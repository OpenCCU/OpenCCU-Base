# Serverseitige Funktionen für Enhanced WebUI auf OpenCCU.
set pep_root /usr/local/addons/ewebui
set pep_var  $pep_root/var
set pep_version 1.1.0

# Text für die Übertragung als UTF-8-Prozentkodierung verpacken.
proc pep_editor_uri {value} {
  binary scan [encoding convertto utf-8 $value] c* bytes
  set out ""
  foreach byte $bytes {append out %[format %02X [expr {($byte+256)%256}]]}
  return $out
}
# Prozentkodierte Formulardaten entschlüsseln.
proc pep_urldecode {s} {
  set out ""
  set n [string length $s]
  set i 0
  while {$i < $n} {
    set c [string index $s $i]
    if {$c == "+"} {
      append out " "
    } elseif {$c == "%" && $i + 2 < $n && [regexp {^[0-9a-fA-F][0-9a-fA-F]$} [string range $s [expr {$i+1}] [expr {$i+2}]]]} {
      set hex [string range $s [expr {$i+1}] [expr {$i+2}]]
      scan $hex %x code
      append out [format %c $code]
      incr i 2
    } else {
      append out $c
    }
    incr i
  }
  return $out
}

# Eingabefelder aus der CGI-Anfrage lesen.
proc pep_read_params {} {
  global env pep_P
  set data ""
  if {[info exists env(QUERY_STRING)]} { set data $env(QUERY_STRING) }
  if {[info exists env(REQUEST_METHOD)] && $env(REQUEST_METHOD) == "POST"} {
    set len 0
    if {[info exists env(CONTENT_LENGTH)]} { set len $env(CONTENT_LENGTH) }
    if {$len > 0 && $len < 2000000} {
      set body [read stdin $len]
      if {$data != ""} { append data "&" }
      append data $body
    }
  }
  foreach pair [split $data "&"] {
    set eq [string first "=" $pair]
    if {$eq < 0} continue
    set k [pep_urldecode [string range $pair 0 [expr {$eq-1}]]]
    set v [pep_urldecode [string range $pair [expr {$eq+1}] end]]
    set pep_P($k) $v
  }
}

# Ein übermitteltes Feld abfragen.
proc pep_param {name} {
  global pep_P
  if {[info exists pep_P($name)]} { return $pep_P($name) }
  return ""
}

# Eine gültige numerische CCU-Objekt-ID erkennen.
proc pep_is_id {s} { return [expr {[regexp {^[1-9][0-9]{0,9}$} $s] && $s < 2147483647}] }

# Prüfen, ob alle Listeneinträge übereinstimmen.
proc pep_uniform {lst} {
  set first [lindex $lst 0]
  foreach x $lst { if {$x != $first} { return 0 } }
  return 1
}

# Die Gültigkeit der WebUI-Sitzung prüfen.
proc pep_check_session {sid} {
  set sidnr ""
  if {![regexp {^@([0-9a-zA-Z]{10})@$} $sid all sidnr]} {
    if {![regexp {^[0-9a-zA-Z]{10}$} $sid]} { return 0 }
    set sidnr $sid
  }
  set script "string pepSession = system.GetSessionVarStr(\"$sidnr\");\n"
  append script "if (pepSession == \"\") { pepSession = system.GetSessionVarStr(\"@$sidnr@\"); }\nWrite(pepSession);"
  array set res [rega_script $script]
  if {[info exists res(STDOUT)] && [string trim $res(STDOUT)] != ""} { return 1 }
  return 0
}

# Die Administratorberechtigung der Sitzung prüfen.
proc pep_check_admin {sid} {
  set sidnr ""
  if {![regexp {^@([0-9a-zA-Z]{10})@$} $sid all sidnr]} {
    if {![regexp {^[0-9a-zA-Z]{10}$} $sid]} { return 0 }
    set sidnr $sid
  }
  set s "string sS = system.GetSessionVarStr(\"$sidnr\");\n"
  append s "if (sS == \"\") { sS = system.GetSessionVarStr(\"@$sidnr@\"); }\n"
  append s "if( sS != \"\" )\n\{\n"
  append s "  string sU = sS.StrValueByIndex(\";\",0);\n"
  append s "  object oU = dom.GetObject(sU);\n"
  append s "  if( oU )\n  \{\n"
  append s "    if( oU.UserLevel() == iulAdmin ) \{ Write(\"ADMIN\"); \}\n"
  append s "  \}\n\}\n"
  array set res [rega_script $s]
  if {[info exists res(STDOUT)] && [string trim $res(STDOUT)] == "ADMIN"} { return 1 }
  return 0
}

# ReGa aufrufen und dessen Textausgabe zurückgeben.
proc pep_rega {script} {
  array set res [rega_script $script]
  if {[info exists res(STDOUT)]} { return $res(STDOUT) }
  return ""
}

# Die Grundoptionen des Addons lesen.
proc pep_settings {} {
  global pep_root
  set out {}
  foreach name {sorting infos favorites programids programsort printnotes themes} {
    lappend out [pep_option_active $name]
  }
  return $out
}

# Die Grundoptionen prüfen und zentral speichern.
proc pep_settings_set {sorting infos {extra {}}} {
  global pep_root
  if {($sorting != "0" && $sorting != "1") || ($infos != "0" && $infos != "1")} { return "ERR|Ungueltige Einstellung" }
  file mkdir "$pep_root/etc"
  set values [list $sorting $infos]
  set current [pep_settings]; set n 2
  foreach name {favorites programids programsort printnotes themes} {
    set value [lindex $extra [expr {$n-2}]]
    if {$value == ""} { set value [lindex $current $n] }
    if {$value != "0" && $value != "1"} { return "ERR|Ungueltige Einstellung" }
    lappend values $value; incr n
  }
  foreach name {sorting infos favorites programids programsort printnotes themes} value $values {
    set file "$pep_root/etc/$name.disabled"
    if {$value == "1"} {
      if {[file exists $file]} { file delete $file }
    } else { set fh [open $file w]; close $fh }
  }
  if {[file exists "$pep_root/etc/disabled"]} { file delete "$pep_root/etc/disabled" }
  return "OK|[join $values |]"
}


source "$pep_root/lib/registry.tcl"
