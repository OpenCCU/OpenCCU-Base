set pep_negative_options {sorting infos favorites programids programsort themes}
set pep_module_options {editor {sorting infos} groups {programgroups sysvargroups} filters {filters} columns {programids programsort} script {scripteditor} mobile {mobile} favorites {favorites} account {useraccount} theme {themes}}
# Die Paketliste stammt aus dem Build. Jede Markierung steht für ein installiertes Funktionspaket.
proc pep_module_present {module} {
  global pep_root
  return [file exists "$pep_root/modules/$module.version"]
}

# Die registrierten Module und deren Versionen für den WebUI-Loader bereitstellen.
proc pep_module_manifest {} {
  global pep_root pep_module_options
  set out {}
  foreach {module options} $pep_module_options {
    if {![pep_module_present $module]} {continue}
    set f [open "$pep_root/modules/$module.version" r]
    set version [string trim [read $f]]
    close $f
    if {[regexp {^[0-9A-Za-z._-]+$} $version]} {lappend out "$module|$version"}
  }
  return $out
}

# Nur installierte Optionen für die WebUI freigeben.
proc pep_option_present {option} {
  global pep_module_options
  foreach {module options} $pep_module_options {
    if {[lsearch -exact $options $option] >= 0} {return [pep_module_present $module]}
  }
  return 0
}

# Die Einstellung anhand des bisherigen Dateiformats lesen.
proc pep_option_active {option} {
  global pep_root pep_negative_options
  if {![pep_option_present $option] || [file exists "$pep_root/etc/disabled"]} {return 0}
  if {[lsearch -exact $pep_negative_options $option] >= 0} {
    return [expr {![file exists "$pep_root/etc/$option.disabled"]}]
  }
  return [file exists "$pep_root/etc/$option.enabled"]
}

# Die Einstellung eines einzelnen Schalters speichern.
proc pep_option_write {option value} {
  global pep_root pep_negative_options
  set suffix enabled
  set present $value
  if {[lsearch -exact $pep_negative_options $option] >= 0} {
    set suffix disabled
    set present [expr {!$value}]
  }
  set path "$pep_root/etc/$option.$suffix"
  if {$present} {set f [open $path w]; close $f} else {file delete $path}
}

# Nur die Optionen der installierten Pakete im Einstellungsdialog anzeigen.
proc pep_module_settings {} {
  global pep_module_options
  set out OK
  foreach {module options} $pep_module_options {
    if {![pep_module_present $module]} {continue}
    foreach option $options {append out "\n$option|[pep_option_active $option]"}
  }
  return $out
}

# Geänderte Optionen erst nach vollständiger Prüfung unter der CGI-Schreibsperre speichern.
proc pep_module_settings_set {} {
  global pep_root pep_module_options
  set values {}
  foreach {module options} $pep_module_options {
    foreach option $options {
      set value [pep_param $option]
      if {$value == ""} {continue}
      if {![pep_module_present $module] || ($value != "0" && $value != "1")} {
        return "ERR|Ungueltige oder nicht installierte Einstellung"
      }
      lappend values $option $value
    }
  }
  if {![llength $values]} {return [pep_module_settings]}
  if {[file exists "$pep_root/etc/disabled"]} {
    # Ein alter globaler Sperrschalter entspricht ausgeschalteten Einzeloptionen.
    foreach {module options} $pep_module_options {
      foreach option $options {pep_option_write $option 0}
    }
    file delete "$pep_root/etc/disabled"
  }
  foreach {option value} $values {pep_option_write $option $value}
  return [pep_module_settings]
}
