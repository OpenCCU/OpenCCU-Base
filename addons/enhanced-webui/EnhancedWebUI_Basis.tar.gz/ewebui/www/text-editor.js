// Den gemeinsamen Dialog für Infotext, Programmname und Programmbeschreibung bereitstellen.
(function(w){
 'use strict';var P=w.__PEP__,d=w.document;if(!P){return;}
 P.openTextEditor=/* Den gemeinsamen Textdialog für das gewählte Feld öffnen. */ function(options){
  var old=d.getElementById('pep-text-editor');if(old){return;}
  var dialog=d.createElement('dialog');dialog.id='pep-text-editor';dialog.className='pep-text-dialog';
  var title=d.createElement('h2'),input=d.createElement('textarea'),count=d.createElement('p'),error=d.createElement('p'),actions=d.createElement('div'),cancel=d.createElement('button'),apply=d.createElement('button'),previous=d.activeElement;
  title.id='pep-text-title';title.textContent=options.title;dialog.setAttribute('aria-labelledby',title.id);input.value=options.value;input.rows=7;input.setAttribute('aria-label',options.title);
  if(options.limit){input.maxLength=options.limit;}count.className='pep-text-count';error.className='pep-text-error';error.setAttribute('role','alert');
  // Den Zeichenzähler und die Eingabegrenze aktualisieren.
  function update(){count.textContent=input.value.length+(options.limit?' / '+options.limit:'')+' Zeichen';}update();input.oninput=update;
  cancel.type=apply.type='button';cancel.textContent='Abbrechen';apply.textContent='\u00dcbernehmen';
  // Den Textdialog schließen.
  function close(){if(dialog.open&&dialog.close){dialog.close();}dialog.remove();if(previous&&previous.isConnected){previous.focus();}}
  cancel.onclick=close;apply.onclick=/* Den eingegebenen Text übernehmen. */ function(){var message;try{message=options.apply(input.value);}catch(e){error.textContent='Der Text konnte nicht \u00fcbernommen werden.';return;}if(message){error.textContent=message;return;}close();};
  dialog.addEventListener('cancel',function(e){e.preventDefault();close();});actions.append(cancel,apply);dialog.append(title,input,count,error,actions);d.body.appendChild(dialog);dialog.showModal();input.focus();
 };
 d.addEventListener('click',function(e){
  var mobile=w.__EWUI_MOBILE__&&w.__EWUI_MOBILE__.isEnabled()&&w.innerWidth<=900;
  if(!P.settings.infos&&!mobile){return;}
  var cell=e.target.closest&&e.target.closest('#ProgramTable td[id]'),match=cell&&/^prg([1-9][0-9]*)(name|desc)$/.exec(cell.id);if(!match||cell.querySelector('input,textarea')){return;}
  if(!w.iseSystem||typeof w.iseSystem.saveName!=='function'||typeof w.iseSystem.saveDesc!=='function'){return;}
  e.preventDefault();e.stopImmediatePropagation();var name=match[2]==='name',id=Number(match[1]);
  P.openTextEditor({title:name?'Programmname':'Programmbeschreibung',value:cell.textContent,limit:name?100:null,apply:/* Den Text an den Aufrufer zurückgeben. */ function(value){
   if(!cell.isConnected){return 'Das Programm ist nicht mehr ge\u00f6ffnet.';}
   if(name&&(!value.trim()||value.length>100||/[\r\n]/.test(value))){return 'Bitte einen einzeiligen Namen mit 1 bis 100 Zeichen eingeben.';}
   if(typeof w.isTextAllowed==='function'&&!w.isTextAllowed(value,name?1:0,true)){return 'Der Text enth\u00e4lt Zeichen, die die WebUI nicht erlaubt.';}
   if(/[<>'"&$\[\]{}\\]/.test(value)){return 'Der Text enth\u00e4lt Zeichen, die die WebUI nicht erlaubt.';}
   if(value===cell.textContent){return;}
   if(name){w.iseSystem.saveName(id,value,cell.id);}else{w.iseSystem.saveDesc(id,value);}
   cell.textContent=value;
  }});
 },true);
})(window);
