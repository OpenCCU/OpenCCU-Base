#!/bin/tclsh
# Die Meldung für eine ungültige oder abgelaufene Sitzung ausgeben.
set pep_root /usr/local/addons/ewebui
set ready 0
if {![catch {load tclrega.so;source "$pep_root/lib/ewebui_lib.tcl"}]} {set ready 1}
set status 404
if {[info exists env(REDIRECT_STATUS)] && [regexp {^[45][0-9][0-9]$} $env(REDIRECT_STATUS)]} {set status $env(REDIRECT_STATUS)}
set uri ""
if {[info exists env(REQUEST_URI)]} {set uri $env(REQUEST_URI)}
set sid ""
if {[regexp {[?&]sid=([^&]*)} $uri unused encoded] && $ready} {set sid [pep_urldecode $encoded]}
set expired 0
if {$status == 500 && $sid != "" && $ready} {
  if {![catch {set valid [pep_check_session $sid]}] && !$valid} {set expired 1}
}
set mobile [expr {[file exists "$pep_root/etc/mobile.enabled"] && ![file exists "$pep_root/etc/disabled"] && ![file exists "$pep_root/etc/uninstalled"]}]
set styled [expr {![file exists "$pep_root/etc/disabled"] && ![file exists "$pep_root/etc/uninstalled"]}]
set themes [expr {$ready && [pep_option_active themes] && ![file exists "$pep_root/etc/uninstalled"]}]
fconfigure stdout -encoding utf-8
puts "Status: $status"
puts "Content-Type: text/html; charset=utf-8"
puts "Cache-Control: no-store"
puts "X-Content-Type-Options: nosniff"
puts ""
set message "Anfrage fehlgeschlagen (HTTP $status)."
if {$expired} {set message "Sitzung ung\u00fcltig oder abgelaufen!"}
puts {<!doctype html><html lang="de"><head><meta charset="utf-8">}
if {$styled} {
 puts {<meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0;min-height:100vh;min-height:100dvh;display:grid;place-items:center;background:#edf2f6;color:#253d50;font:20px/1.5 Arial,sans-serif}main{box-sizing:border-box;text-align:center;width:min(100% - 32px,520px);padding:28px;background:white;border:1px solid #c3d1dd;border-radius:7px}p{margin:0 0 24px}a{display:inline-block;min-width:140px;padding:12px 20px;box-sizing:border-box;background:#215f91;color:white;border-radius:4px;font-weight:bold;text-decoration:none}.dark{background:#14202d;color:#e5edf5}.dark main{background:#293e50;border-color:#596e84}.dark a{background:#3b5e7b;color:#e5edf5}</style>}
}
puts {<title>WebUI</title></head><body>}
if {$styled && $themes} {puts {<script>try{if(localStorage.getItem('ewebui-theme')==='dark'){document.body.className='dark';}}catch(e){}</script>}}
puts "<main><p>$message</p><a href=\"/index.htm\">Weiter</a></main></body></html>"
