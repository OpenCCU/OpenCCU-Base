
(function () {
  'use strict';
  const d = document, save = d.getElementById('save'), status = d.getElementById('status');
  const buttons = ['enable-all','disable-all'].map(id => d.getElementById(id));
  const sections = [...d.querySelectorAll('.feature-option')];
  let controls = [], busy = true;
  sections.forEach(section => { section.hidden = true; });

  // Die vorhandene WebUI-Sitzung für die Einstellungsanfrage verwenden.
  function sid() {
    const token = new URLSearchParams(location.search).get('sid');
    if (token) { return token; }
    try { if (window.opener?.SessionId) { return String(window.opener.SessionId); } } catch (error) {}
    try { return String(d.getElementById('frame').contentWindow.SessionId || ''); } catch (error) { return ''; }
  }

  // Die Schalter der registrierten Pakete lesen oder speichern.
  async function request(op, values = {}) {
    const response = await fetch('ewebui.cgi', {
      method: 'POST',
      body: new URLSearchParams({op, sid: sid(), ...values}),
      cache: 'no-store'
    });
    const lines = (await response.text()).trim().split(/\r?\n/);
    if (!response.ok || lines.shift() !== 'OK') { throw Error('Die Einstellungen konnten nicht verarbeitet werden.'); }
    return new Map(lines.map(line => line.split('|')));
  }

  // Die verfügbaren Bedienelemente abhängig von Sitzung und Speicherstatus freigeben.
  function updateControls() {
    save.disabled = busy || !controls.length || !sid();
    buttons.forEach(button => { button.disabled = busy || !controls.length; });
    d.getElementById('auth').hidden = !!sid();
  }

  // Nur Optionen tatsächlich installierter Pakete anzeigen.
  async function load() {
    try {
      const options = await request('module_settings');
      controls = [];
      sections.forEach(section => {
        const input = section.querySelector('input');
        section.hidden = !options.has(input.id);
        if (!section.hidden) {
          input.disabled = false;
          input.checked = options.get(input.id) === '1';
          controls.push(input);
        }
      });
      status.textContent = controls.length ? '' : 'Installiere ein Enhanced WebUI-Funktionspaket, um hier seine Einstellungen zu sehen.';
    } catch (error) { status.textContent = error.message; }
    finally { busy = false; updateControls(); }
  }

  // Geänderte Werte speichern und geöffnete WebUI-Tabs informieren.
  async function saveOptions() {
    if (busy) { return; }
    busy = true;
    updateControls();
    controls.forEach(input => { input.disabled = true; });
    status.textContent = 'Einstellungen werden gespeichert …';
    try {
      const options = await request('module_settings_set', Object.fromEntries(controls.map(input => [input.id, input.checked ? '1' : '0'])));
      const flags = Object.fromEntries([...options].map(([key, value]) => [key, value === '1']));
      const modules = {scripteditor:'editor',filters:'filters',useraccount:'userAccount',programgroups:'programGroups',sysvargroups:'systemVariableGroups'};
      try {
        for (const [key, value] of options) { localStorage.setItem('ewebui-'+key+'-enabled', value); }
        localStorage.setItem('ewebui-settings', JSON.stringify(flags));
      } catch (error) {}
      try {
        const opener = window.opener;
        opener?.__PEP__?.applySettings(flags);
        for (const [key, module] of Object.entries(modules)) {
          if (options.has(key)) { opener?.__PEP__?.[module]?.configure(flags[key]); }
        }
        if (options.has('mobile')) { opener?.__EWUI_MOBILE__?.configure(flags.mobile); }
      } catch (error) {}
      status.textContent = 'Einstellungen gespeichert.';
    } catch (error) { status.textContent = error.message; }
    finally {
      busy = false;
      controls.forEach(input => { input.disabled = false; });
      updateControls();
    }
  }

  buttons.forEach((button, index) => {
    button.addEventListener('click', () => {
      controls.forEach(input => { input.checked = index === 0; });
      status.textContent = 'Auswahl geändert. Mit Einstellungen speichern übernehmen.';
    });
  });
  save.addEventListener('click', saveOptions);
  d.getElementById('login').addEventListener('click', function () {
    const frame = d.getElementById('frame');
    frame.hidden = false;
    frame.src = '/';
    this.hidden = true;
  });
  setInterval(updateControls, 1000);
  updateControls();
  load();
})();
