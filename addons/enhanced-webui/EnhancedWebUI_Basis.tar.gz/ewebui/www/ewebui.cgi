#!/bin/tclsh
# Schnittstelle zwischen der WebUI und den serverseitigen Addon-Funktionen.

load tclrega.so
source /usr/local/addons/ewebui/lib/ewebui_lib.tcl

puts "Content-Type: text/plain; charset=utf-8"
puts "Cache-Control: no-store"
puts ""

# Anfragen prüfen und an die passende Funktion weiterleiten.
proc pep_main {} {
  global pep_version pep_root pep_var pep_lock env errorCode
  pep_read_params
  set op [pep_param op]
  # Die Einstellungsseite zeigt ausschließlich Schalter registrierter Pakete.
  if {$op == "module_settings"} {return [pep_module_settings]}
  switch -exact -- $op {
    desc_get - desc_set - reorder - printnotes_status {set module editor}
    groups_get - groups_change - groups_catalog {set module groups}
    favorites_get - favorites_set {set module favorites}
    program_dates - program_saved {set module columns}
    editor_device {set module script}
    default {set module ""}
  }
  if {$module != ""} {
    if {$op == "printnotes_status" && ![pep_module_present $module]} {return "OK|0"}
    if {![pep_module_present $module]} {return "ERR|Funktionspaket nicht installiert"}
    if {$op != "printnotes_status"} {uplevel #0 [list source "$pep_root/lib/$module.tcl"]}
  }
  if {$op == "programgroups_settings" || $op == "sysvargroups_settings"} {
    set option [lindex [split $op _] 0]
    set active [expr {[pep_option_active $option]}]
    return "OK|$active"
  }
  if {$op == "useraccount_settings"} {
    set active [expr {[pep_option_active useraccount]}]
    return "OK|$active"
  }
  if {$op == "filters_settings"} {
    set active [expr {[pep_option_active filters]}]
    return "OK|$active"
  }
  if {$op == "mobile_settings"} {
    set active [expr {[pep_option_active mobile]}]
    return "OK|$active"
  }
  if {$op == "editor_settings"} {
    set active [expr {[pep_option_active scripteditor]}]
    return "OK|$active"
  }
  if {$op == "ping"} {
    set flags [pep_settings]
    return "OK|ewebui $pep_version|[expr {[lsearch -exact $flags 1] >= 0}]|[join $flags |]"
    return
  }
  if {$op != "desc_get" && $op != "settings_get" && (![info exists env(REQUEST_METHOD)] || $env(REQUEST_METHOD) != "POST")} {
    return "ERR|POST erforderlich"; return
  }
  if {![pep_check_session [pep_param sid]]} {
    return "ERR|Sitzung ungueltig - bitte WebUI neu laden und anmelden"
    return
  }
  # Die Druckintegration fragt nur die Freigabe ab. Die Infotexte liest sie separat.
  if {$op == "printnotes_status"} {
    return "OK|1"
  }
  # Beide Übersichten dürfen Gruppen lesen. Nur Administratoren ändern sie.
  if {$op == "groups_get" || $op == "groups_change" || $op == "groups_catalog"} {
    set kind [pep_param kind]
    if {$kind == ""} {set kind programs}
    if {$kind != "programs" && $kind != "variables"} {return "ERR|Ungueltiger Gruppentyp"}
    set option [expr {$kind == "variables" ? "sysvargroups" : "programgroups"}]
    if {![pep_option_active $option]} {
      return "ERR|Gruppenfunktion ausgeschaltet"
    }
    if {$op == "groups_get"} {
      return [pep_groups_response [pep_groups_read $kind] [pep_check_admin [pep_param sid]]]
    }
  }
  if {$op != "desc_get" && $op != "settings_get" && ![pep_check_admin [pep_param sid]]} {
    return "ERR|Nur Administratoren duerfen Programme aendern"
    return
  }
  if {[lsearch -exact {desc_get settings_get program_dates favorites_get editor_device groups_catalog} $op] < 0} {
    file mkdir $pep_var
    set pep_lock "$pep_var/write.lock"
    if {[catch {set fh [open $pep_lock {WRONLY CREAT EXCL}]}]} {
      set lock_error $errorCode
      set pep_lock ""
      if {[lindex $lock_error 0] == "POSIX" && [lindex $lock_error 1] == "EEXIST"} {
        return "BUSY|Andere Aenderung laeuft oder vorheriger Vorgang unbestaetigt"
      }
      return "ERR|Schreibsperre konnte nicht angelegt werden"
    }
    close $fh
  }
  if {$op == "module_settings_set"} {
    return [pep_module_settings_set]
  } elseif {$op == "groups_change"} {
    # Die Formularroutine liefert die dekodierten Bytes. Gruppennamen als UTF-8 lesen.
    set name [encoding convertfrom utf-8 [encoding convertto iso8859-1 [pep_param name]]]
    return [pep_groups_change [pep_param action] [pep_param gid] [pep_param revision] $name [pep_param ids] $kind]
  } elseif {$op == "groups_catalog"} {
    return [pep_groups_catalog $kind]
  } elseif {$op == "settings_get"} {
    set flags [pep_settings]
    return "OK|[join $flags |]"
  } elseif {$op == "editor_device"} {
    if {![file exists "$pep_root/etc/scripteditor.enabled"] || [file exists "$pep_root/etc/disabled"]} {return "ERR|Skripteditor ausgeschaltet"}
    return [pep_editor_device [pep_param id]]
  } elseif {$op == "favorites_get"} {
    return [pep_favorites_get [pep_param parent]]
  } elseif {$op == "favorites_set"} {
    return [pep_favorites_set [pep_param parent] [pep_param expected] [pep_param order]]
  } elseif {$op == "program_dates"} {
    return [pep_program_dates_get]
  } elseif {$op == "program_saved"} {
    return [pep_program_saved [pep_param pid] [pep_param copy]]
  } elseif {$op == "desc_get"} {
    return [pep_desc_get [pep_param pid]]
  } elseif {$op == "desc_set"} {
    return [pep_desc_set [pep_param pid] [pep_param items]]
  } elseif {$op == "reorder"} {
    if {![lindex [pep_settings] 0]} { return "ERR|Sortierung ist ausgeschaltet"; return }
    if {![regexp {^[1-9][0-9]*(,[1-9][0-9]*)*$} [pep_param expected]]} {
      return "ERR|Struktur-Snapshot fehlt"; return
    }
    set kind [pep_param kind]
    if {$kind == "conds"} {
      return [pep_op_conds [pep_param rid] [pep_param cid] [pep_param perm]]
    } elseif {$kind == "groups"} {
      return [pep_op_groups [pep_param rid] [pep_param perm]]
    } elseif {$kind == "acts"} {
      return [pep_op_acts [pep_param rid] [pep_param did] [pep_param perm]]
    } elseif {$kind == "branches"} {
      return [pep_op_branches [pep_param rids] [pep_param perm]]
    } else {
      return "ERR|Unbekannte Operation"
    }
  } elseif {$op == "selftest"} {
    return "ERR|Der Selbsttest ist in dieser Version deaktiviert"
  } else {
    return "ERR|Unbekannte Operation"
  }
}

# Die Schreibsperre vor der Antwort freigeben, damit Folgeanfragen sofort schreiben können.
if {[catch {set result [pep_main]} err]} {
  set result "ERR|Interner Fehler: $err"
}
if {[info exists pep_lock] && $pep_lock != ""} {
  if {[catch {file delete $pep_lock}]} {
    set result "POSTFAIL|Vorgang ausgefuehrt, Schreibsperre konnte nicht freigegeben werden"
  }
}
puts $result
