#!/bin/tclsh
# Prototype ausliefern und danach die Einstellungen für Theme und mobile Ansicht einbinden.

set pep_dir /usr/local/addons/ewebui
set root /www
if {[info exists env(DOCUMENT_ROOT)] && $env(DOCUMENT_ROOT) != ""} {
  set candidate [string trimright $env(DOCUMENT_ROOT) "/"]
  if {[file isfile "$candidate/webui/js/extern/prototype.js"]} { set root $candidate }
}
set orig "$root/webui/js/extern/prototype.js"

fconfigure stdout -translation binary -encoding iso8859-1 -buffering full

if {[catch {set fh [open $orig r]}]} {
  puts -nonewline "Status: 404 Not Found\r\nContent-Type: text/plain\r\n\r\nprototype.js not found\r\n"
  exit 0
}
fconfigure $fh -translation binary -encoding iso8859-1

puts -nonewline "Content-Type: application/javascript\r\n"
puts -nonewline "Cache-Control: no-cache, must-revalidate\r\n"
puts -nonewline "\r\n"

fcopy $fh stdout
close $fh

catch {
  if {![file exists "$pep_dir/etc/uninstalled"]} {
    set pep_root $pep_dir
    source "$pep_root/lib/registry.tcl"
    foreach item [pep_module_manifest] {
      set fields [split $item |]
      set versions([lindex $fields 0]) [lindex $fields 1]
    }
    set enabled [pep_option_active themes]
    if {[info exists versions(mobile)]} {
      set ver $versions(mobile)
      puts -nonewline "\n;(function(){if(window.__EWUI_MOBILE_LOADING__){return;}window.__EWUI_MOBILE_LOADING__=true;var s=document.createElement('script');s.charset='UTF-8';s.src='/addons/ewebui/mobile.js?v=$ver';(document.head||document.documentElement).appendChild(s);})();\n"
    }
    if {[info exists versions(theme)]} {
      set ver $versions(theme)
      puts -nonewline "\n;(function(){try{var w=window;if(w.__EWUI_THEME_LOADING__){return;}w.__EWUI_THEME_LOADING__=true;w.__EWUI_THEME_CONTEXT__={base:'/addons/ewebui/',version:'$ver',settings:{themes:$enabled}};var s=document.createElement('script');s.charset='UTF-8';s.src='/addons/ewebui/theme.js?v=$ver';s.onerror=function(){w.__EWUI_THEME_LOADING__=false;};(document.head||document.documentElement).appendChild(s);}catch(e){}})();\n"
    }
  }
}
flush stdout
