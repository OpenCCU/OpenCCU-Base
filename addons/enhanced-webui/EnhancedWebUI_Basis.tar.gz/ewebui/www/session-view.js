// Abgelaufene Sitzungen deutlicher anzeigen.
(function(w){
 'use strict';var d=w.document,pending=false;
 // Die native Meldung zur abgelaufenen Sitzung erkennen.
 function expired(host){return /^Sitzung ung(?:ü|Ã¼|\uFFFD)ltig oder abgelaufen!\s*Weiter$/.test(host.textContent.replace(/\s+/g,' ').trim());}
 // Die Meldung in der WebUI sichtbar hervorheben.
 function scan(){
  Array.prototype.forEach.call(d.querySelectorAll('.pep-session-surface'),function(host){if(!host.querySelector(':scope > .pep-session-card')){host.classList.remove('pep-session-surface');}});
  Array.prototype.forEach.call(d.querySelectorAll('a[href]'),function(link){
   if(link.closest('.pep-session-card')||link.textContent.trim()!=='Weiter'){return;}var uri;try{uri=new URL(link.href,d.baseURI);}catch(e){return;}
   if(uri.origin!==w.location.origin||uri.pathname!=='/index.htm'){return;}
   var host=link.parentElement;
   while(host&&host!==d.body){
    if(expired(host)&&!host.querySelector('input,textarea,button')&&host.childElementCount<=3){
     var content=host.closest('#content');if(content&&expired(content)&&!content.querySelector('input,textarea,button')){host=content;}
     var card=d.createElement('section');card.className='pep-session-card';card.setAttribute('role','alert');
     while(host.firstChild){card.appendChild(host.firstChild);}host.appendChild(card);host.classList.add('pep-session-surface');link.classList.add('pep-session-continue');return;
    }
    host=host.parentElement;
   }
  });
 }
 new w.MutationObserver(function(){if(!pending){pending=true;w.setTimeout(function(){pending=false;scan();},40);}}).observe(d.documentElement,{subtree:true,childList:true});scan();
})(window);
