#!/bin/tclsh
# Das Originalskript ausliefern und anschließend die Erweiterung laden.

set pep_dir /usr/local/addons/ewebui
set root /www
if {[info exists env(DOCUMENT_ROOT)] && $env(DOCUMENT_ROOT) != ""} {
  set candidate [string trimright $env(DOCUMENT_ROOT) "/"]
  if {[file isfile "$candidate/webui/webui.js"]} { set root $candidate }
}
set orig "$root/webui/webui.js"

fconfigure stdout -translation binary -encoding iso8859-1 -buffering full

if {[catch {set fh [open $orig r]}]} {
  puts -nonewline "Status: 404 Not Found\r\nContent-Type: text/plain\r\n\r\nwebui.js not found\r\n"
  exit 0
}
fconfigure $fh -translation binary -encoding iso8859-1

puts -nonewline "Content-Type: application/javascript\r\n"
puts -nonewline "Cache-Control: no-cache, must-revalidate\r\n"
puts -nonewline "\r\n"

fcopy $fh stdout
close $fh

catch {
  if {![file exists "$pep_dir/etc/uninstalled"]} {
    set pep_root $pep_dir
    source "$pep_root/lib/registry.tcl"
    set ver "1.1.2-split2"
    set sorting [pep_option_active sorting]; set infos [pep_option_active infos]
    set extra ""
    foreach name {favorites programids programsort printnotes themes} {
      append extra ",$name:[pep_option_active $name]"
    }
    set packages {}
    foreach item [pep_module_manifest] {
      set fields [split $item |]
      lappend packages "[lindex $fields 0]:'[lindex $fields 1]'"
    }
    set manifest [join $packages ,]
    puts -nonewline "\n;(function(){try{var w=window;if(w.__PEP__||w.__PEP_LOADING__){return;}w.__PEP_PACKAGES__={$manifest};w.__PEP_CONFIG__={sorting:$sorting,infos:$infos$extra};w.__PEP_LOADING__=true;var s=document.createElement('script');s.charset='UTF-8';s.src='/addons/ewebui/ewebui.js?v=$ver';s.onerror=function(){w.__PEP_LOADING__=false;};(document.head||document.documentElement).appendChild(s);}catch(e){}})();\n"
  }
}
flush stdout
