// Den gemeinsamen Einstellungszugang in der Systemsteuerung ergänzen.
(function(w){
 'use strict';
 var P=w.__PEP__,d=w.document;
 if(!P||P.overview){return;}
 // Ein Element mit Text erzeugen.
 function node(tag,cls,text){var e=d.createElement(tag);e.className=cls||'';if(text!==undefined){e.textContent=text;}return e;}
 // Die Addon-Einstellungen in der Systemsteuerung verlinken.
 function settingsButton(){
  var table=d.querySelector('#configMainTable,#mainTable'),software=table&&table.querySelector('[onclick*="showSoftwareCP"]');if(!software){return;}
  var button=d.getElementById('pep-system-settings');
  if(!button){
   var cell=node(table.tagName==='TABLE'?'td':'div',table.tagName==='TABLE'?'':'cpCell'),host=node('div','cpButton');button=node('a','StdTableBtn CLASS21701','Enhanced WebUI');button.id='pep-system-settings';button.target='_blank';button.rel='noopener';button.title='Enhanced WebUI – Einstellungen';
   host.appendChild(button);cell.appendChild(host);if(table.tagName==='TABLE'){var row=node('tr','CLASS21700');row.appendChild(cell);(table.tBodies[0]||table).appendChild(row);}else{table.appendChild(cell);}
  }
  var icon=d.getElementById('pep-system-help'),features=['Programmlogik sortieren','Infotexte in Programmen','Erweiterter Skripteditor','Favoriten per Drag and Drop sortieren','Verbesserte Filter','Mobile Ansicht','Theme-Auswahl'];
  if(!icon){
   var help=node('div','StdTableBtnHelp');icon=node('img');icon.id='pep-system-help';icon.src='/ise/img/help.png';icon.alt='Funktionen von Enhanced WebUI';icon.tabIndex=0;icon.title=features.join(' · ');help.appendChild(icon);button.parentNode.appendChild(help);
  }
  if(!icon.dataset.pepTooltip&&w.jQuery&&w.jQuery.fn.powerTip){var tip=node('ul');features.forEach(function(text){tip.appendChild(node('li','',text));});w.jQuery(icon).data('powertip',tip.outerHTML).powerTip({placement:'se',followMouse:true});icon.dataset.pepTooltip='1';icon.removeAttribute('title');}
  button.href=P.base+'index.html?sid='+encodeURIComponent(P.sid());
 }
 P.overview={scan:settingsButton};
 settingsButton();
})(window);
