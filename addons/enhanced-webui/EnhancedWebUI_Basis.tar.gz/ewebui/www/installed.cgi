#!/bin/tclsh
# Eine abgeschlossene Deinstallation für die WebUI erkennbar machen.
puts "Content-Type: text/plain; charset=utf-8"
puts "Cache-Control: no-store"
puts ""
if {[file exists /usr/local/addons/ewebui/etc/uninstalled]} {puts "EWEBUI_REMOVED"} else {puts "EWEBUI_INSTALLED"}
