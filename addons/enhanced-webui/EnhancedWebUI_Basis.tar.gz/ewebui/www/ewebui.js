// Gemeinsame WebUI-Einbindung, Sitzung und Anfragen für die installierten Pakete.
(function (win) {
  'use strict';
  var doc = win.document;
  if (win.__PEP__) { return; }

  var VERSION = '1.1.2-split2';
  // Den Installationspfad aus der URL dieses Skripts ableiten.
  var BASE = (function () {
    try {
      var s = doc.currentScript && doc.currentScript.src;
      if (s) { return s.replace(/[^\/]*$/, ''); }
    } catch (e) {    }
    return '/addons/ewebui/';
  })();

  var PEP = win.__PEP__ = { version: VERSION, base: BASE };
  // Erst die bestätigte Deinstallation beendet die Sitzung. Eine fehlende Antwort kann auch ein Verbindungsproblem sein.
  var uninstallChecking=false,uninstallLogout=false;
  // Deinstallationsstatus der Zentrale prüfen.
  function checkInstalled(){
    if(uninstallChecking||uninstallLogout){return;}uninstallChecking=true;
    var x=new win.XMLHttpRequest();x.open('GET',BASE+'installed.cgi?t='+Date.now(),true);x.timeout=5000;
    x.onload=/* Nach bestätigter Deinstallation die Sitzung beenden. */ function(){uninstallChecking=false;if(x.status!==200||(x.responseText||'').trim()!=='EWEBUI_REMOVED'){return;}uninstallLogout=true;
      if(PEP.drag){PEP.drag.cancel();}
      if(PEP.favoriteSorting){PEP.favoriteSorting.cancel();}
      if(typeof win.logout==='function'){win.logout();}
      else if(typeof win.homematic==='function'){win.homematic('Session.logout',{},function(){win.location.replace('/');});}
      else{win.location.replace('/');}
    };x.onerror=x.ontimeout=/* Zeitüberschreitung bei der Statusprüfung behandeln. */ function(){uninstallChecking=false;};x.send();
  }
  win.setInterval(checkInstalled,10000);win.addEventListener('focus',checkInstalled);
  doc.addEventListener('visibilitychange',function(){if(!doc.hidden){checkInstalled();}});
  PEP.checkInstalled=checkInstalled;
  if(win.__EWUI_THEME__){PEP.theme=win.__EWUI_THEME__;}
  PEP.packages = win.__PEP_PACKAGES__ || {};
  PEP.settings = win.__PEP_CONFIG__ || {};
  var settingsRevision=0,settingsRequest=0;
  // Registrierte Ansichten nach Navigation und Einstellungsänderungen aktualisieren.
  function scanOverviews() {
    for (const view of [PEP.overview, PEP.programColumns, PEP.favoriteSorting]) {
      if (view) { view.scan(); }
    }
  }

  PEP.applySettings = /* Einstellungen übernehmen und sichtbare Funktionen aktualisieren. */ function (flags) {
    settingsRevision++;
    var normalized={};
    ['sorting','infos','favorites','programids','programsort','printnotes','themes'].forEach(function(k){normalized[k]=flags[k]===true||flags[k]===1||flags[k]==='1';});
    PEP.settings=normalized;
    doc.documentElement.classList.toggle('pep-no-sorting',!PEP.settings.sorting);
    doc.documentElement.classList.toggle('pep-no-infos',!PEP.settings.infos);
    doc.documentElement.classList.toggle('pep-no-favorites',!PEP.settings.favorites);
    if(PEP.drag){PEP.drag.cancel();}
      if(PEP.favoriteSorting){PEP.favoriteSorting.cancel();}
    if(PEP.scan){PEP.scan();}
    scanOverviews();
    if(PEP.theme){PEP.theme.refresh();}
  };
  PEP.applySettings(PEP.settings);
  win.addEventListener('storage',function(e){if(e.key==='ewebui-settings' && e.newValue){try{PEP.applySettings(JSON.parse(e.newValue));}catch(ignore){}}});

  // Ein Element im angegebenen Bereich suchen.
  function $(sel, root) { return (root || doc).querySelector(sel); }
  // Alle passenden Elemente im Bereich sammeln.
  function $all(sel, root) { return Array.prototype.slice.call((root || doc).querySelectorAll(sel)); }
  // Ein DOM-Element erzeugen.
  function el(tag, cls, text) {
    var e = doc.createElement(tag);
    if (cls) { e.className = cls; }
    if (text !== undefined) { e.textContent = text; }
    return e;
  }
  // Ein Attribut auslesen.
  function attr(node, name) { return (node && node.getAttribute && node.getAttribute(name)) || ''; }

  PEP.sid = /* Die Sitzungskennung der WebUI ermitteln. */ function () {
    try { if (win.SessionId) { return String(win.SessionId); } } catch (e) {    }
    return '';
  };

  // Formulardaten für die CGI-Anfrage kodieren.
  function formBody(p) {
    var parts = [];
    for (var k in p) { if (Object.prototype.hasOwnProperty.call(p, k)) {
      parts.push(encodeURIComponent(k) + '=' + encodeURIComponent(p[k]));
    } }
    return parts.join('&');
  }

  // Schreibvorgänge laufen nacheinander. Ein erneuter Versuch ist nur sicher, wenn die CCU die Anfrage vor jeder Änderung abgelehnt hat.
  var writes = [], writing = false;
  // Eine Anfrage an die Addon-Schnittstelle senden.
  function sendApi(params, cb) {
    params.sid = PEP.sid();
    var x = new win.XMLHttpRequest();
    x.open('POST', BASE + 'ewebui.cgi', true);
    x.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    var finished = false;
    // Die Anfrage einmalig abschließen.
    function done() {
      if (finished) { return; } finished = true;
      if (x.status >= 200 && x.status < 300) { cb(true, (x.responseText || '').replace(/^\s+|\s+$/g, '')); }
      else { cb(false, 'ERR|HTTP ' + x.status); }
    }
    x.timeout = 45000;
    x.onreadystatechange = /* Die fertige HTTP-Antwort weitergeben. */ function () { if (x.readyState === 4) { done(); } };
    x.onerror = x.ontimeout = x.onabort = done;
    try { x.send(formBody(params)); } catch (e) { if (!finished) { finished=true; cb(false, 'ERR|' + e.message); } }
  }
  // Den nächsten Schreibvorgang ausführen.
  function nextWrite() {
    if (writing || !writes.length) { return; }
    writing = true;
    var item = writes.shift(), retries = 0;
    // Eine belegte Schreibsperre erneut anfragen.
    function attempt() {
      sendApi(item.params, function (ok, text) {
        if (ok && text.indexOf('BUSY|') === 0 && retries < 4) {
          win.setTimeout(attempt, [100,250,500,1000][retries++]); return;
        }
        try { item.cb(ok, text); }
        finally { writing = false; nextWrite(); }
      });
    }
    attempt();
  }
  PEP.api = /* Leseanfragen direkt und Schreibanfragen nacheinander senden. */ function (params, cb) {
    if (/^(ping|settings_get|desc_get|program_dates|favorites_get|editor_settings|editor_device|filters_settings|useraccount_settings|programgroups_settings|sysvargroups_settings|groups_get|groups_catalog)$/.test(params.op)) { sendApi(params, cb); return; }
    writes.push({params:params,cb:cb}); nextWrite();
  };

  PEP.refreshSettings = /* Die gespeicherten Einstellungen der CCU abfragen. */ function () {
    if(!PEP.sid()){return;}
    var revision=settingsRevision,request=++settingsRequest;
    PEP.api({op:'settings_get'},function(ok,text){
      if(revision!==settingsRevision||request!==settingsRequest){return;}
      var fields=text.split('|'),keys=['sorting','infos','favorites','programids','programsort','printnotes','themes'];
      if(!ok||fields[0]!=='OK'||fields.length!==8){return;}
      var flags={};keys.forEach(function(k,i){flags[k]=fields[i+1]==='1';});PEP.applySettings(flags);
    });
  };
  win.addEventListener('focus',function(){PEP.refreshSettings();});
  doc.addEventListener('visibilitychange',function(){if(!doc.hidden){PEP.refreshSettings();}});
  PEP.refreshSettings();

  var timer = null;
  win.addEventListener('resize',schedule);
  // Mehrere DOM-Änderungen zu einer Aktualisierung bündeln.
  function schedule() {
    if (timer) { return; }
    timer = win.setTimeout(function () {
      timer = null;
      if (PEP.drag && (PEP.drag.active || PEP.drag.pending)) { schedule(); return; }   
      try { if (PEP.scan) { PEP.scan(); } } catch (e) { if (win.console) { win.console.error('Enhanced WebUI: ' + e); } }
      try { scanOverviews(); } catch(e) { if(win.console){win.console.error('Enhanced WebUI Übersicht: '+e);} }
      try { if(PEP.theme){PEP.theme.refresh();} } catch(ignore) {}
      if (obs) { obs.takeRecords(); }
    }, 80);
  }
  var obs = null;
  if (win.MutationObserver) {
    obs = new win.MutationObserver(schedule);
    obs.observe(doc.documentElement, { childList: true, subtree: true });
  } else {
    win.setInterval(schedule, 700);
  }

  if (!doc.getElementById('pep-css')) {
    var link = el('link');
    link.id = 'pep-css';
    link.rel = 'stylesheet';
    link.href = BASE + 'ewebui.css?v=' + VERSION;
    (doc.head || doc.documentElement).appendChild(link);
  }
  schedule();

  PEP.schedule = schedule;
  // Funktionsdateien nacheinander laden, damit Erweiterungen auf langsamen CCUs
  // erst nach den gemeinsam benötigten Hilfsfunktionen ausgeführt werden.
  function loadQueue(queue) {
    if (!queue.length) { return; }
    var item = queue.shift(), element = el(item.css ? 'link' : 'script');
    var url = BASE + item.name + '?v=' + encodeURIComponent(item.version);
    if (item.css) {
      element.rel = 'stylesheet'; element.href = url;
      (doc.head || doc.documentElement).appendChild(element);
      loadQueue(queue);
      return;
    }
    element.charset = 'UTF-8'; element.async = false; element.src = url;
    element.onload = element.onerror = function () { loadQueue(queue); };
    (doc.head || doc.documentElement).appendChild(element);
  }

  var queue = [
    {name:'session-view.js', version:VERSION},
    {name:'basis-settings.js', version:VERSION}
  ];
  if (PEP.packages.editor || PEP.packages.mobile) { queue.push({name:'text-editor.js', version:VERSION}); }
  var assets = {
    editor: ['program-editor.js','program-editor.css'],
    groups: ['program-groups.js','groups.css'],
    filters: ['filters.js','filters.css'],
    columns: ['program-columns.js','columns.css'],
    script: ['script-editor.js','script-errors.js','script.css'],
    mobile: win.__EWUI_MOBILE_LOADING__ || win.__EWUI_MOBILE__ ? [] : ['mobile.js'],
    favorites: ['favorite-sorting.js','favorites.css'],
    account: ['user-account.js','account.css'],
    theme: win.__EWUI_THEME_LOADING__ || win.__EWUI_THEME__ ? [] : ['theme.js']
  };
  Object.keys(assets).forEach(function (module) {
    if (!PEP.packages[module]) { return; }
    assets[module].forEach(function (file) {
      queue.push({name:file, version:PEP.packages[module], css:file.endsWith('.css')});
    });
  });
  loadQueue(queue);
})(window);
