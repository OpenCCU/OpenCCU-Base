# Enhanced WebUI Basis

Installiert den gemeinsamen WebUI-Zugang und die Einstellungen der Funktionspakete.
Die Basis zuerst installieren. Funktionspakete vor der Basis deinstallieren.
