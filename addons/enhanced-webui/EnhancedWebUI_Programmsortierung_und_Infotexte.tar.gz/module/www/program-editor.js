// Programmeditor und Infotexte in der nativen WebUI ergänzen.
(function (win) {
  'use strict';
  var doc = win.document, PEP = win.__PEP__;
  if (!PEP || PEP.scan) { return; }
  var schedule = PEP.schedule;
  // Ein Element im angegebenen Bereich suchen.
  function $(sel, root) { return (root || doc).querySelector(sel); }
  // Alle passenden Elemente im Bereich sammeln.
  function $all(sel, root) { return Array.prototype.slice.call((root || doc).querySelectorAll(sel)); }
  // Ein DOM-Element erzeugen.
  function el(tag, cls, text) {
    var e = doc.createElement(tag);
    if (cls) { e.className = cls; }
    if (text !== undefined) { e.textContent = text; }
    return e;
  }
  // Ein Attribut auslesen.
  function attr(node, name) { return (node && node.getAttribute && node.getAttribute(name)) || ''; }

  var S = PEP.state = {
    container: null,      
    origId: '',           
    stored: null,         
    storedCount: null,
    storedApplied: false,
    metadataLoading: false,
    metadataFailed: false,
    pendingNotes: null,
    desc: {},             
    settled: false,
    settleTimer: null,
    seenRules: {},
    showAll: false,
    sortChanged: false,
    busy: false,
    poisoned: false,
    loadingRules: null,
    reloads: null,
    awaitingReload: false,
    reloadGeneration: 0,
    copyId: '',
    generation: 0,
    model: null
  };

  // Den Zustand beim Wechsel des Programms zurücksetzen.
  function resetState(container) {
    if(S.branchSizer){S.branchSizer.disconnect();S.branchSizer=null;}
    if(container&&win.ResizeObserver){S.branchSizer=new win.ResizeObserver(schedule);S.branchSizer.observe(container);}
    S.generation++;
    S.container = container;
    S.origId = '';
    S.stored = null;
    S.storedCount = null;
    S.storedApplied = false;
    S.metadataLoading = false;
    S.metadataFailed = false;
    S.pendingNotes = null;
    S.desc = {};
    S.settled = false;
    S.seenRules = {};
    S.showAll = false;
    S.sortChanged = false;
    S.busy = false;
    S.poisoned = false;
    S.loadingRules = null;
    S.reloads = null;
    S.awaitingReload = false;
    S.copyId = '';
    S.model = null;
    if (S.settleTimer) { win.clearTimeout(S.settleTimer); S.settleTimer = null; }
  }

  // Die vom Originaleditor gerenderte Programmstruktur erfassen.
  function readModel(container) {
    var m = { rules: [], containers: [] };
    var ruleEls = [];
    Array.prototype.forEach.call(container.children, function (c) {
      if (c.nodeType === 1 && /^rule\d+$/.test(c.id || '')) { ruleEls.push(c); }
    });
    ruleEls.forEach(function (re, ri) {
      var rid = re.id.replace('rule', '');
      var hasCond = !!$('img[onclick*="AddCondition("]', re);
      var rule = { rid: rid, el: re, index: ri, conditional: hasCond, kind: '' };
      if (hasCond) { rule.kind = ri === 0 ? 'if' : 'elseif'; }
      else if (ri > 0) { rule.kind = 'else'; }
      rule.groups = [];
      rule.did = '';
      $all('img[onclick*="AddSingleCondition("]', re).forEach(function (img) {
        var mm = /AddSingleCondition\(\s*(\d+)\s*,\s*(\d+)\s*\)/.exec(attr(img, 'onclick'));
        if (!mm) { return; }
        var groupEl = img.parentNode && img.parentNode.parentNode;
        if (!groupEl || groupEl === re) { return; }
        var singles = [];
        $all('span[id^="sico"]', groupEl).forEach(function (sp) {
          if (!/^sico\d+$/.test(sp.id)) { return; }
          singles.push({ id: sp.id.replace('sico', ''), el: sp.parentNode });
        });
        rule.groups.push({ cid: mm[2], el: groupEl, singles: singles });
      });
      var acts = [];
      $all('img[onclick*="AddSingleDestination("]', re).forEach(function (img) {
        var mm = /AddSingleDestination\(\s*(\d+)\s*,\s*(\d+)\s*\)/.exec(attr(img, 'onclick'));
        if (mm && !rule.did) { rule.did = mm[2]; }
      });
      $all('span[id^="side"]', re).forEach(function (sp) {
        if (!/^side\d+$/.test(sp.id)) { return; }
        acts.push({ id: sp.id.replace('side', ''), el: sp.parentNode });
      });
      rule.acts = acts;
      // Ein leerer SONST-Teil kann im letzten bedingten Zweig stehen. Er gehört trotzdem nicht zur sortierbaren Fläche.
      var emptyMarker=$('img[onclick*="AddSubRuleDest("]',re);
      rule.emptyElse=emptyMarker&&emptyMarker.closest('.Rule');
      if(rule.emptyElse&&rule.emptyElse.parentNode!==re){rule.emptyElse=null;}
      m.rules.push(rule);
    });

    var cond = m.rules.filter(function (r) { return r.conditional; });
    var elseRule = null;
    m.rules.forEach(function (r) { if (r.kind === 'else') { elseRule = r; } });
    if (cond.length >= 1) {
      m.containers.push({ type: 'branches', key: 'branches', label: 'Zweig',
        items: cond.map(function (r) { return { id: r.rid, el: r.el }; }),
        rids: cond.map(function (r) { return r.rid; }),
        forbid: (elseRule ? [elseRule.el] : []).concat(m.rules.filter(function(r){return r.emptyElse;}).map(function(r){return r.emptyElse;})) });
    }
    m.rules.forEach(function (r) {
      if (r.groups.length >= 2) {
        m.containers.push({ type: 'groups', key: 'groups' + r.rid, label: 'Bedingungsgruppe',
          rid: r.rid, items: r.groups.map(function (g) { return { id: g.cid, el: g.el }; }), forbid: [] });
      }
      r.groups.forEach(function (g) {
        if (g.singles.length >= 1) {
          m.containers.push({ type: 'conds', key: 'conds' + g.cid, label: 'Bedingung',
            rid: r.rid, cid: g.cid, items: g.singles, forbid: [] });
        }
      });
      if (r.acts.length >= 1 && r.did) {
        m.containers.push({ type: 'acts', key: 'acts' + r.did, label: 'Aktion',
          rid: r.rid, did: r.did, items: r.acts, forbid: [] });
      }
    });
    return m;
  }
  PEP.readModel = readModel;

  // Einen Ziehgriff erzeugen.
  function makeHandle(title) {
    var h = el('span', 'pep-handle');
    h.title = title;
    h.setAttribute('data-pep', 'handle');
    return h;
  }

  // Einen sortierbaren Eintrag kennzeichnen.
  function decorateItem(item, cont, where) {
    var node = item.el;
    if (!node) { return; }
    if (node.querySelector && node.querySelector(':scope > .pep-handle')) { return; }
    var h = makeHandle(cont.label + ' per Drag-and-Drop verschieben');
    h.setAttribute('data-pep-key', cont.key);
    h.setAttribute('data-pep-id', item.id);
    if (cont.type === 'groups') {
      if (node.querySelector(':scope > .pep-groupbar')) { return; }
      var groupbar=el('div','pep-groupbar');
      h.classList.add('pep-group-handle'); h.textContent='↕ Logische Gruppe';
      groupbar.appendChild(h); node.insertBefore(groupbar,node.firstChild);
    } else { node.insertBefore(h, node.firstChild); }
    node.setAttribute('data-pep-item', cont.key);
    if(cont.type==='groups'){node.setAttribute('data-pep-group',item.id);}
  }

  var NOTE_LIMIT = 2000;
  // Den Infotext zum Eintrag ermitteln.
  function descOf(key) {
    if (!S.desc[key]) { S.desc[key] = { text: '', open: false, touched: false }; }
    return S.desc[key];
  }
  // Die bedingten Programmzweige zusammenstellen.
  function branchList(model) {
    return model.rules.filter(function (r) { return r.kind; });
  }
  // Zweige, Bedingungen und Aktionen mit Infotexten sammeln.
  function noteEntities(model) {
    var all = [];
    branchList(model).forEach(function (rule, b) {
      all.push({key:rule.rid, kind:'r', b:b, index:0, rule:rule, el:rule.el});
      var index = 0;
      rule.groups.forEach(function (group) {
        group.singles.forEach(function (item) {
          all.push({key:'c'+item.id, kind:'c', b:b, index:index++, rule:rule, el:item.el});
        });
      });
      rule.acts.forEach(function (item, i) {
        all.push({key:'a'+item.id, kind:'a', b:b, index:i, rule:rule, el:item.el});
      });
    });
    return all;
  }
  PEP.noteEntities = noteEntities;
  // Geladene Infotexte den sichtbaren Einträgen zuordnen.
  function applyStored(model) {
    if (!S.stored || S.storedApplied || branchList(model).length !== S.storedCount) { return; }
    noteEntities(model).forEach(function (entity) {
      var d = descOf(entity.key), text = S.stored[entity.kind+'|'+entity.b+'|'+entity.index];
      if (!d.touched && text !== undefined && d.text === '') { d.text = text; }
      if (S.showAll && d.text !== '') { d.open = true; }
    });
    S.storedApplied = true;
  }
  // Den Platz für den Infotext ermitteln.
  function noteHost(entity) {
    return entity.kind === 'r' ? entity.el.querySelector(':scope > .pep-branchbar') : entity.el;
  }
  // Symbol und Textanzeige aktualisieren.
  function refreshNote(entity) {
    var host = noteHost(entity);
    if (!host) { return; }
    var control = host.querySelector(':scope > .pep-note');
    if (!control) { return; }
    var d = descOf(entity.key), icon = control.querySelector('.pep-info');
    icon.className = 'pep-info' + (d.text !== '' ? ' pep-info-has' : '') + (d.open ? ' pep-info-open' : '');
    icon.setAttribute('aria-expanded', d.open ? 'true' : 'false');
    icon.title = (d.text ? 'Infotext anzeigen/ausblenden' : 'Infotext hinzufügen') + ' (max. '+NOTE_LIMIT+' Zeichen)';
    control.querySelector('.pep-desc').style.display = d.open ? 'block' : 'none';
    var ta = control.querySelector('textarea');
    if (doc.activeElement !== ta && ta.value !== d.text) { ta.value = d.text; }
    control.querySelector('.pep-count').textContent = ta.value.length+' / '+NOTE_LIMIT+' Zeichen'+(ta.value.length>NOTE_LIMIT?' – vorhandener längerer Text bleibt unverändert erhalten; Änderungen bitte kürzen':'');
  }
  // Infotextsymbol und Bearbeitung bereitstellen.
  function ensureNote(entity) {
    var host = noteHost(entity);
    if (!host) { return; }
    var control = host.querySelector(':scope > .pep-note');
    if (!control) {
      control = el('span', 'pep-note');
      control.setAttribute('data-pep-note',entity.key);
      var icon = el('button', 'pep-info', 'i');
      icon.type = 'button';
      icon.addEventListener('click',function () {
        if(PEP.openTextEditor){var note=descOf(entity.key);PEP.openTextEditor({title:'Infotext',value:note.text,limit:NOTE_LIMIT,apply:/* Den übernommenen Text im Editor vormerken. */ function(text){if(text.length>NOTE_LIMIT&&text!==note.text){return 'Maximal '+NOTE_LIMIT+' Zeichen.';}if(text!==note.text){note.text=text;note.touched=true;}refreshNote(entity);}});return;}
        var d=descOf(entity.key); d.open=!d.open; refreshNote(entity);
        if(d.open){control.querySelector('textarea').focus();}
      });
      var box=el('span','pep-desc'), ta=el('textarea','pep-desc-text');
      ta.rows=3; ta.maxLength=NOTE_LIMIT;
      ta.placeholder='Infotext (max. '+NOTE_LIMIT+' Zeichen; wird separat im Add-on gespeichert)';
      ta.setAttribute('aria-label','Infotext, maximal '+NOTE_LIMIT+' Zeichen');
      ta.addEventListener('input',function () {
        var d=descOf(entity.key); d.text=ta.value; d.touched=true; refreshNote(entity);
      });
      box.appendChild(ta); box.appendChild(el('span','pep-count',''));
      control.appendChild(icon); control.appendChild(box); host.appendChild(control);
    }
    refreshNote(entity);
  }
  // Die Sichtbarkeit aller Infotexte aktualisieren.
  function refreshInfo(rule) {
    if (S.model) { noteEntities(S.model).filter(function (e) { return e.rule.rid === rule.rid; }).forEach(refreshNote); }
  }
  // Die senkrechte Leiste eines Programmzweigs erstellen.
  function buildBranchBar(rule) {
    var bar=el('div','pep-branchbar'); bar.setAttribute('data-pep','branchbar');
    if(rule.conditional){
      var h=makeHandle('Programmzweig verschieben');
      h.setAttribute('data-pep-key','branches'); h.setAttribute('data-pep-id',rule.rid);
      bar.appendChild(h);
    } else if(rule.kind==='else'){
      bar.classList.add('pep-branchbar-else');
      bar.title='Der SONST-Zweig ist fest und bleibt als bedingungsloser Abschluss am Ende. Seine Aktivitäten lassen sich sortieren.';
      var locked=el('span','pep-handle pep-locked');
      locked.title='SONST bleibt als bedingungsloser Abschluss am Ende';
      locked.setAttribute('aria-disabled','true'); if(rule.acts.length){bar.appendChild(locked);}
    }
    var label=el('span','pep-branchlabel',{'if':'WENN','elseif':'SONST, WENN','else':'SONST'}[rule.kind]);
    label.title=label.textContent;
    bar.appendChild(label);
    rule.el.classList.add('pep-branchrail');
    rule.el.insertBefore(bar,rule.el.firstChild);
    return bar;
  }
  // Infotexte für eine bevorstehende Sortierung sichern.
  function snapshotNotes(model) {
    var data=branchList(model).map(function () { return {r:[],c:[],a:[]}; });
    noteEntities(model).forEach(function (e) {
      var d=descOf(e.key); data[e.b][e.kind][e.index]={text:d.text,open:d.open,touched:true};
    });
    return data;
  }
  // Infotexte nach dem Neuladen der Zweige wieder zuordnen.
  function restoreNotes(model,data) {
    S.desc={};
    noteEntities(model).forEach(function (e) {
      var d=data[e.b] && data[e.b][e.kind][e.index];
      if(d){S.desc[e.key]=d;}
    });
  }

  // Die Werkzeugleiste des Programmeditors einhängen.
  function ensureToolbar(container) {
    var tb = doc.getElementById('pep-toolbar');
    if (tb) { return tb; }
    tb = el('div', 'pep-toolbar');
    tb.id = 'pep-toolbar';
    var lab = el('label', 'pep-showall');
    var cb = doc.createElement('input');
    cb.type = 'checkbox';
    cb.id = 'pep-showall';
    cb.addEventListener('change', function () {
      S.showAll = cb.checked;
      if (S.model) {
        noteEntities(S.model).forEach(function (r) {
          var d = descOf(r.key);
          d.open = S.showAll && d.text !== '';
          refreshNote(r);
        });
      }
    });
    lab.appendChild(cb);
    lab.appendChild(doc.createTextNode(' Alle Infotexte aufklappen'));
    tb.appendChild(lab);
    var st = el('span', 'pep-status', '');
    st.id = 'pep-status';
    tb.appendChild(st);
    container.parentNode.insertBefore(tb, container);
    return tb;
  }

  var SORT_NOTICE = 'Letzte Sortieränderung übernommen. Mit "OK" speichern, mit "Zurück" abbrechen.';
  // Eine Rückmeldung zur Sortierung anzeigen.
  function setStatus(msg, bad) {
    var st = doc.getElementById('pep-status');
    if (!st) { return; }
    msg = msg || (S.sortChanged ? SORT_NOTICE : '');
    st.textContent = msg;
    st.title = msg || '';   
    st.className = 'pep-status' + (bad ? ' pep-bad' : '');
    if (msg && !bad && msg !== SORT_NOTICE) {
      win.setTimeout(function () { if (st.isConnected && st.textContent === msg) { setStatus(''); } }, 4000);
    }
  }
  PEP.setStatus = setStatus;

  PEP.scan = /* Den Programmeditor erkennen und ergänzen. */ function () {
    installSaveObserver();
    var container = doc.getElementById('prgrulecontent');
    if (!container) {
      if (S.container) { resetState(null); }
      return;
    }
    if (S.container !== container) { resetState(container); }
    ensureToolbar(container);
    if(S.sortChanged && !S.busy && !doc.getElementById('pep-status').textContent){setStatus(SORT_NOTICE);}
    var m = S.model = readModel(container);
    if(S.awaitingReload){
      if(S.reloads && Object.keys(S.reloads).length){return;}
      S.awaitingReload=false;S.busy=false;
    }
    if (S.loadingRules) {
      var actual = m.rules.map(function (r) { return r.rid; }).join(',');
      if (actual !== S.loadingRules.join(',')) { return; }
      S.loadingRules = null;
      S.busy = false;
      if(S.pendingNotes){restoreNotes(m,S.pendingNotes);S.pendingNotes=null;}
    }

    if (!S.origId) {
      var okBtn = $('[onclick*="SaveProgramEdit("]');
      var mm = okBtn && /SaveProgramEdit\(\s*(\d+)\s*,\s*(\d+)\s*\)/.exec(attr(okBtn, 'onclick'));
      if (mm) { S.origId = mm[1]; S.copyId = mm[2]; loadStored(); }
    }

    m.rules.forEach(function (r) {
      if (!S.seenRules[r.rid]) {
        S.seenRules[r.rid] = true;
        if (!S.settled) {
          if (S.settleTimer) { win.clearTimeout(S.settleTimer); }
          S.settleTimer = win.setTimeout(function () { S.settled = true; }, 2000);
        }
      }
    });
    applyStored(m);

    branchList(m).forEach(function (r) {
      if (!r.el.querySelector(':scope > .pep-branchbar')) { buildBranchBar(r); }
      var bar=r.el.querySelector(':scope > .pep-branchbar'),tailHeight=0;
      if(r.emptyElse){
        r.emptyElse.classList.add('pep-empty-else');
        tailHeight=Math.max(0,r.el.getBoundingClientRect().bottom-r.emptyElse.getBoundingClientRect().top);
      }
      r.el.style.setProperty('--pep-tail-height',tailHeight+'px');
      bar.style.bottom=(tailHeight+3)+'px';
      refreshInfo(r);
    });
    noteEntities(m).forEach(ensureNote);

    m.containers.forEach(function (c) {
      if (c.type === 'branches') { return; }   
      c.items.forEach(function (it) { decorateItem(it, c); });
    });
  };

  // Gespeicherte Infotexte abrufen.
  function loadStored() {
    if (!S.origId) { return; }
    S.metadataLoading = true;
    var generation = S.generation;
    PEP.api({ op: 'desc_get', pid: S.origId }, function (ok, text) {
      if (generation !== S.generation) { return; }
      S.metadataLoading = false;
      if (!ok || text.indexOf('OK|') !== 0) { S.metadataFailed=true; setStatus('Infotexte konnten nicht geladen werden. Zum Sortieren bitte Editor neu öffnen.',true); return; }
      var map = {};
      text.split('\n').slice(1).forEach(function (line) {
        var p = line.split('\t');
        if (p.length === 2 && /^[rca]\|\d+\|\d+$/.test(p[0])) {
          try { map[p[0]] = decodeURIComponent(p[1]); } catch (e) {    }
        }
      });
      S.stored = map;
      S.storedCount = parseInt(text.split('\n')[0].split('|')[1], 10);
      if (S.model) { applyStored(S.model); S.model.rules.forEach(function (r) { if (r.kind) { refreshInfo(r); } }); }
    });
  }

  PEP.movePerm = /* Die neue Reihenfolge aus Quell- und Zielposition berechnen. */ function (n, from, insertBefore) {
    var order = [], i;
    for (i = 0; i < n; i++) { order.push(i); }
    var item = order.splice(from, 1)[0];
    var to = insertBefore > from ? insertBefore - 1 : insertBefore;
    order.splice(to, 0, item);
    return order;
  };

  // Prüfen, ob sich die Reihenfolge überhaupt ändert.
  function isIdentity(perm) {
    return perm.every(function (v, i) { return v === i; });
  }

  // Die betroffenen Zweige mit dem Originaleditor neu laden.
  function reloadRules(rids) {
    if(!rids.length){return;}
    S.busy=true;S.awaitingReload=true;S.reloadGeneration=S.generation;S.reloads={};
    rids.forEach(function(rid){S.reloads[rid]=true;});
    rids.forEach(function (rid) {
      if (typeof win.ReloadRule === 'function') { win.ReloadRule(rid); }
    });
  }

  // Die neue Reihenfolge auf der Arbeitskopie anwenden lassen.
  function request(cont, perm) {
    if (S.busy || S.poisoned || S.metadataFailed || !PEP.settings.sorting) { return; }
    var generation = S.generation;
    // Die CCU gleicht die Ausgangsreihenfolge ab und sortiert nur die Arbeitskopie des Editors.
    var p = { op: 'reorder', kind: cont.type, perm: perm.join(','),
      expected: cont.items.map(function (it) { return it.id; }).join(',') };
    var affected;
    if (cont.type === 'branches') { p.rids = cont.rids.join(','); affected = cont.rids.filter(function (r, i) { return perm[i] !== i; }); }
    else if (cont.type === 'groups') { p.rid = cont.rid; affected = [cont.rid]; }
    else if (cont.type === 'conds') { p.rid = cont.rid; p.cid = cont.cid; affected = [cont.rid]; }
    else { p.rid = cont.rid; p.did = cont.did; affected = [cont.rid]; }

    S.busy = true;
    setStatus('Reihenfolge wird gespeichert \u2026');
    PEP.api(p, function (ok, text) {
      if (generation !== S.generation) { return; }
      S.busy = false;
      var status = text.split('|')[0];
      if (ok && status === 'OK') {
        if (cont.type === 'branches') {
          var fields = text.split('|');
          var newIds = (fields[3] || '').split(',');
          if (!/^\d+$/.test(fields[1] || '') || !/^\d+$/.test(fields[2] || '') ||
              newIds.length !== S.model.rules.length || newIds.some(function (id) { return !/^\d+$/.test(id); })) {
            S.poisoned = true;
            setStatus('Serverantwort unvollstaendig. Bearbeitung bitte abbrechen.', true);
            return;
          }
          // Beim Kopieren bekommen Zweige neue IDs. Die Infotexte folgen deshalb der Reihenfolge.
          var oldDesc = snapshotNotes(S.model);
          S.desc = {};
          S.pendingNotes = newIds.map(function(id,i){return oldDesc[i < perm.length ? perm[i] : i];});
          S.settled = true;
          S.stored = null;
          S.loadingRules = newIds;
          S.busy = true;
          S.container.innerHTML = '';
          win.LoadRule(fields[1], fields[2]);
        } else {
          var previousItems = cont.items;
          cont.items = perm.map(function (index) { return previousItems[index]; });
          reloadRules(affected);
        }
        S.sortChanged = true;
        setStatus(SORT_NOTICE);
      } else if (status === 'POSTFAIL') {
        S.poisoned = true;
        reloadRules(affected);
        win.alert('Enhanced WebUI: Die Reihenfolge konnte nach dem Schreiben nicht best\u00e4tigt werden.\n\n' +
          text.split('|').slice(1).join('|') +
          '\n\nBitte pr\u00fcfen Sie das Programm. Mit \u201eAbbrechen\u201c im Editor wird die Bearbeitung verworfen, das Original bleibt unver\u00e4ndert.');
        setStatus('Reihenfolge nicht best\u00e4tigt \u2013 bitte pr\u00fcfen oder abbrechen.', true);
      } else {
        if (!ok) { S.poisoned = true; }
        reloadRules(affected);
        setStatus('Nicht verschoben: ' + (text.split('|').slice(1).join('|') || 'Fehler') + '', true);
      }
    });
  }
  PEP.request = request;

  var D = PEP.drag = { active: false, pending: null, ghost: null, cont: null, from: -1, insert: -1, valid: false };

  // Vorherige Ziehmarkierungen entfernen.
  function clearMarks() {
    $all('.pep-drop-before, .pep-drop-after, .pep-drop-invalid').forEach(function (n) {
      n.classList.remove('pep-drop-before'); n.classList.remove('pep-drop-after'); n.classList.remove('pep-drop-invalid');
    });
  }

  // Den Sortierbereich für einen Eintrag finden.
  function containerFor(handle) {
    if (!S.model) { return null; }
    var key = attr(handle, 'data-pep-key');
    for (var i = 0; i < S.model.containers.length; i++) {
      if (S.model.containers[i].key === key) { return S.model.containers[i]; }
    }
    return null;
  }

  // Die Position eines Ziehziels bestimmen.
  function rectOf(n) {
    var r=n.getBoundingClientRect(),tail=n.querySelector(':scope > .pep-empty-else');
    if(!tail){return r;}
    var bottom=Math.min(r.bottom,tail.getBoundingClientRect().top);
    return {top:r.top,bottom:bottom,left:r.left,right:r.right,width:r.width,height:bottom-r.top};
  }

  D.start = /* Das Ziehen am Griff beginnen. */ function (handle, x, y) {
    if (S.busy || S.poisoned || S.metadataLoading || S.metadataFailed || !PEP.settings.sorting || handle.classList.contains('pep-locked')) { return false; }
    var cont = containerFor(handle);
    if (!cont || cont.items.length < 2) { return false; }
    var id = attr(handle, 'data-pep-id');
    var from = -1;
    cont.items.forEach(function (it, i) { if (it.id === id) { from = i; } });
    if (from < 0) { return false; }
    D.pending = { cont: cont, from: from, x: x, y: y, handle: handle };
    return true;
  };

  D.move = /* Ziehvorschau und Zielposition aktualisieren. */ function (x, y) {
    if (!D.pending && !D.active) { return; }
    if (!D.active) {
      if (Math.abs(x - D.pending.x) + Math.abs(y - D.pending.y) < 6) { return; }   
      D.active = true;
      D.cont = D.pending.cont;
      D.from = D.pending.from;
      D.ghost = el('div', 'pep-ghost', D.cont.label);
      doc.body.appendChild(D.ghost);
      D.cont.items[D.from].el.classList.add('pep-dragging');
      doc.body.classList.add('pep-dragmode');
    }
    D.ghost.style.left = (x + 12) + 'px';
    D.ghost.style.top = (y + 12) + 'px';
    clearMarks();
    D.valid = false;
    D.insert = -1;
    var cont = D.cont, items = cont.items, i, r;

    for (i = 0; i < cont.forbid.length; i++) {
      r = rectOf(cont.forbid[i]);
      if (y >= r.top && y <= r.bottom) {
        cont.forbid[i].classList.add('pep-drop-invalid');
        D.ghost.className = 'pep-ghost pep-ghost-bad';
        D.ghost.textContent = 'SONST bleibt am Ende';
        return;
      }
    }
    var sameKind = S.model.containers.filter(function (c) { return c.type === cont.type && c.key !== cont.key; });
    for (i = 0; i < sameKind.length; i++) {
      var first = rectOf(sameKind[i].items[0].el), last = rectOf(sameKind[i].items[sameKind[i].items.length - 1].el);
      if (y >= first.top && y <= last.bottom) {
        sameKind[i].items.forEach(function (it) { it.el.classList.add('pep-drop-invalid'); });
        D.ghost.className = 'pep-ghost pep-ghost-bad';
        D.ghost.textContent = cont.type === 'conds' ? 'Bedingungen bleiben in ihrer Gruppe; kein Wechsel zwischen Zweigen' : cont.type === 'acts' ? 'Aktionen bleiben im selben DANN-/SONST-Bereich' : 'Bedingungsgruppen bleiben im selben Zweig';
        return;
      }
    }
    D.ghost.className = 'pep-ghost';
    D.ghost.textContent = cont.label;

    var ins = items.length;
    for (i = 0; i < items.length; i++) {
      r = rectOf(items[i].el);
      if (y < r.top + r.height / 2) { ins = i; break; }
    }
    var firstR = rectOf(items[0].el), lastR = rectOf(items[items.length - 1].el);
    var margin = 40;
    if (y < firstR.top - margin || y > lastR.bottom + margin ||
        x < Math.min(firstR.left, lastR.left) - margin || x > Math.max(firstR.right, lastR.right) + margin) { return; }
    D.insert = ins;
    D.valid = !(ins === D.from || ins === D.from + 1);   
    if (ins < items.length) { items[ins].el.classList.add('pep-drop-before'); }
    else { items[items.length - 1].el.classList.add('pep-drop-after'); }
  };

  D.cancel = /* Eine laufende Ziehbewegung aufräumen. */ function () {
    clearMarks();
    if (D.ghost && D.ghost.parentNode) { D.ghost.parentNode.removeChild(D.ghost); }
    if (D.cont && D.from >= 0 && D.cont.items[D.from]) { D.cont.items[D.from].el.classList.remove('pep-dragging'); }
    doc.body.classList.remove('pep-dragmode');
    D.active = false; D.pending = null; D.ghost = null; D.cont = null; D.from = -1; D.insert = -1; D.valid = false;
  };

  D.end = /* Das Ziehen abschließen und die Änderung anfordern. */ function (x, y) {
    var wasActive = D.active;
    var cont = D.cont, from = D.from, ins = D.insert, valid = D.valid;
    D.cancel();
    if (!wasActive || !valid || ins < 0) { return false; }
    var perm = PEP.movePerm(cont.items.length, from, ins);
    if (isIdentity(perm)) { return false; }
    request(cont, perm);
    return true;
  };

  doc.addEventListener('pointerdown', function (e) {
    if (e.button !== undefined && e.button !== 0) { return; }
    var h = e.target && e.target.closest && e.target.closest('.pep-handle');
    if (!h) { return; }
    if (D.start(h, e.clientX, e.clientY)) { e.preventDefault(); }
  }, true);
  doc.addEventListener('pointermove', function (e) {
    if (D.pending || D.active) { D.move(e.clientX, e.clientY); if (D.active) { e.preventDefault(); } }
  }, true);
  doc.addEventListener('pointerup', function (e) {
    if (D.active) { D.end(e.clientX, e.clientY); e.preventDefault(); }
    else { D.pending = null; }
  }, true);
  doc.addEventListener('pointercancel', function () { D.cancel(); }, true);
  doc.addEventListener('keydown', function (e) { if (e.key === 'Escape' && (D.active || D.pending)) { D.cancel(); } }, true);

  PEP.descItems = /* Geänderte Infotexte für die Speicherung sammeln. */ function () {
    if (!S.model) { return []; }
    return branchList(S.model).map(function (r) { return descOf(r.rid).text; });
  };

  PEP.persistDescriptions = /* Infotexte nach dem Programmspeichern sichern. */ function (save, done) {
    PEP.api({ op: 'desc_set', pid: save.pid, copy: save.copy, notes: save.notes }, function (ok, text) {
      if (!ok || text.indexOf('OK') !== 0) {
        win.alert('Enhanced WebUI: Die Beschreibungen konnten nicht gespeichert werden.\n' + text);
      }
      if (done) { done(); }
    });
  };

  // Infotexte werden erst nach der bestätigten Speicherung durch die WebUI dauerhaft übernommen.
  // Die Originalanfrage zum Speichern beobachten.
  function installSaveObserver() {
    if (PEP.saveObserver || !win.Ajax || !win.Ajax.Responders) { return; }
    PEP.saveObserver = true;
    win.Ajax.Responders.register({ onComplete: /* Die Originalantwort an die WebUI weitergeben und prüfen. */ function (request) {
      if (String(request.url || '').indexOf('/esp/programs.htm') < 0) { return; }
      var body = String(request.options && request.options.postBody || '');
      try { body = win.unescape(body); } catch (ignore) {    }
      if(S.awaitingReload && S.reloadGeneration===S.generation && body.indexOf('"ReloadRule"')>=0){
        var match=/string rid\s*=\s*"(\d+)"/.exec(body);
        if(match && S.reloads){delete S.reloads[match[1]];schedule();}
      }
      var save = PEP.pendingSave;
      if(!save){return;}
      if (body.indexOf('RestoreProgram') < 0 || body.indexOf('"' + save.copy + '"') < 0) { return; }
      PEP.pendingSave = null;
      // Nach bestätigtem Speichern die Infotexte sichern.
      function finished() {
        if (save.generation === S.generation) {
          S.busy = false;
        }
      }
      if (request.transport && request.transport.status >= 200 && request.transport.status < 300) {
        PEP.persistDescriptions(save, finished);
      } else { finished(); }
    } });
  }

  doc.addEventListener('click', function (e) {
    var t = e.target && e.target.closest && e.target.closest('[onclick*="SaveProgramEdit("]');
    if (t && S.container) {
      if (S.busy || S.poisoned || S.metadataLoading) {
        e.preventDefault(); e.stopImmediatePropagation();
        setStatus(S.poisoned ? 'Sortierung unbestaetigt. Bitte Bearbeitung abbrechen.' : 'Bitte das Ende der Sortierung abwarten.', true);
        return;
      }
      if(S.metadataFailed){PEP.pendingSave=null;return;}
      installSaveObserver();
      if (!PEP.saveObserver) {
        e.preventDefault(); e.stopImmediatePropagation();
        setStatus('Originale Speicherfunktion noch nicht verfuegbar.', true);
        return;
      }
      PEP.pendingSave = { pid: S.origId, copy: S.copyId, generation: S.generation,
        notes: noteEntities(S.model).map(function (e) { return e.kind+'|'+e.b+'|'+e.index+'|'+encodeURIComponent(descOf(e.key).text); }).join(',') };
      S.busy = true;
    }
  }, true);

  PEP.scan();
})(window);
