# Prüfen, ob jede Ausgangsposition genau einmal vorkommt.
proc pep_valid_perm {perm n} {
  if {$n < 1 || $n > 1000 || ![regexp {^(0|[1-9][0-9]*)(,(0|[1-9][0-9]*))*$} $perm]} { return 0 }
  set l [split $perm ","]
  if {[llength $l] != $n} { return 0 }
  set seen {}
  foreach x $l {
    if {$x >= $n} { return 0 }
    if {[lsearch -exact $seen $x] >= 0} { return 0 }
    lappend seen $x
  }
  return 1
}

# Den lesenden ReGa-Code für einen Strukturabzug erzeugen.
proc pep_rg_dump {rids {markers 0}} {
  set s "string sEI = \"0\";\nstring sBO = \"0\";\n"
  set k 0
  foreach rid $rids {
    incr k
    append s "object oR$k = dom.GetObject($rid);\n"
    append s "if( oR$k )\n\{\n"
    append s "  object oD$k = oR$k.RuleDestination();\n"
    append s "  sEI = \"0\";\n  if( oR$k.ElseIfFlag() ) \{ sEI = \"1\"; \}\n"
    append s "  sBO = \"0\";\n  if( oD$k.BreakOnRestart() ) \{ sBO = \"1\"; \}\n"
    append s "  Write(\"R|\"#oR$k.ID()#\"|\"#oR$k.RuleParentID()#\"|\"#sEI#\"|\"#oD$k.ID()#\"|\"#sBO#\"\\n\");\n"
    append s "  integer iCnt$k = oR$k.RuleConditions().Count();\n"
    append s "  string sI$k;\n  string sJ$k;\n  string sT$k;\n"
    append s "  if( iCnt$k > 0 )\n  \{\n"
    append s "    foreach( sI$k, system.GenerateEnum(0,(iCnt$k-1)) )\n    \{\n"
    append s "      object oC$k = oR$k.RuleCondition(sI$k);\n"
    append s "      if( oC$k )\n      \{\n"
    append s "        integer iSc$k = oC$k.CndSingleCount();\n"
    append s "        Write(\"C|\"#oR$k.ID()#\"|\"#sI$k#\"|\"#oC$k.ID()#\"|\"#oC$k.CndOperatorType()#\"|\"#iSc$k#\"\\n\");\n"
    append s "        if( iSc$k > 0 )\n        \{\n"
    append s "          foreach( sJ$k, system.GenerateEnum(0,(iSc$k-1)) )\n          \{\n"
    append s "            object oS$k = oC$k.CndSingleCondition(sJ$k);\n"
    append s "            if( oS$k )\n            \{\n"
    append s "              sT$k = \"0\";\n"
    append s "              if( oS$k.LeftValType() == ivtCurrentDate ) \{ sT$k = \"1\"; \}\n"
    append s "              if( oS$k.RightVal1ValType() == ivtObjectId ) \{ sT$k = \"1\"; \}\n"
    append s "              Write(\"S|\"#oC$k.ID()#\"|\"#sJ$k#\"|\"#oS$k.ID()#\"|\"#oS$k.OperatorType()#\"|\"#sT$k#\"\\n\");\n"
    if {$markers} {
      append s "              Write(\"MS|\"#oS$k.ID()#\"|\"#oS$k.RightVal1()#\"\\n\");\n"
    }
    append s "            \}\n          \}\n        \}\n      \}\n    \}\n  \}\n"
    append s "  integer iDc$k = oD$k.DestSingleCount();\n"
    append s "  Write(\"D|\"#oR$k.ID()#\"|\"#oD$k.ID()#\"|\"#iDc$k#\"\\n\");\n"
    append s "  if( iDc$k > 0 )\n  \{\n"
    append s "    string sK$k;\n"
    append s "    foreach( sK$k, system.GenerateEnum(0,(iDc$k-1)) )\n    \{\n"
    append s "      object oE$k = oD$k.DestSingleDestination(sK$k);\n"
    append s "      if( oE$k )\n      \{\n"
    append s "        Write(\"E|\"#oD$k.ID()#\"|\"#sK$k#\"|\"#oE$k.ID()#\"\\n\");\n"
    if {$markers} {
      append s "        Write(\"ME|\"#oE$k.ID()#\"|\"#oE$k.DestinationValue()#\"\\n\");\n"
    }
    append s "      \}\n    \}\n  \}\n"
    append s "\}\n"
  }
  return $s
}

# Vorher eingelesene Strukturmerkmale zurücksetzen.
proc pep_dump_reset {} {
  global D_parent D_ei D_did D_bor D_groups D_gop D_gn D_singles D_sop D_tm D_dsingles D_mark
  foreach v {D_parent D_ei D_did D_bor D_groups D_gop D_gn D_singles D_sop D_tm D_dsingles D_mark} {
    catch {unset ::$v}
  }
}

# Zweige, Bedingungen und Aktionen aus ReGa lesen und zuordnen.
proc pep_dump {rids {markers 0}} {
  global D_parent D_ei D_did D_bor D_groups D_gop D_gn D_singles D_sop D_tm D_dsingles D_mark
  pep_dump_reset
  set out [pep_rega [pep_rg_dump $rids $markers]]
  foreach line [split $out "\n"] {
    set line [string trim $line]
    if {$line == ""} continue
    set f [split $line "|"]
    set t [lindex $f 0]
    if {$t == "R"} {
      set rid [lindex $f 1]
      set D_parent($rid) [lindex $f 2]
      set D_ei($rid)     [lindex $f 3]
      set D_did($rid)    [lindex $f 4]
      set D_bor($rid)    [lindex $f 5]
      set D_groups($rid) {}
    } elseif {$t == "C"} {
      set rid [lindex $f 1]; set cid [lindex $f 3]
      lappend D_groups($rid) $cid
      set D_gop($cid) [lindex $f 4]
      set D_gn($cid)  [lindex $f 5]
      set D_singles($cid) {}
    } elseif {$t == "S"} {
      set cid [lindex $f 1]; set sid [lindex $f 3]
      lappend D_singles($cid) $sid
      set D_sop($sid) [lindex $f 4]
      set D_tm($sid)  [lindex $f 5]
    } elseif {$t == "D"} {
      set did [lindex $f 2]
      set D_dsingles($did) {}
    } elseif {$t == "E"} {
      set did [lindex $f 1]
      lappend D_dsingles($did) [lindex $f 3]
    } elseif {$t == "MS" || $t == "ME"} {
      set D_mark([lindex $f 1]) [lindex $f 2]
    }
  }
  foreach rid $rids {
    if {![info exists D_parent($rid)]} { return 0 }
  }
  return 1
}

# Die Einträge nach den gewünschten Positionen anordnen.
proc pep_permute {lst perm} {
  set out {}
  foreach i [split $perm ,] { lappend out [lindex $lst $i] }
  return $out
}

# Prüfen, ob die Arbeitskopie noch dem Stand im Browser entspricht.
proc pep_expected {ids} {
  set expected [pep_param expected]
  return [expr {$expected == "" || $expected == [join $ids ,]}]
}

# Den ReGa-Code zur Prüfung der beteiligten Reihenfolgen erzeugen.
proc pep_plan_check {plan which flag} {
  set s ""
  set n 0
  foreach entry $plan {
    set owner [lindex $entry 0]; set method [lindex $entry 1]
    set ids [lindex $entry $which]
    set a "dom.GetObject($owner).${method}()"
    append s "if ($a.Count() != [llength $ids]) { $flag = true; }\n"
    set i 0
    foreach id $ids {
      incr n
      append s "object pck$n = $a.GetAt($i);\n"
      append s "if (!pck$n) { $flag = true; } else { if (pck$n.ID() != $id) { $flag = true; } }\n"
      incr i
    }
  }
  return $s
}

# Den ReGa-Code zum Umhängen vorhandener Einträge erzeugen.
proc pep_plan_write {plan from to} {
  set s ""
  # Die Einträge nur aus der Liste aushängen. Die Objekte selbst bleiben erhalten.
  foreach entry $plan {
    set a "dom.GetObject([lindex $entry 0]).[lindex $entry 1]()"
    foreach id [lindex $entry $from] { append s "$a.Remove($id);\n" }
  }
  foreach entry $plan {
    set owner [lindex $entry 0]
    set a "dom.GetObject($owner).[lindex $entry 1]()"
    foreach id [lindex $entry $to] {
      append s "$a.Add($id);\n"
    }
  }
  return $s
}

# Den Sortierplan prüfen, anwenden und bei Bedarf zurücksetzen.
proc pep_apply_plan {plan {extraCheck ""} {extraWrite ""} {extraUndo ""} {extraPost ""}} {
  global pep_scope_guard
  set s "boolean stale = false; boolean failed = false; boolean rollbackFailed = false;\n"
  if {[info exists pep_scope_guard]} { append s $pep_scope_guard }
  append s $extraCheck [pep_plan_check $plan 2 stale]
  append s "if (stale) { Write(\"ERR|Struktur geaendert - Editor neu laden\"); } else {\n"
  append s [pep_plan_write $plan 2 3] $extraWrite
  append s [pep_plan_check $plan 3 failed] $extraPost
  append s "if (failed) {\n"
  append s [pep_plan_write $plan 3 2] $extraUndo
  append s [pep_plan_check $plan 2 rollbackFailed]
  append s "if (rollbackFailed) { Write(\"POSTFAIL|Wiederherstellung nicht bestaetigt - Bearbeitung abbrechen\"); } else { Write(\"ERR|Sortierung nicht uebernommen; Ausgangsreihenfolge wiederhergestellt\"); }\n"
  append s "} else { Write(\"OK\"); }\n}\n"
  set out [string trim [pep_rega $s]]
  if {$out == ""} { return "POSTFAIL|Keine Bestaetigung von ReGa - Bearbeitung abbrechen" }
  return $out
}

# Prüfen, ob die beteiligten Zweige zu einer Editor-Arbeitskopie gehören.
proc pep_scope {rids} {
  global pep_scope_guard
  set s "boolean allowed = true; integer scopePID = 0;\n"
  foreach rid $rids {
    append s "object scopeR = dom.GetObject($rid);\n"
    append s "if (!scopeR) { allowed = false; } else {\n"
    append s "object scopeP = dom.GetObject(scopeR.RuleProgramID());\n"
    append s "if (!scopeP) { allowed = false; } else {\n"
    append s "if (!scopeP.IsTypeOf(OT_PROGRAM)) { allowed = false; }\n"
    append s "if (scopeP.ProgramCopyID() == ID_ERROR) { allowed = false; }\n"
    append s "if (scopePID == 0) { scopePID = scopeP.ID(); } else { if (scopePID != scopeP.ID()) { allowed = false; } }\n"
    append s "} }\n"
  }
  set pep_scope_guard "$s\nif (!allowed) { stale = true; }\n"
  append s "if (allowed) { Write(\"OK\"); }"
  return [expr {[string trim [pep_rega $s]] == "OK"}]
}

# Bedingungen innerhalb einer logischen Gruppe umsortieren.
proc pep_op_conds {rid cid perm} {
  global D_groups D_singles D_sop
  if {![pep_is_id $rid] || ![pep_is_id $cid]} { return "ERR|Ungueltige Parameter" }
  if {![pep_scope [list $rid]]} { return "ERR|Nur in einer Editor-Arbeitskopie moeglich; neues Programm zuerst speichern und erneut oeffnen" }
  if {![pep_dump [list $rid]]} { return "ERR|Regel nicht gefunden" }
  if {[lsearch -exact $D_groups($rid) $cid] < 0} { return "ERR|Gruppe gehoert nicht zur Regel" }
  set ids $D_singles($cid)
  if {![pep_expected $ids]} { return "ERR|Bedingungen geaendert - Editor neu laden" }
  if {![pep_valid_perm $perm [llength $ids]]} { return "ERR|Struktur geaendert" }
  set ops {}
  foreach id $ids { lappend ops $D_sop($id) }
  if {![pep_uniform $ops]} { return "ERR|Gemischte UND/ODER-Verknuepfungen: Verschieben nicht eindeutig" }
  return [pep_apply_plan [list [list $cid CndSingleConditions $ids [pep_permute $ids $perm] ""]]]
}

# Logische Gruppen innerhalb eines Zweigs umsortieren.
proc pep_op_groups {rid perm} {
  global D_groups D_gop
  if {![pep_is_id $rid]} { return "ERR|Ungueltige Parameter" }
  if {![pep_scope [list $rid]]} { return "ERR|Keine Editor-Arbeitskopie" }
  if {![pep_dump [list $rid]]} { return "ERR|Regel nicht gefunden" }
  set ids $D_groups($rid)
  if {![pep_expected $ids]} { return "ERR|Gruppen geaendert - Editor neu laden" }
  if {![pep_valid_perm $perm [llength $ids]]} { return "ERR|Struktur geaendert" }
  set ops {}
  foreach id $ids { lappend ops $D_gop($id) }
  if {![pep_uniform $ops]} { return "ERR|Gemischte Gruppenverknuepfungen: Verschieben nicht eindeutig" }
  return [pep_apply_plan [list [list $rid RuleConditions $ids [pep_permute $ids $perm] ""]]]
}

# Aktionen innerhalb derselben Aktionsliste umsortieren.
proc pep_op_acts {rid did perm} {
  global D_did D_dsingles
  if {![pep_is_id $rid] || ![pep_is_id $did]} { return "ERR|Ungueltige Parameter" }
  if {![pep_scope [list $rid]]} { return "ERR|Keine Editor-Arbeitskopie" }
  if {![pep_dump [list $rid]]} { return "ERR|Regel nicht gefunden" }
  if {$D_did($rid) != $did} { return "ERR|Aktionsbereich gehoert nicht zur Regel" }
  set ids $D_dsingles($did)
  if {![pep_expected $ids]} { return "ERR|Aktionen geaendert - Editor neu laden" }
  if {![pep_valid_perm $perm [llength $ids]]} { return "ERR|Struktur geaendert" }
  return [pep_apply_plan [list [list $did DestSingleDestinations $ids [pep_permute $ids $perm] ""]]]
}

# Einen eindeutigen Vergleichsausdruck für Objekteigenschaften erzeugen.
proc pep_sig_expr {obj props} {
  set parts {}
  foreach p $props {
    lappend parts "${obj}.${p}().ToString().Length() # \":\" # ${obj}.${p}().ToString()"
  }
  return [join $parts { # }]
}

# Einen Zweig einschließlich Bedingungen, Zeitmodulen und Aktionen beschreiben.
proc pep_fingerprint {rule out} {
  set s "string $out = ${rule}.ElseIfFlag().ToString() # ${rule}.RuleDestination().BreakOnRestart().ToString();\n"
  append s "${out} = ${out} # ${rule}.RuleConditions().Count().ToString() # \":\";\n"
  append s "string fg; string fs; string fa;\n"
  append s "foreach (fg, ${rule}.RuleConditions().EnumIDs()) {\nobject fc = dom.GetObject(fg);\n"
  append s "${out} = ${out} # fc.CndOperatorType().ToString() # fc.CndSingleCount().ToString() # \":\";\n"
  append s "foreach (fs, fc.CndSingleConditions().EnumIDs()) {\nobject fsc = dom.GetObject(fs);\n"
  append s "${out} = ${out} # [pep_sig_expr fsc {ConditionChannel LeftValType ConditionType ConditionType2 RightVal1ValType RightVal2ValType RightVal2 OperatorType NegateCondition}];\n"
  append s "if ((fsc.LeftValType() == ivtCurrentDate) && (fsc.RightVal1ValType() == ivtObjectId)) {\nobject ftm = dom.GetObject(fsc.RightVal1());\n"
  append s "if (ftm) { ${out} = ${out} # [pep_sig_expr ftm {TimerType Time CalDuration CalRepeatTime Weekdays Period CalRepetitionValue Begin End CalRepetitionCount SunOffsetType}]; } else { ${out} = ${out} # \"MISSING_TIMER\"; }\n"
  append s "} else { ${out} = ${out} # [pep_sig_expr fsc {LeftVal RightVal1}]; }\n} }\n"
  append s "${out} = ${out} # ${rule}.RuleDestination().DestSingleCount().ToString() # \":\";\n"
  append s "foreach (fa, ${rule}.RuleDestination().DestSingleDestinations().EnumIDs()) {\nobject fad = dom.GetObject(fa);\n"
  append s "${out} = ${out} # [pep_sig_expr fad {DestinationChannel DestinationDP DestinationParam DestinationValueType DestinationValue DestinationValueParamType}];\n"
  # Bei Verzögerungen gehört nur die Uhrzeit zum Vergleich. Das Datum kann sich beim Kopieren ändern.
  append s "if (fad.DestinationValueParamType() == ivtDelay) { string delayTime = fad.DestinationValueParam().ToString().Substr(11,8);\n"
  append s "${out} = ${out} # delayTime.Length() # \":\" # delayTime;\n} else { ${out} = ${out} # [pep_sig_expr fad {DestinationValueParam}]; }\n}\n"
  return $s
}

# Ganze bedingte Zweige mit dem nativen Kopierverfahren umsortieren.
proc pep_op_branches {rids perm} {
  global D_parent D_ei D_did D_bor D_groups D_dsingles
  if {![regexp {^[0-9]+(,[0-9]+)*$} $rids]} { return "ERR|Ungueltige Parameter" }
  set rules [split $rids ,]; set n [llength $rules]
  if {![pep_valid_perm $perm $n] || $n < 2 || $n > 100} { return "ERR|Ungueltige Reihenfolge" }
  set seen {}
  foreach rid $rules {
    if {![pep_is_id $rid]} { return "ERR|Ungueltige Regel-ID" }
    if {[lsearch -exact $seen $rid] >= 0} { return "ERR|Doppelte Regel" }
    lappend seen $rid
  }
  if {![pep_scope $rules]} { return "ERR|Keine gemeinsame Editor-Arbeitskopie" }
  if {![pep_dump $rules]} { return "ERR|Regel nicht gefunden" }
  set prev ""; set plan {}
  foreach rid $rules {
    if {$D_ei($rid) != 1} { return "ERR|SONST bleibt als bedingungsloser Abschluss am Ende" }
    if {$prev != "" && $D_parent($rid) != $prev} { return "ERR|Regelkette geaendert" }
    lappend plan [list $rid RuleConditions $D_groups($rid) $D_groups($rid) ""]
    lappend plan [list $D_did($rid) DestSingleDestinations $D_dsingles($D_did($rid)) $D_dsingles($D_did($rid)) ""]
    set prev $rid
  }
  set root [lindex $rules 0]
  set s "boolean stale = false; boolean failed = false;\n"
  append s "object work = dom.GetObject(dom.GetObject($root).RuleProgramID());\n"
  append s "integer originalCopy = work.ProgramCopyID();\n"
  append s "if ((originalCopy == ID_ERROR) || (work.Rule().ID() != $root)) { stale = true; }\n"
  append s [pep_plan_check $plan 2 stale]
  set i 0
  foreach rid $rules {
    append s "if (!dom.GetObject($rid).ElseIfFlag()) { stale = true; }\n"
    if {$i > 0} { append s "if (dom.GetObject([lindex $rules [expr {$i-1}]]).RuleSubRule().ID() != $rid) { stale = true; }\n" }
    append s "object wr$i = dom.GetObject($rid);\n"
    append s [pep_fingerprint wr$i want$i]
    incr i
  }
  append s "object tail = dom.GetObject([lindex $rules end]).RuleSubRule();\nif (tail) { if (tail.ElseIfFlag()) { stale = true; } }\n"
  append s "boolean hadElse = false; string wantElse = \"\";\nif (tail) { hadElse = true;\n"
  append s [pep_fingerprint tail capturedElse]
  append s "wantElse = capturedElse;\n}\n"
  append s "if (stale) { Write(\"ERR|Regelkette geaendert - Editor neu laden\"); } else {\n"
  # Die WebUI kopiert Zweige mitsamt ihren Zeitmodulen. Danach Quelle und Kopie wieder wie zuvor verknüpfen.
  append s "object stage = work.ProgramCopyTo();\nwork.ProgramCopyID(originalCopy);\n"
  append s "if (!stage) { Write(\"ERR|Temporaere Programmkopie fehlgeschlagen\"); } else {\nstage.Active(false);\n"
  for {set i 0} {$i < $n} {incr i} {
    if {$i == 0} { append s "object sr0 = stage.Rule();\n" } else { append s "object sr$i = sr[expr {$i-1}].RuleSubRule();\n" }
    append s "string groups$i = sr$i.RuleConditions().EnumIDs();\nstring acts$i = sr$i.RuleDestination().DestSingleDestinations().EnumIDs();\nboolean bor$i = sr$i.RuleDestination().BreakOnRestart();\n"
    append s [pep_fingerprint sr$i copied$i]
    append s "if (copied$i != want$i) { failed = true; }\n"
  }
  append s "string moveID;\nif (!failed) {\n"
  for {set i 0} {$i < $n} {incr i} {
    append s "foreach(moveID, groups$i) { sr$i.RuleConditions().Remove(moveID); }\n"
    append s "foreach(moveID, acts$i) { sr$i.RuleDestination().DestSingleDestinations().Remove(moveID); }\n"
  }
  set i 0
  foreach src [split $perm ,] {
    append s "foreach(moveID, groups$src) { sr$i.RuleConditions().Add(moveID); }\n"
    append s "foreach(moveID, acts$src) { sr$i.RuleDestination().DestSingleDestinations().Add(moveID); }\n"
    append s "sr$i.RuleDestination().BreakOnRestart(bor$src);\n"
    append s [pep_fingerprint sr$i sorted$i]
    append s "if (sorted$i != want$src) { failed = true; }\n"
    incr i
  }
  # Der native Kopiervorgang ordnet die Zweige ihrem neuen übergeordneten Zweig zu.
  append s "if (!failed) {\nboolean committed = stage.ProgramCopyTo(work.ID());\nwork.ProgramCopyID(originalCopy);\n"
  append s "if (!committed) { failed = true; }\n}\n"
  # Die ursprüngliche Liste wiederherstellen, bevor das temporäre Programm gelöscht wird.
  set i 0
  foreach src [split $perm ,] {
    append s "foreach(moveID, groups$src) { sr$i.RuleConditions().Remove(moveID); }\n"
    append s "foreach(moveID, acts$src) { sr$i.RuleDestination().DestSingleDestinations().Remove(moveID); }\n"
    incr i
  }
  for {set i 0} {$i < $n} {incr i} {
    append s "foreach(moveID, groups$i) { sr$i.RuleConditions().Add(moveID); }\n"
    append s "foreach(moveID, acts$i) { sr$i.RuleDestination().DestSingleDestinations().Add(moveID); }\n"
    append s "sr$i.RuleDestination().BreakOnRestart(bor$i);\n"
  }
  append s "}\n"
  append s "dom.DeleteObject(stage.ID());\n"
  # Das Ergebnis einschließlich Bedingungen, Aktionen und Zeitmodulen erneut lesen und vergleichen.
  append s "string newRules = \"\";\n"
  set i 0
  foreach src [split $perm ,] {
    if {$i == 0} { append s "object nr0 = work.Rule();\n" } else { append s "object nr$i = nr[expr {$i-1}].RuleSubRule();\n" }
    append s [pep_fingerprint nr$i actual$i]
    append s "if (actual$i != want$src) { failed = true; }\n"
    if {$i > 0} { append s "newRules = newRules # \",\";\n" }
    append s "newRules = newRules # nr$i.ID();\n"
    incr i
  }
  append s "object finalElse = nr[expr {$n-1}].RuleSubRule();\nif (finalElse) { newRules = newRules # \",\" # finalElse.ID(); }\n"
  append s "if (hadElse) { if (!finalElse) { failed = true; } else {\n"
  append s [pep_fingerprint finalElse actualElse]
  append s "if (actualElse != wantElse) { failed = true; }\n} } else { if (finalElse) { failed = true; } }\n"
  append s "if (failed) { Write(\"POSTFAIL|Native Kopie nicht bestaetigt - Bearbeitung abbrechen\"); } else { Write(\"OK|\" # work.ID() # \"|\" # work.Rule().ID() # \"|\" # newRules); }\n} }\n"
  set out [string trim [pep_rega $s]]
  if {$out == ""} { return "POSTFAIL|Keine ReGa-Bestaetigung - Bearbeitung abbrechen" }
  return $out
}

# Vergleichswerte für gespeicherte Zweigtexte bestimmen.
proc pep_desc_signatures {pid} {
  if {![pep_is_id $pid]} { error "Ungueltige Programm-ID" }
  set s "object dp = dom.GetObject($pid);\nif (dp) { if (dp.IsTypeOf(OT_PROGRAM)) {\nobject dr = dp.Rule(); integer dn = 0;\nwhile (dr && (dn < 100)) {\n"
  append s [pep_fingerprint dr dsig]
  append s "Write(dsig.Length() # \":\" # dsig);\ndr = dr.RuleSubRule(); dn = dn + 1;\n} } }\n"
  set data [pep_rega $s]; set result {}
  while {$data != ""} {
    set sep [string first : $data]
    if {$sep < 1} { error "Programmdaten nicht lesbar" }
    set length [string range $data 0 [expr {$sep-1}]]
    if {![regexp {^[0-9]+$} $length] || $length > 1000000} { error "Ungueltige Programmdaten" }
    set start [expr {$sep+1}]; set end [expr {$start+$length-1}]
    if {[string length $data] < $end+1} { error "Unvollstaendige Programmdaten" }
    lappend result [string range $data $start $end]
    set data [string range $data [expr {$end+1}] end]
  }
  if {[llength $result] == 0} { error "Programm nicht gefunden" }
  return $result
}

# Die früheren Zweigtexte aus der Datendatei lesen.
proc pep_desc_records {} {
  global pep_var
  set path "$pep_var/descriptions-v2.list"
  if {![file exists $path]} { return {} }
  set fh [open $path r]; fconfigure $fh -encoding utf-8
  set data [read $fh]; close $fh
  if {[catch {llength $data}]} { error "Beschreibungsdatei beschaedigt" }
  return $data
}

# Gespeicherte Zweigtexte anhand der Zweiginhalte zuordnen.
proc pep_desc_get_v2 {pid} {
  global pep_var
  set signatures [pep_desc_signatures $pid]
  set records [pep_desc_records]; set stored {}; set exists 0
  foreach record $records {
    if {[llength $record] != 4} { error "Ungueltiger Beschreibungseintrag" }
    if {[lindex $record 0] == $pid} { lappend stored $record; set exists 1 }
  }
  set out "OK|[llength $signatures]\n"; set index 0
  foreach sig $signatures {
    set exact ""; set matches {}; set sameCount 0
    foreach other $signatures { if {$other == $sig} { incr sameCount } }
    foreach record $stored {
      if {[lindex $record 2] == $sig} {
        lappend matches [lindex $record 3]
        if {[lindex $record 1] == $index} { set exact [lindex $record 3] }
      }
    }
    if {$exact != ""} { append out "$index\t$exact\n" } elseif {$sameCount == 1 && [llength $matches] == 1} {
      append out "$index\t[lindex $matches 0]\n"
    }
    incr index
  }
  # Zweigtexte aus dem früheren Dateiformat beim Lesen übernehmen.
  if {!$exists && [file exists "$pep_var/descriptions.tsv"]} {
    set fh [open "$pep_var/descriptions.tsv" r]; set data [read $fh]; close $fh
    foreach line [split $data \n] {
      set fields [split $line \t]
      if {[llength $fields] == 3 && [lindex $fields 0] == $pid &&
          [regexp {^[0-9]+$} [lindex $fields 1]] && [lindex $fields 1] < [llength $signatures]} {
        append out "[lindex $fields 1]\t[lindex $fields 2]\n"
      }
    }
  }
  return $out
}

# Die Zweigtexte im früheren Dateiformat speichern.
proc pep_desc_set_v2 {pid items} {
  global pep_var
  set copy [pep_param copy]
  if {![pep_is_id $pid] || ![pep_is_id $copy]} { return "ERR|Ungueltige Programm-ID" }
  # Erst nach bestätigter Programmspeicherung schreiben.
  if {$copy != $pid} {
    set check "if (!dom.GetObject($copy)) { if (dom.GetObject($pid)) { Write(\"SAVED\"); } }"
    if {[string trim [pep_rega $check]] != "SAVED"} { return "ERR|Originales Speichern noch nicht bestaetigt" }
  }
  set signatures [pep_desc_signatures $pid]
  set texts [split $items ,]
  if {[llength $texts] != [llength $signatures]} { return "ERR|Zweigstruktur beim Speichern geaendert" }
  set keep {}
  foreach record [pep_desc_records] { if {[lindex $record 0] != $pid} { lappend keep $record } }
  set index 0
  foreach text $texts {
    if {[string length $text] > 12000 || ![regexp {^([A-Za-z0-9_.~!*'()-]|%[0-9A-Fa-f][0-9A-Fa-f])*$} $text]} {
      return "ERR|Beschreibung zu lang oder ungueltig kodiert"
    }
    # Ein leerer Eintrag markiert einen gelöschten Text, damit er nicht aus alten Daten zurückkehrt.
    lappend keep [list $pid $index [lindex $signatures $index] $text]
    incr index
  }
  file mkdir $pep_var
  set path "$pep_var/descriptions-v2.list"; set tmp "$path.tmp"
  set fh [open $tmp w]; fconfigure $fh -encoding utf-8
  puts -nonewline $fh $keep; close $fh
  file rename -force $tmp $path
  return "OK"
}

set pep_note_limit 2000

# Die Textlänge nach denselben Regeln wie der Browser zählen.
proc pep_note_length {text} {
  set bytes [encoding convertto iso8859-1 [pep_urldecode $text]]
  binary scan $bytes c* values
  set count 0; set total [llength $values]
  for {set n 0} {$n < $total} {incr n} {
    set b [expr {[lindex $values $n] & 255}]
    set more 0; set units 1
    if {$b < 128} {
      set more 0
    } elseif {$b >= 194 && $b <= 223} { set more 1
    } elseif {$b >= 224 && $b <= 239} { set more 2
    } elseif {$b >= 240 && $b <= 244} { set more 3; set units 2
    } else { error "Ungueltiges UTF-8" }
    if {$n+$more >= $total} { error "Unvollstaendiges UTF-8" }
    for {set j 1} {$j <= $more} {incr j} {
      set next [expr {[lindex $values [expr {$n+$j}]] & 255}]
      if {$next < 128 || $next > 191} { error "Ungueltiges UTF-8" }
      if {$j == 1 && (($b == 224 && $next < 160) || ($b == 237 && $next > 159) || ($b == 240 && $next < 144) || ($b == 244 && $next > 143))} { error "Ungueltiges UTF-8" }
    }
    incr n $more; incr count $units
  }
  return $count
}

# Dokumentierbare Zweige, Bedingungen und Aktionen bestimmen.
proc pep_note_entities {pid} {
  if {![pep_is_id $pid]} { error "Ungueltige Programm-ID" }
  set s "object np = dom.GetObject($pid);\nif (np) { if (np.IsTypeOf(OT_PROGRAM)) {\nobject nr = np.Rule(); integer nb = 0; string ni; string nj;\nwhile (nr && (nb < 100)) {\n"
  append s [pep_fingerprint nr branchSig]
  append s "Write(\"r|\" # nb # \"|0|\" # branchSig.Length() # \":\" # branchSig);\ninteger nc = 0;\n"
  append s "foreach(ni, nr.RuleConditions().EnumIDs()) { object ng = dom.GetObject(ni);\nforeach(nj, ng.CndSingleConditions().EnumIDs()) { object ns = dom.GetObject(nj);\n"
  append s [pep_note_condition_signature ns itemSig]
  append s "Write(\"c|\" # nb # \"|\" # nc # \"|\" # itemSig.Length() # \":\" # itemSig); nc = nc + 1;\n} }\n"
  append s "integer na = 0;\nforeach(ni, nr.RuleDestination().DestSingleDestinations().EnumIDs()) { object ns = dom.GetObject(ni);\n"
  append s [pep_note_action_signature ns itemSig]
  append s "Write(\"a|\" # nb # \"|\" # na # \"|\" # itemSig.Length() # \":\" # itemSig); na = na + 1;\n}\nnr = nr.RuleSubRule(); nb = nb + 1;\n} } }\n"
  set data [pep_rega $s]; set result {}; set branch ""
  while {$data != ""} {
    if {![regexp {^([rca])\|([0-9]+)\|([0-9]+)\|([0-9]+):} $data header kind b i size]} { error "Unvollstaendige Programmdaten" }
    set start [string length $header]; set end [expr {$start+$size-1}]
    if {$size > 1000000 || [string length $data] < $end+1} { error "Ungueltige Programmdaten" }
    set sig [string range $data $start $end]
    if {$kind == "r"} { set branch $sig }
    lappend result [list $kind $b $i $branch $sig]
    set data [string range $data [expr {$end+1}] end]
  }
  if {[llength $result] == 0} { error "Programm nicht gefunden" }
  return $result
}

# Den Vergleichswert einer Bedingung erzeugen.
proc pep_note_condition_signature {obj out} {
  set s "string $out = [pep_sig_expr $obj {ConditionChannel LeftValType ConditionType ConditionType2 RightVal1ValType RightVal2ValType RightVal2 OperatorType NegateCondition}];\n"
  append s "if ((${obj}.LeftValType() == ivtCurrentDate) && (${obj}.RightVal1ValType() == ivtObjectId)) { object nt = dom.GetObject(${obj}.RightVal1());\n"
  append s "if (nt) { $out = $out # [pep_sig_expr nt {TimerType Time CalDuration CalRepeatTime Weekdays Period CalRepetitionValue Begin End CalRepetitionCount SunOffsetType}]; } else { $out = $out # \"MISSING_TIMER\"; }\n"
  append s "} else { $out = $out # [pep_sig_expr $obj {LeftVal RightVal1}]; }\n"
  return $s
}

# Den Vergleichswert einer Aktion erzeugen.
proc pep_note_action_signature {obj out} {
  set s "string $out = [pep_sig_expr $obj {DestinationChannel DestinationDP DestinationParam DestinationValueType DestinationValue DestinationValueParamType}];\n"
  append s "if (${obj}.DestinationValueParamType() == ivtDelay) { string ntime = ${obj}.DestinationValueParam().ToString().Substr(11,8); $out = $out # ntime.Length() # \":\" # ntime; } else { $out = $out # [pep_sig_expr $obj {DestinationValueParam}]; }\n"
  return $s
}

# Die gespeicherten Infotexte aus der Datendatei lesen.
proc pep_note_records {} {
  global pep_var
  set file "$pep_var/descriptions-v3.list"
  if {![file exists $file]} { return {} }
  set fh [open $file r]; fconfigure $fh -encoding utf-8
  set data [read $fh]; close $fh
  if {[catch {llength $data}]} { error "Beschreibungsdatei beschaedigt" }
  foreach record $data { if {[llength $record] != 7} { error "Ungueltiger Beschreibungseintrag" } }
  return $data
}

# Gespeicherte Infotexte den aktuellen Programmeinträgen zuordnen.
proc pep_desc_get {pid} {
  set entities [pep_note_entities $pid]; set stored {}; set found 0; set count 0
  foreach record [pep_note_records] {
    if {[lindex $record 0] == $pid} { lappend stored $record; set found 1 }
  }
  foreach entity $entities { if {[lindex $entity 0] == "r"} { incr count } }
  set out "OK|$count\n"
  if {!$found} {
    # Ältere Zweigtexte lesen, solange noch keine aktuellen Infotexte vorliegen.
    foreach line [split [pep_desc_get_v2 $pid] \n] {
      set f [split $line \t]
      if {[llength $f] == 2 && [regexp {^[0-9]+$} [lindex $f 0]]} {
        append out "r|[lindex $f 0]|0\t[lindex $f 1]\n"
      }
    }
    return $out
  }
  foreach entity $entities {
    set kind [lindex $entity 0]; set b [lindex $entity 1]; set i [lindex $entity 2]
    set branch [lindex $entity 3]; set sig [lindex $entity 4]
    set exact ""; set exactFound 0; set matches {}; set currentMatches 0
    foreach other $entities {
      if {[lindex $other 0] == $kind && [lindex $other 3] == $branch && [lindex $other 4] == $sig} { incr currentMatches }
    }
    foreach record $stored {
      if {[lindex $record 1] == $kind && [lindex $record 4] == $branch && [lindex $record 5] == $sig} {
        lappend matches [lindex $record 6]
        if {[lindex $record 2] == $b && [lindex $record 3] == $i} { set exact [lindex $record 6]; set exactFound 1 }
      }
    }
    if {$exactFound} { append out "$kind|$b|$i\t$exact\n" } elseif {$currentMatches == 1 && [llength $matches] == 1} {
      append out "$kind|$b|$i\t[lindex $matches 0]\n"
    }
  }
  return $out
}

# Infotexte für das bestätigte Programm speichern.
proc pep_desc_set {pid ignored} {
  global pep_var pep_note_limit
  set copy [pep_param copy]
  if {![pep_is_id $pid] || ![pep_is_id $copy]} { return "ERR|Ungueltige Programm-ID" }
  if {$copy != $pid} {
    if {[string trim [pep_rega "if (!dom.GetObject($copy)) { if (dom.GetObject($pid)) { Write(\"SAVED\"); } }"]] != "SAVED"} {
      return "ERR|Originales Speichern noch nicht bestaetigt"
    }
  }
  set notes [pep_param notes]
  if {$notes == ""} { return "ERR|Aktuelle Dokumentationsdaten fehlen - WebUI neu laden" }
  catch {unset texts}
  foreach line [split $notes ,] {
    if {![regexp {^([rca])\|([0-9]+)\|([0-9]+)\|(.*)$} $line all kind b i text]} { return "ERR|Ungueltige Dokumentationsdaten" }
    set key "$kind|$b|$i"
    if {[info exists texts($key)]} { return "ERR|Doppelter Dokumentationseintrag" }
    if {[string length $text] > 24000 || ![regexp {^([A-Za-z0-9_.~!*'()-]|%[0-9A-Fa-f][0-9A-Fa-f])*$} $text]} { return "ERR|Text ungueltig kodiert" }
    if {[catch {set length [pep_note_length $text]}]} { return "ERR|Text ungueltig kodiert" }
    if {$length > $pep_note_limit && ![pep_note_existing_long $pid $text]} {
      return "ERR|Maximal $pep_note_limit Zeichen je Infotext"
    }
    set texts($key) $text
  }
  set entities [pep_note_entities $pid]
  if {[array size texts] != [llength $entities]} { return "ERR|Programmstruktur beim Speichern geaendert" }
  set keep {}
  foreach record [pep_note_records] { if {[lindex $record 0] != $pid} { lappend keep $record } }
  foreach entity $entities {
    set kind [lindex $entity 0]; set b [lindex $entity 1]; set i [lindex $entity 2]
    set key "$kind|$b|$i"
    if {![info exists texts($key)]} { return "ERR|Dokumentationszuordnung unvollstaendig" }
    lappend keep [list $pid $kind $b $i [lindex $entity 3] [lindex $entity 4] $texts($key)]
  }
  file mkdir $pep_var
  set file "$pep_var/descriptions-v3.list"; set tmp "$file.tmp"
  set fh [open $tmp w]; fconfigure $fh -encoding utf-8
  puts -nonewline $fh $keep; close $fh
  file rename -force $tmp $file
  return "OK"
}

# Einen bereits gespeicherten längeren Text unverändert erkennen.
proc pep_note_existing_long {pid text} {
  global pep_var
  foreach record [pep_note_records] {
    if {[lindex $record 0] == $pid && [lindex $record 6] == $text} { return 1 }
  }
  foreach record [pep_desc_records] {
    if {[lindex $record 0] == $pid && [lindex $record 3] == $text} { return 1 }
  }
  if {[file exists "$pep_var/descriptions.tsv"]} {
    set fh [open "$pep_var/descriptions.tsv" r]; set data [read $fh]; close $fh
    foreach line [split $data \n] {
      set f [split $line \t]
      if {[llength $f] == 3 && [lindex $f 0] == $pid && [lindex $f 2] == $text} { return 1 }
    }
  }
  return 0
}

