// Das ausgewählte Farbschema auf die WebUI anwenden.
(function(w){
 'use strict';var P=w.__PEP__||w.__EWUI_THEME_CONTEXT__,d=w.document;if(!P){return;}
 if(w.__EWUI_THEME__){if(w.__PEP__){w.__PEP__.theme=w.__EWUI_THEME__;}w.__EWUI_THEME__.refresh();return;}
 // Prüfen, ob der Theme-Wechsel freigegeben ist.
 function enabled(){return !!((w.__PEP__||P).settings.themes);}
 var mode='light',documents=new WeakMap(),scheduled=false;
 try{mode=w.localStorage.getItem('ewebui-theme')==='dark'?'dark':'light';}catch(ignore){}
 // Die Farbpalette der Oberfläche anwenden.
 function colors(value){var m=/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/.exec(value);return m&&(!m[4]||Number(m[4])>0.95)?[+m[1],+m[2],+m[3]]:null;}
 // Die Originalansicht wiederherstellen.
 function neutral(c){return c&&Math.max.apply(Math,c)-Math.min.apply(Math,c)<45;}
 // Eine Aktualisierung der Darstellung vormerken.
 function queue(){if(scheduled){return;}scheduled=true;w.setTimeout(function(){scheduled=false;refresh();},60);}
 // Das gewählte Theme auf ein Dokument anwenden.
 function applyDocument(doc,depth){
  if(!doc.documentElement||depth>5){return;}
  if(doc.documentElement.getAttribute('data-pep-theme')==='original'||doc.getElementById('printDiv')){doc.documentElement.classList.remove('pep-dark');return;}
  var state=documents.get(doc);
  if(!state){
   state={signatures:new WeakMap(),chrome:new WeakSet()};documents.set(doc,state);
   var link=doc.createElement('link');link.rel='stylesheet';link.href=P.base+'dark.css?v='+P.version;link.id='pep-dark-css';(doc.head||doc.documentElement).appendChild(link);
   if(w.MutationObserver){state.observer=new w.MutationObserver(function(records){
    var changed=records.some(function(r){return !(r.type==='attributes'&&r.target===doc.documentElement&&r.attributeName==='class');});
    if(records.some(function(r){return r.target.nodeName==='STYLE';})){state.signatures=new WeakMap();}
    if(changed){queue();}
   });state.observer.observe(doc.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['class','style','bgcolor','color']});}
  }
  var active=enabled()&&mode==='dark';
  var chrome=Array.prototype.slice.call(doc.querySelectorAll('#header,#menubar')).filter(function(e){return !state.chrome.has(e);});
  if(chrome.length){
   doc.documentElement.classList.remove('pep-dark');
   chrome.forEach(function(e){e.style.setProperty('--pep-native-ink',doc.defaultView.getComputedStyle(e).color);state.chrome.add(e);});
  }
  // Für die Farberkennung die Originalfarben auslesen, bevor das dunkle Theme sie überdeckt.
  doc.documentElement.classList.remove('pep-dark');
  if(active){
   Array.prototype.forEach.call(doc.querySelectorAll('body,div,table,thead,tbody,tfoot,tr,colgroup,col,td,th,span,label,p,small,strong,em,caption,fieldset,legend,ul,li,form,h1,h2,h3,pre,a,input,select,textarea,button,font,section,article,main,center,b,i'),function(e){
    var signature=[e.className,e.getAttribute('style'),e.getAttribute('bgcolor'),e.getAttribute('color')].join('|');
    if(state.signatures.get(e)===signature){return;}state.signatures.set(e,signature);
    ['data-pep-control','data-pep-icon-control','data-pep-surface','data-pep-ink','data-pep-code-token'].forEach(function(a){e.removeAttribute(a);});
    var cs=doc.defaultView.getComputedStyle(e),bg=colors(cs.backgroundColor),fg=colors(cs.color);
    if(e.closest('.cm-editor,.CodeMirror')&&fg&&!neutral(fg)){e.setAttribute('data-pep-code-token',fg[0]>fg[2]?'warm':'cool');}
    if(e.matches('.tMoveUp,.tMoveDown')){e.setAttribute('data-pep-icon-control','1');}
    else if(e.matches('button,input[type="button"],input[type="submit"],input[type="reset"],[role="button"],.Button,.StdTableBtn,.StdTableBtn2,.StdButton,.StdButtonBig,.StdButtonInactive,.FooterButton,.FilterBtn,.FilterSetButton,.scriptButton,.NavButton,.NavButton2,.NavButtonSelected,.NavButtonSelected2,.MainMenuItemCaption,.MainMenuItem_Caption,.Messages,.UIButtonText,.YesNoDialog_yesButton,.YesNoDialog_noButton,.EulaDialog_yesButton,.EulaDialog_noButton')||((e.hasAttribute('onclick')||e.getAttribute('role')==='button')&&cs.backgroundImage.indexOf('gradient(')>=0)){
      if(e.id!=='pep-theme-toggle'&&!e.classList.contains('pep-info')){e.setAttribute('data-pep-control','1');}
    }
    if(e.closest('#header,#menubar,#pep-theme-toggle,.pep-print-note')){return;}
    if(neutral(bg)){
     var avg=(bg[0]+bg[1]+bg[2])/3;
     if(avg>110){e.setAttribute('data-pep-surface',avg>235?'1':avg>195?'2':'3');}
    }
    if((!bg||neutral(bg))&&neutral(fg)&&(fg[0]+fg[1]+fg[2])/3<150){e.setAttribute('data-pep-ink','1');}
   });
  }
  doc.documentElement.classList.toggle('pep-dark',active);
  Array.prototype.forEach.call(doc.querySelectorAll('link[rel="stylesheet"]'),function(link){if(!link.__ewuiThemeLoad){link.__ewuiThemeLoad=true;link.addEventListener('load',function(){state.signatures=new WeakMap();queue();});}});
  Array.prototype.forEach.call(doc.querySelectorAll('iframe'),function(frame){
   if(!frame.__pepThemeListener){frame.__pepThemeListener=true;frame.addEventListener('load',queue);}
   try{if(frame.contentDocument){applyDocument(frame.contentDocument,depth+1);}}catch(ignore){}
  });
 }
 // Die Theme-Schaltfläche und Ansicht aktualisieren.
 function refresh(){
  var anchor=d.getElementById('menuNewDevicesPage'),button=d.getElementById('pep-theme-toggle');
  if(enabled()&&anchor){
   if(!button){button=d.createElement('div');button.id='pep-theme-toggle';button.className='MainMenuItem_Right';button.setAttribute('role','button');button.tabIndex=0;
    var caption=d.createElement('div');caption.className='MainMenuItemCaption';caption.textContent='Theme wechseln';button.appendChild(caption);
    button.onclick=/* Zwischen hellem und dunklem Theme wechseln. */ function(){setMode(mode==='dark'?'light':'dark');};button.onkeydown=/* Die Theme-Schaltfläche per Tastatur bedienen. */ function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();button.click();}};
    anchor.parentNode.insertBefore(button,anchor.nextSibling);
   }
   button.setAttribute('aria-pressed',mode==='dark'?'true':'false');button.title=mode==='dark'?'Aktuelles Theme: Dunkel. Zum hellen Theme wechseln.':'Aktuelles Theme: Original. Zum dunklen Theme wechseln.';
  }else if(button){button.remove();}
  applyDocument(d,0);
 }
 // Das ausgewählte Theme speichern und anwenden.
 function setMode(value){mode=value==='dark'?'dark':'light';try{w.localStorage.setItem('ewebui-theme',mode);}catch(ignore){}refresh();}
 w.addEventListener('storage',function(e){if(e.key==='ewebui-theme'){mode=e.newValue==='dark'?'dark':'light';refresh();}else if(e.key==='ewebui-settings'&&!w.__PEP__&&e.newValue){try{P.settings.themes=JSON.parse(e.newValue).themes===true;refresh();}catch(ignore){}}});
 P.theme=w.__EWUI_THEME__={refresh:refresh,setMode:setMode,getMode:/* Das ausgewählte Theme abfragen. */ function(){return mode;}};refresh();
})(window);
