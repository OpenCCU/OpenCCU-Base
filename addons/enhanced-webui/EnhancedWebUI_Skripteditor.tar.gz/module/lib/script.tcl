# Name, Adresse und Kanäle eines Geräts für den Skripteditor lesen.
proc pep_editor_device {id} {
  if {![pep_is_id $id]} {return "ERR|Ungueltige Geraete-ID"}
  set channels [pep_rega "object d=dom.GetObject($id); if(d) { if(d.IsTypeOf(OT_DEVICE)) { WriteLine(\"DEVICE\"); string c; foreach(c,d.Channels()) { WriteLine(c); } } }"]
  set lines [split [string trim $channels] \n]
  if {[string trim [lindex $lines 0]] != "DEVICE"} {return "ERR|Geraet nicht vorhanden"}
  set out "OK\n"
  set ids [linsert [lrange $lines 1 end] 0 $id]
  if {[llength $ids]>1025} {return "ERR|Zu viele Kanaele"}
  foreach oid $ids {
    set oid [string trim $oid]
    if {![pep_is_id $oid]} {continue}
    set name [pep_rega "object o=dom.GetObject($oid); if(o) { Write(o.Name()); }"]
    set address [pep_rega "object o=dom.GetObject($oid); if(o) { Write(o.Address()); }"]
    set kind "channel";if {$oid == $id} {set kind "device"}
    append out "$oid|[pep_editor_uri $name]|[pep_editor_uri $address]|[pep_editor_uri $kind]\n"
  }
  return $out
}

