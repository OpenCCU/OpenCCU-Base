// Fehlerzeilen aus der nativen ReGa-Fehlerprüfung markieren.
(function(w){
 'use strict';var P=w.__PEP__;if(!P||P.scriptErrors){return;}var documents=new Map(),queued=false;
 // Prüfen, ob Fehlermarkierungen aktiv sind.
 function enabled(){return !!(P.editor&&P.editor.isEnabled());}
 // Die Zeilennummer aus einer nativen Prüfmeldung lesen.
 function parse(text,count){
  var result=[],seen=new Set(),plain=String(text||'').replace(/<br\s*\/?>/gi,'\n').replace(/<[^>]*>/g,'');
  plain.split(/\r?\n/).forEach(function(line){var m=/^\s*Error\s+\d+\s+at\s+row\s+([1-9]\d*)\s+col\s+(\d+)\b/i.exec(line);if(!m){return;}var n=Number(m[1]);if(n>count||seen.has(n)){return;}seen.add(n);result.push({line:n-1,column:Math.max(0,Number(m[2])-1),message:line.trim()});});return result;
 }
 // Vorhandene Fehlermarkierungen entfernen.
 function clear(record){
  record.lines.forEach(function(line){record.cm.removeLineClass(line,'background','pep-script-error-line');});record.lines=[];record.cm.clearGutter('pep-error-gutter');
 }
 // Die Fehleranzeige vom Editor lösen.
 function detach(record){clear(record);record.cm.off('changes',record.changed);record.cm.setOption('gutters',(record.cm.getOption('gutters')||[]).filter(function(g){return g!=='pep-error-gutter';}));}
 // Fehlermarkierungen für einen Editor vorbereiten.
 function attach(doc,state){
  state.records.forEach(function(record,cm){if(!enabled()||!cm.getWrapperElement().isConnected){detach(record);state.records.delete(cm);}});
  if(!enabled()){return;}
  Array.prototype.forEach.call(doc.querySelectorAll('.CodeMirror'),function(node){
   var cm=node.CodeMirror,area=cm&&cm.getTextArea&&cm.getTextArea();if(!cm||!area||!/^code$|^scrinp$/.test(area.id)||cm.getOption('readOnly')||typeof cm.addLineClass!=='function'||state.records.has(cm)){return;}
   var record={cm:cm,version:0,sequence:0,lines:[]};record.changed=/* Bei Skriptänderungen die Markierung entfernen. */ function(){record.version++;clear(record);};cm.on('changes',record.changed);
   var gutters=(cm.getOption('gutters')||[]).slice();if(gutters.indexOf('pep-error-gutter')<0){gutters.push('pep-error-gutter');cm.setOption('gutters',gutters);}state.records.set(cm,record);
  });
 }
 // Den Text der Prüfantwort lesen.
 function bodyText(body){var m=/^<prototypejs><!\[CDATA\[([\s\S]*)\]\]><\/prototypejs>$/.exec(body);return m?w.unescape(m[1]):body;}
 // Eine Prüfanforderung dem passenden Editor zuordnen.
 function requestRecord(doc,state,url,options){
  if(!enabled()||!options||typeof options.postBody!=='string'){return null;}var uri;try{uri=new URL(url,doc.baseURI);}catch(e){return null;}
  if(uri.origin!==doc.location.origin||uri.pathname!=='/esp/system.htm'){return null;}
  var body=bodyText(options.postBody);if(!/^\s*string\s+action\s*=\s*['"]SyntaxCheck['"]\s*;/.test(body)){return null;}
  attach(doc,state);var candidates=[];
  state.records.forEach(function(record){var code=record.cm.getValue(),nativeCode=code.replace(/\^/g,"^#'^'#^");if(body.indexOf('string code = ^'+nativeCode+'^;')>=0){candidates.push(record);}});
  if(candidates.length>1){candidates=candidates.filter(function(record){return record.cm.getWrapperElement().contains(doc.activeElement);});}
  return candidates.length===1?candidates[0]:null;
 }
 // Die native Fehlerprüfung beobachten.
 function hook(target,state){
  if(!enabled()){if(state.hook&&target.Ajax&&target.Ajax.Request===state.hook.wrapper){target.Ajax.Request=state.hook.original;state.hook=null;}return;}
  if(state.hook||!target.Ajax||typeof target.Ajax.Request!=='function'){return;}
  var Original=target.Ajax.Request;
  // Die native Anfrage mit der Prüfbeobachtung ausführen.
  function Request(url,options){
   var record=requestRecord(target.document,state,url,options),next=options;
   if(record){
    clear(record);var sequence=++record.sequence,version=record.version,complete=options.onComplete;next=Object.assign({},options);
    next.onComplete=/* Eine Fehlermarkierung aus der Prüfantwort setzen. */ function(response){
     try{if(complete){return complete.apply(this,arguments);}}
     finally{
      // Eine alte Antwort darf keinen inzwischen geänderten Skripttext markieren.
      if(enabled()&&record.sequence===sequence&&record.version===version&&record.cm.getWrapperElement().isConnected&&response&&Number(response.status)===200){
       var errors=parse(response.responseText,record.cm.lineCount());
       record.cm.operation(function(){errors.forEach(function(error){var marker=target.document.createElement('span');marker.className='pep-script-error-marker';marker.textContent='!';marker.title=error.message;marker.setAttribute('aria-label',error.message);record.cm.setGutterMarker(error.line,'pep-error-gutter',marker);record.lines.push(record.cm.addLineClass(error.line,'background','pep-script-error-line'));});});
       if(errors.length){record.cm.scrollIntoView({line:errors[0].line,ch:Math.min(errors[0].column,record.cm.getLine(errors[0].line).length)},50);}
      }
     }
    };
   }
   return new Original(url,next);
  }
  Request.prototype=Original.prototype;Object.setPrototypeOf(Request,Original);target.Ajax.Request=Request;state.hook={original:Original,wrapper:Request};
 }
 // Die Beobachtung einer Seite beenden.
 function dispose(doc,state){state.records.forEach(detach);var target=doc.defaultView;if(state.hook&&target&&target.Ajax&&target.Ajax.Request===state.hook.wrapper){target.Ajax.Request=state.hook.original;}state.observer.disconnect();}
 // Editoren in einem Dokument erkennen.
 function scanDocument(doc){
  if(!doc.documentElement){return;}var state=documents.get(doc);
  if(!state){state={records:new Map(),hook:null};state.observer=new w.MutationObserver(queue);state.observer.observe(doc.documentElement,{childList:true,subtree:true});documents.set(doc,state);if(doc!==w.document&&!doc.getElementById('pep-errors-css')){var link=doc.createElement('link');link.id='pep-errors-css';link.rel='stylesheet';link.href=P.base+'script.css?v='+P.version;(doc.head||doc.documentElement).appendChild(link);}}
  attach(doc,state);hook(doc.defaultView,state);
  Array.prototype.forEach.call(doc.querySelectorAll('iframe'),function(frame){if(!frame.__pepErrorsLoad){frame.__pepErrorsLoad=true;frame.addEventListener('load',queue);}try{if(frame.contentDocument){scanDocument(frame.contentDocument);}}catch(ignore){}});
 }
 // Skriptdialoge in der WebUI und in Rahmen erkennen.
 function scan(){documents.forEach(function(state,doc){try{if(doc!==w.document&&(!doc.defaultView||!doc.defaultView.frameElement||!doc.defaultView.frameElement.isConnected)){dispose(doc,state);documents.delete(doc);}}catch(e){documents.delete(doc);}});scanDocument(w.document);}
 // Eine Aktualisierung der Prüfbeobachtung vormerken.
 function queue(){if(!queued){queued=true;w.setTimeout(function(){queued=false;scan();},50);}}
 P.scriptErrors={scan:scan,parse:parse};w.addEventListener('pep-editor-settings',scan);scan();
})(window);
