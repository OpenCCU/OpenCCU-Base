// ReGa-Vorschläge, Objektkatalog und Einrückungslinien bereitstellen.
(function(w){
 'use strict';var P=w.__PEP__;if(!P||P.editor){return;}
 var enabled=false,objects=[],catalogAt=0,catalogSid='',loading=false,revision=0,windows=new WeakSet(),legacy=new WeakMap(),legacyEditors=new Set(),modernViews=new Set();
 var globals='if else elseif while foreach break continue return quit var object string integer real boolean time idarray true false null dom system ID_DEVICES ID_CHANNELS ID_DATAPOINTS ID_SYSTEM_VARIABLES ID_PROGRAMS OT_DEVICE OT_CHANNEL OT_DP OT_VARDP'.split(' ');
 var methods={
  dom:[['GetObject','GetObject(id oder name)','Objekt nach ID oder eindeutigem Namen suchen.']],
  system:[['Date','Date(format)','Aktuelles Datum formatieren.']],
  object:[['ID','ID()','Interne Objekt-ID.'],['Name','Name()','Name des Objekts.'],['Type','Type()','Objekttyp.'],['TypeName','TypeName()','Bezeichnung des Objekttyps.'],['IsTypeOf','IsTypeOf(type)','Objekttyp prüfen.'],['State','State() / State(wert)','Zustand lesen oder einen neuen Zustand setzen.'],['Value','Value()','Gespeicherten Wert lesen.'],['Address','Address()','Geräte- oder Kanaladresse.'],['Channels','Channels()','Kanäle eines Geräts.'],['DPs','DPs()','Datenpunkte eines Kanals.'],['DPByHssDP','DPByHssDP(name)','Datenpunkt eines Kanals suchen.'],['HssType','HssType()','Typbezeichnung.'],['Device','Device()','Zugehöriges Gerät.'],['Channel','Channel()','Zugehöriger Kanal.'],['EnumUsedIDs','EnumUsedIDs()','IDs der verwendeten Aufzählungselemente.'],['EnumUsedNames','EnumUsedNames()','Namen der verwendeten Aufzählungselemente.'],['Count','Count()','Anzahl der Aufzählungselemente.'],['Get','Get(name)','Element einer Aufzählung suchen.'],['GetAt','GetAt(index)','Element anhand seiner Position suchen.']],
  string:[['Length','Length()','Länge der Zeichenkette.'],['Substr','Substr(start, länge)','Teil einer Zeichenkette.'],['Find','Find(text)','Text in einer Zeichenkette suchen.'],['StrValueByIndex','StrValueByIndex(trenner, index)','Teil einer getrennten Zeichenkette.'],['ToInteger','ToInteger()','In eine Ganzzahl umwandeln.'],['ToFloat','ToFloat()','In eine Fließkommazahl umwandeln.'],['ToString','ToString()','In Text umwandeln.']]
 };
 var functions=[['Write','Write(text)','Text ausgeben.'],['WriteLine','WriteLine(text)','Text mit Zeilenumbruch ausgeben.']];
 // Methoden für den aktuellen Ausdruck bestimmen.
 function methodOptions(list){return list.map(function(a){return {label:a[0],type:'function',detail:a[1],info:a[2],apply:/* Den Methodenvorschlag einsetzen. */ function(view,c,from,to){var suffix=view.state.sliceDoc(to,to+1)==='('?a[0]:a[0]+'()';view.dispatch({changes:{from:from,to:to,insert:suffix},selection:{anchor:from+a[0].length+1}});}};});}
 // Prüfen, ob die Eingabe in einem Textliteral steht.
 function inLiteral(text){var quote='',comment=false;for(var i=0;i<text.length;i++){var c=text[i];if(comment){if(c==='\n'){comment=false;}continue;}if(quote){if(c==='\\'){i++;}else if(c===quote){quote='';}continue;}if(c==='"'||c==="'"){quote=c;}else if(c==='!'&&text[i+1]!=='='&&(/\s/.test(text[i-1]||' ')||i===0)){comment=true;}}return !!quote||comment;}
 // Das Ende eines bereits eingegebenen Namens finden.
 function nameEnd(state,pos,quote){var after=state.sliceDoc(pos);for(var k=0;k<after.length&&after[k]!=='\n'&&after[k]!=='\r';k++){if(after[k]==='\\'){k++;}else if(after[k]===quote){return pos+k;}}return pos;}
 // Vorschläge für den aktuellen Cursor-Kontext erzeugen.
 function source(context,waited){
  if(!enabled){return null;}
  if(catalogSid&&catalogSid!==P.sid()){objects=[];catalogAt=0;catalogSid='';revision++;loading=false;}
  readCatalog();
  var before=context.state.sliceDoc(0,context.pos),match=/\bGetObject\s*\(\s*(["'])((?:\\.|[^"'\\\r\n])*)$/.exec(before);
  if(match){
   // Innerhalb von GetObject sind Objektvorschläge sinnvoll. An anderen Stellen bestimmt der Ausdruck die Vorschläge.
   if(inLiteral(before.slice(0,match.index))){return null;}
   if(loading&&!objects.length&&!waited){return new Promise(function(resolve){var start=Date.now();/* Die Vorschläge mit dem geladenen Katalog vervollständigen. */ function ready(){if(context.aborted){resolve(null);}else if(!loading||Date.now()-start>5000){resolve(source(context,true));}else{w.setTimeout(ready,50);}}ready();});}
   var start=context.pos-match[2].length,quote=match[1],counts=Object.create(null);
   objects.forEach(function(o){counts[o.name]=(counts[o.name]||0)+1;});
   return {from:start,options:objects.map(function(o){return {label:o.name,type:o.kind==='Gerät'?'class':'variable',detail:(o.deviceName?o.deviceName+' · ':'')+o.kind+' · '+o.address+' · ID '+o.id,info:counts[o.name]>1?'Mehrfacher Name: zur eindeutigen Zuordnung wird die Objekt-ID eingefügt.':o.kind+' aus dieser Zentrale.',apply:/* Den gewählten Objektnamen einsetzen. */ function(view,c,from,to){
    to=nameEnd(view.state,to,quote);
    if(counts[o.name]>1){var end=to+(view.state.sliceDoc(to,to+1)===quote?1:0);view.dispatch({changes:{from:from-1,to:end,insert:o.id},selection:{anchor:from-1+o.id.length}});}
    else{var value=o.name.replace(/\\/g,'\\\\').split(quote).join('\\'+quote);view.dispatch({changes:{from:from,to:to,insert:value},selection:{anchor:from+value.length}});}
   }};}),validFor:/^[^"'\r\n]*$/};
  }
  if(inLiteral(before)){return null;}
  var token=context.matchBefore(/[A-Za-z_][A-Za-z_0-9]*$/),prefix=token?token.text:'',from=token?token.from:context.pos;
  var left=before.slice(0,from),member=/([A-Za-z_][A-Za-z_0-9]*|\))\.$/.exec(left),options=[];
  if(member){
   var family=member[1]==='dom'?'dom':member[1]==='system'?'system':'object';
   if(family==='object'&&new RegExp('\\bstring\\s+'+member[1].replace(/[^\w]/g,'_')+'\\b').test(before)){family='string';}
   options=methodOptions(methods[family]);
  }else{
   if(!prefix&&!context.explicit){return null;}
   options=globals.map(function(label){return {label:label,type:'keyword'};}).concat(methodOptions(functions));
   var local=/\b(?:var|object|string|integer|real|boolean|time|idarray)\s+([A-Za-z_]\w*)/g,m,seen=Object.create(null);while((m=local.exec(before))){if(!seen[m[1]]){seen[m[1]]=true;options.push({label:m[1],type:'variable',detail:'Lokale Variable'});}}
  }
  return {from:from,options:options,validFor:/^\w*$/};
 }
 // Geräte, Kanäle und Variablen aus der CCU lesen.
 function readCatalog(){
  if(!enabled||typeof w.homematic!=='function'||!P.sid()){return;}
  // Ergebnisse gehören zur aktuellen Sitzung. Antworten aus älteren Ladevorgängen werden verworfen.
  if(catalogSid!==P.sid()){objects=[];catalogAt=0;catalogSid=P.sid();revision++;loading=false;}
  if(loading||Date.now()-catalogAt<300000){return;}loading=true;var generation=++revision,list=[],failed=false,pending=2;
  w.setTimeout(function(){if(loading&&generation===revision){loading=false;revision++;}},30000);
  // Die Katalogabfrage abschließen.
  function finish(){if(--pending){return;}if(generation!==revision){return;}loading=false;objects=list;catalogAt=failed?Date.now()-240000:Date.now();}
  // Ein Objekt in den Vorschlagskatalog aufnehmen.
  function add(item,kind,deviceName){if(item&&/^\d+$/.test(String(item.id))&&typeof item.name==='string'&&item.name){list.push({id:String(item.id),name:item.name,kind:kind,address:String(item.address||''),deviceName:deviceName||''});}}
  w.homematic('SysVar.getAll',{},function(result,error){if(generation!==revision){return;}if(error||!Array.isArray(result)){failed=true;}else{result.forEach(function(s){add(s,'Systemvariable');});}finish();});
  w.homematic('Device.listAll',{},function(ids,error){
   if(generation!==revision){return;}if(error||!Array.isArray(ids)){failed=true;finish();return;}
   var next=0,active=0,finished=false;
   // Die verbleibenden Kataloganfragen mit begrenzter Parallelität starten.
   function pump(){
    if(generation!==revision||!enabled){return;}
    if(next===ids.length&&active===0){if(!finished){finished=true;finish();}return;}
    while(active<2&&next<ids.length){var id=String(ids[next++]);if(!/^\d+$/.test(id)){failed=true;continue;}active++;(function(deviceId){w.homematic('Device.get',{id:deviceId},function(device,err){
     if(generation!==revision){return;}
     if(err||!device){P.api({op:'editor_device',id:deviceId},function(ok,text){
      if(generation!==revision){return;}active--;
      if(ok&&/^OK\r?\n/.test(text)){try{var parentName='';text.split(/\r?\n/).slice(1).forEach(function(line){if(!line){return;}var f=line.split('|'),kind=decodeURIComponent(f[3]);if(kind==='device'){parentName=decodeURIComponent(f[1]);}add({id:f[0],name:decodeURIComponent(f[1]),address:decodeURIComponent(f[2])},kind==='device'?'Gerät':kind==='channel'?'Kanal':kind,kind==='channel'?parentName:'');});}catch(ignore){failed=true;}}
      else{failed=true;}pump();
     });return;}
     active--;add(device,'Gerät');(device.channels||[]).forEach(function(ch){add(ch,'Kanal',device.name);});pump();
    });})(id);}
    if(next===ids.length&&active===0&&!finished){finished=true;finish();}
   }pump();
  });
 }
 source.isEnabled=/* Den aktuellen Status der Editor-Erweiterung abfragen. */ function(){return enabled;};
 // Die sichtbare Einrückung einschließlich Tabs berechnen.
 function indentColumns(text,tabSize){var column=0;for(var i=0;i<text.length;i++){if(text[i]===' '){column++;}else if(text[i]==='\t'){column+=tabSize-column%tabSize;}else{break;}}return column;}
 // Einrückungsebenen für alle Zeilen bestimmen.
 function indentLevels(text,unit,tabSize){
  unit=Math.max(1,Number(unit)||2);tabSize=Math.max(1,Number(tabSize)||2);
  var lines=text.split('\n'),levels=lines.map(function(line){return indentColumns(line,tabSize);}),previous=[],depth=0;
  lines.forEach(function(line,i){previous[i]=depth;if(line.trim()){depth=levels[i]+(/\{\s*$/.test(line)?unit:0);}});
  depth=0;for(var i=lines.length-1;i>=0;i--){if(lines[i].trim()){depth=levels[i]+(/^\s*[}\])]/.test(lines[i])?unit:0);}else{levels[i]=Math.max(levels[i],Math.min(previous[i],depth));}}
  return levels;
 }
 // Die Darstellung der Einrückungslinien vorbereiten.
 function indentLayers(columns,unit,padding){var layers=[];unit=Math.max(1,Number(unit)||2);for(var col=0;col+unit<=columns&&layers.length<64;col+=unit){var x='calc('+padding+'px + '+col+'ch)',right='calc('+padding+'px + '+col+'ch + 1px)';layers.push('linear-gradient(to right, transparent '+x+', var(--pep-indent-guide) '+x+', var(--pep-indent-guide) '+right+', transparent '+right+')');}return layers.length?layers.join(','):'none';}
 source.indentLevels=indentLevels;source.indentLayers=indentLayers;
 // Darstellungsregeln für die Editor-Erweiterung einhängen.
 function editorStyles(doc){
  if(doc.getElementById('pep-editor-guide-style')){return;}
  var style=doc.createElement('style');style.id='pep-editor-guide-style';
  style.textContent=':root{--pep-indent-guide:#b5c7d6}.pep-dark{--pep-indent-guide:#7d95ada6}.CodeMirror pre.CodeMirror-line.pep-indent-line,.cm-editor .cm-line.pep-indent-line{background-image:var(--pep-indent-layers);background-size:100% var(--pep-indent-height,14px);background-repeat:no-repeat}';
  (doc.head||doc.documentElement).appendChild(style);
 }
 // Den nativen Editor als Vorschlagskontext bereitstellen.
 function legacyContext(cm,explicit){
  var text=cm.getValue(),pos=cm.indexFromPos(cm.getCursor());
  return {pos:pos,explicit:explicit,get aborted/* Prüfen, ob die Anfrage inzwischen veraltet ist. */ (){return !enabled||cm.indexFromPos(cm.getCursor())!==pos;},state:{sliceDoc:/* Den gewünschten Ausschnitt aus dem Skript lesen. */ function(a,b){return cm.getValue().slice(a,b);}},matchBefore:/* Den Text direkt vor dem Cursor abgleichen. */ function(regex){var match=regex.exec(text.slice(0,pos));return match?{from:match.index,to:pos,text:match[0]}:null;}};
 }
 // Die nativen Editorpositionen auf Zeichenpositionen abbilden.
 function legacyView(cm){return {state:{sliceDoc:/* Den gewünschten Ausschnitt aus dem Skript lesen. */ function(a,b){return cm.getValue().slice(a,b);}},dispatch:/* Die vorgeschlagene Änderung im nativen Editor anwenden. */ function(transaction){cm.operation(function(){var change=transaction.changes;if(change){cm.replaceRange(change.insert,cm.posFromIndex(change.from),cm.posFromIndex(change.to),'complete');}if(transaction.selection){cm.setCursor(cm.posFromIndex(transaction.selection.anchor));}});cm.focus();}};}
 // Vorschläge für den eingebauten CodeMirror-Editor anpassen.
 function legacyHints(target,cm,explicit){
  var context=legacyContext(cm,explicit),result=source(context);
  // Ergebnisse in native Vorschläge umwandeln.
  function convert(data){
   if(!data||context.aborted){return null;}
   var prefix=cm.getValue().slice(data.from,context.pos).toLowerCase(),from=cm.posFromIndex(data.from),to=cm.posFromIndex(context.pos);
   return {from:from,to:to,list:data.options.filter(function(o){return (o.label+' '+(o.detail||'')).toLowerCase().indexOf(prefix)>=0;}).map(function(option){return {text:option.label,displayText:option.label,hint:/* Den ausgewählten Vorschlag übernehmen. */ function(editor,hints){var a=editor.indexFromPos(hints.from),b=editor.indexFromPos(hints.to);if(option.apply){option.apply(legacyView(editor),option,a,b);}else{editor.replaceRange(option.label,hints.from,hints.to,'complete');}},render:/* Einen Vorschlag im Auswahlmenü anzeigen. */ function(node){
    var label=target.document.createElement('span');label.className='pep-hint-label';label.textContent=option.label;node.appendChild(label);
    if(option.detail){var detail=target.document.createElement('small');detail.className='pep-hint-detail';detail.textContent=option.detail;node.appendChild(detail);}if(option.info){node.title=option.info;}
   }};})};
  }
  return result&&typeof result.then==='function'?result.then(convert):convert(result);
 }
 // Die Erweiterung vom nativen Editor lösen.
 function detachLegacy(cm){
  var record=legacy.get(cm);if(!record||!record.active){return;}record.active=false;w.clearTimeout(record.timer);
  cm.off('inputRead',record.input);cm.off('focus',record.focus);cm.setOption('extraKeys',record.keys);cm.setOption('hintOptions',record.hints);
  w.clearTimeout(record.guideTimer);cm.off('renderLine',record.paint);cm.off('beforeChange',record.invalidateGuides);cm.off('changes',record.redrawGuides);cm.off('optionChange',record.guideOption);
  Array.prototype.forEach.call(cm.getWrapperElement().querySelectorAll('.pep-indent-line'),function(line){line.classList.remove('pep-indent-line');line.style.removeProperty('--pep-indent-layers');line.style.removeProperty('--pep-indent-height');});
  if(cm.state.completionActive){cm.state.completionActive.close();}cm.getWrapperElement().removeAttribute('data-pep-script-editor');legacyEditors.delete(cm);
 }
 // Die Ergänzungen am nativen Editor anbringen.
 function attachLegacy(target,cm){
  if(!enabled||!cm||cm.getOption('readOnly')||cm.getOption('mode')!=='text/x-rega'){return;}
  var record=legacy.get(cm);if(record&&record.active){return;}
  if(!record){record={keys:cm.getOption('extraKeys'),hints:cm.getOption('hintOptions')};legacy.set(cm,record);}
  record.active=true;legacyEditors.add(cm);
  // Vorschläge für den aktuellen nativen Editor abfragen.
  function provider(editor){return legacyHints(target,editor,true);}
  // Die Vorschlagsliste öffnen.
  function show(editor){if(enabled&&!editor.getOption('readOnly')){readCatalog();editor.showHint({hint:provider,completeSingle:false});}}
  record.show=show;
  var keys=Object.assign({},record.keys||{});keys['Ctrl-Space']=show;cm.setOption('extraKeys',keys);cm.setOption('hintOptions',Object.assign({},record.hints||{},{hint:provider,completeSingle:false}));
  record.input=/* Bei geänderter Eingabe die Vorschläge aktualisieren. */ function(editor){w.clearTimeout(record.timer);record.timer=w.setTimeout(function(){
   if(!enabled||editor.getOption('readOnly')||editor.state.completionActive){return;}
   var before=editor.getValue().slice(0,editor.indexFromPos(editor.getCursor()));
   if(/(?:\.\w*|[A-Za-z_]\w+)$/.test(before)||/GetObject\s*\(\s*["'][^"'\r\n]*$/.test(before)){show(editor);}
  },120);};
  record.focus=readCatalog;cm.on('inputRead',record.input);cm.on('focus',record.focus);cm.getWrapperElement().setAttribute('data-pep-script-editor','5');readCatalog();
  record.guideMap=null;
  record.invalidateGuides=/* Die Einrückungslinien zur Neuberechnung vormerken. */ function(){record.guideMap=null;};
  record.paint=/* Sichtbare Einrückungslinien zeichnen. */ function(editor,line,node){
   if(!record.active){return;}
   var unit=Number(editor.getOption('indentUnit'))||2,tab=Number(editor.getOption('tabSize'))||2;
   if(!record.guideMap){record.guideMap=indentLevels(editor.getValue(),unit,tab);}
   var number=editor.getLineNumber(line),layers=indentLayers(record.guideMap[number]||0,unit,4);
   if(layers!=='none'){node.classList.add('pep-indent-line');node.style.setProperty('--pep-indent-layers',layers);node.style.setProperty('--pep-indent-height',editor.defaultTextHeight()+'px');}
  };
  record.redrawGuides=/* Einrückungslinien nach Änderungen aktualisieren. */ function(){record.guideMap=null;w.clearTimeout(record.guideTimer);record.guideTimer=w.setTimeout(function(){if(record.active&&cm.getWrapperElement().isConnected){cm.refresh();}},40);};
  record.guideOption=/* Geänderte Editor-Einrückung übernehmen. */ function(editor,option){if(option==='indentUnit'||option==='tabSize'){record.redrawGuides();}};
  cm.on('renderLine',record.paint);cm.on('beforeChange',record.invalidateGuides);cm.on('changes',record.redrawGuides);cm.on('optionChange',record.guideOption);cm.refresh();
 }
 // Die vorhandene CodeMirror-Integration erweitern.
 function installLegacy(target){
  var doc=target.document,CM=target.CodeMirror;
  if(!doc.getElementById('pep-editor-hints-layer')){var style=doc.createElement('style');style.id='pep-editor-hints-layer';style.textContent='.CodeMirror-hints:has(.pep-hint-label){z-index:100000!important}';(doc.head||doc.documentElement).appendChild(style);}
  Array.prototype.forEach.call(doc.querySelectorAll('.CodeMirror'),function(node){if(node.CodeMirror){attachLegacy(target,node.CodeMirror);}});
  if(windows.has(doc)){return;}windows.add(doc);var original=CM.fromTextArea;
  CM.fromTextArea=/* Neue native Editor-Instanzen mit Vorschlägen verbinden. */ function(textarea,options){var cm=original.call(CM,textarea,options);attachLegacy(target,cm);return cm;};
 }
 // Einen passenden Editor einrichten.
 function install(target,fresh){
  if(enabled){editorStyles(target.document);}
  if(enabled&&target.CodeMirror&&/^5\./.test(target.CodeMirror.version||'')&&typeof target.CodeMirror.showHint==='function'){installLegacy(target);return;}
  if(!enabled||!target.CCUCodeMirror6||!target.CCUCodeMirror6.fromTextArea||windows.has(target.document)){return;}
  windows.add(target.document);var original=target.CCUCodeMirror6.fromTextArea,doc=target.document,typed=false;
  // Eine bereits begonnene Eingabe erkennen.
  function touched(){typed=true;}doc.addEventListener('input',touched,true);
  var script=doc.createElement('script');script.src=P.base+'editor.bundle.js?v='+P.version;script.charset='UTF-8';
  script.onload=/* Nach dem Laden des Zusatzeditors fortfahren. */ function(){
   doc.removeEventListener('input',touched,true);if(!target.__PEP_CM6__){return;}
   target.__PEP_EDITOR_SOURCE__=source;
   // Den Ersatzeditor für das Eingabefeld erzeugen.
   function create(textarea,options){if(!enabled||options&&options.readOnly){return original(textarea,options);}readCatalog();var adapter=target.__PEP_CM6__.fromTextArea(textarea,options);modernViews.add(adapter.view);return adapter;}
   target.CCUCodeMirror6.fromTextArea=create;
   if(target.CodeMirror&&target.CodeMirror.fromTextArea===original){target.CodeMirror.fromTextArea=create;}
   // Nur unbenutzte Eingabefelder auf den Ersatzeditor umstellen. Bereits eingegebener Code bleibt im geöffneten Editor.
   var adapter=target.editor_code;
   if(fresh&&!typed&&enabled&&adapter&&adapter.view){
    var host=adapter.view.dom.closest('.CodeMirror'),textarea=host&&host.previousElementSibling;
    if(textarea&&textarea.tagName==='TEXTAREA'){
     var text=adapter.getValue(),head=adapter.view.state.selection.main.head,styles=host.style.cssText;adapter.view.destroy();host.remove();textarea.value=text;
     var next=create(textarea,{mode:'text/x-rega',lineNumbers:true,foldGutter:true,indentUnit:2,extraKeys:{'Ctrl-Space':'autocomplete','Ctrl-Q':/* Den aktuellen Codeabschnitt ein- oder ausklappen. */ function(cm){cm.foldCode(cm.getCursor());},'Alt-F':'findPersistent','F11':/* Den Vollbildmodus umschalten. */ function(cm){cm.setOption('fullScreen',!cm.getOption('fullScreen'));},'Esc':/* Den Vollbildmodus verlassen. */ function(cm){if(cm.getOption('fullScreen')){cm.setOption('fullScreen',false);}}}});
     next.view.dom.closest('.CodeMirror').style.cssText=styles;
     Object.assign(adapter,next);adapter.view.dispatch({selection:{anchor:Math.min(head,text.length)}});
    }
   }
  };
  script.onerror=/* Einen Ladefehler des Zusatzeditors behandeln. */ function(){windows.delete(doc);doc.removeEventListener('input',touched,true);};(doc.head||doc.documentElement).appendChild(script);
 }
 // Neue Eingabefelder und Dialoge erkennen.
 function scan(){
  legacyEditors.forEach(function(cm){if(!cm.getWrapperElement().isConnected){detachLegacy(cm);}});
  modernViews.forEach(function(view){if(!view.dom.isConnected){modernViews.delete(view);}});
  if(!enabled){return;}install(w,false);
  Array.prototype.forEach.call(w.document.querySelectorAll('iframe'),function(frame){
   if(!frame.__pepEditorLoad){frame.__pepEditorLoad=true;frame.addEventListener('load',function(){try{install(frame.contentWindow,true);}catch(ignore){}});}
   try{if(frame.contentDocument&&frame.contentDocument.readyState==='complete'){install(frame.contentWindow,false);}}catch(ignore){}
  });
 }
 // Den erweiterten Skripteditor ein- oder ausschalten.
 function configure(value){enabled=value===true;if(!enabled){legacyEditors.forEach(detachLegacy);objects=[];catalogAt=0;revision++;loading=false;}else{scan();}modernViews.forEach(function(view){if(view.dom.isConnected){view.dispatch({});}else{modernViews.delete(view);}});w.dispatchEvent(new w.Event('pep-editor-settings'));}
 // Die zentrale Editor-Einstellung nachlesen.
 function refresh(){P.api({op:'editor_settings'},function(ok,text){if(ok&&/^OK\|[01]$/.test(text)){configure(text==='OK|1');}});}
 P.editor={refresh:refresh,source:source,scan:scan,isEnabled:/* Den aktuellen Status der Editor-Erweiterung melden. */ function(){return enabled;},catalog:/* Den aktuellen Objektkatalog bereitstellen. */ function(){return objects.slice();},status:/* Den Ladestatus des Katalogs bereitstellen. */ function(){return {enabled:enabled,legacyInputs:legacyEditors.size,catalogObjects:objects.length,loading:loading};},reloadCatalog:/* Den Objektkatalog neu einlesen. */ function(){catalogAt=0;readCatalog();}};
 P.editor.showSuggestions=/* Die Vorschlagsliste über die Schaltfläche öffnen. */ function(cm){var record=legacy.get(cm);if(enabled&&record&&record.active){cm.focus();record.show(cm);return true;}return false;};
 w.addEventListener('focus',refresh);w.addEventListener('storage',function(e){if(e.key==='ewebui-scripteditor-enabled'){configure(e.newValue==='1');}});
 new w.MutationObserver(scan).observe(w.document.documentElement,{subtree:true,childList:true});refresh();
})(window);
