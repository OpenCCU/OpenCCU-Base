// Navigation und Dialoge für schmale Bildschirme anpassen.
(function(w){
 'use strict';
 if(w.__EWUI_MOBILE__){return;}
 var script=w.document.currentScript,base=script?script.src.replace(/[^/]*$/,''):'/addons/ewebui/',enabled=false,documents=new Map(),pending=false;
 // Die mobile Ansicht ein- oder ausschalten.
 function configure(value){enabled=value===true;scan();}
 // Die zentrale Einstellung für die mobile Ansicht abrufen.
 function request(){
  var x=new w.XMLHttpRequest();x.open('POST',base+'ewebui.cgi',true);x.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
  x.onload=/* Die geladene Mobil-Einstellung übernehmen. */ function(){var text=x.responseText.trim();if(x.status===200&&/^OK\|[01]$/.test(text)){configure(text==='OK|1');}};
  x.send('op=mobile_settings');
 }
 // Die Anpassung nach DOM-Änderungen vormerken.
 function queue(){if(pending){return;}pending=true;w.setTimeout(function(){pending=false;scan();},60);}
 // Das ausgeklappte Menü schließen.
 function closeMenu(doc,state,focus){
  doc.documentElement.classList.remove('pep-mobile-menu-open');
  if(state.button){state.button.setAttribute('aria-expanded','false');if(focus){state.button.focus();}}
 }
 // Die mobile Kopfleiste und Navigation aufbauen.
 function navigation(doc,state,header){
  if(!enabled||!state.shell){
   closeMenu(doc,state,false);if(state.bar){state.bar.remove();state.bar=null;state.button=null;}return;
  }
  if(!state.bar||!state.bar.isConnected){
   var bar=doc.createElement('div'),button=doc.createElement('button'),title=doc.createElement('span');
   bar.id='pep-mobile-topbar';button.type='button';button.id='pep-mobile-menu';button.setAttribute('aria-expanded','false');button.setAttribute('aria-controls','header menubar');
   button.innerHTML='<span class="pep-mobile-burger" aria-hidden="true"></span><span>Men\u00fc</span>';
   title.id='pep-mobile-page';bar.appendChild(button);bar.appendChild(title);state.shell.insertBefore(bar,header);state.bar=bar;state.button=button;state.title=title;
   button.onclick=/* Das mobile Menü auf- oder zuklappen. */ function(){var open=!doc.documentElement.classList.contains('pep-mobile-menu-open');doc.documentElement.classList.toggle('pep-mobile-menu-open',open);button.setAttribute('aria-expanded',String(open));};
  }
  var path=doc.getElementById('PagePath'),full=path?path.textContent.replace(/\s+/g,' ').trim():'OpenCCU',parts=full.split('>'),label=parts[parts.length-1].trim()||'OpenCCU';
  if(state.title.textContent!==label){state.title.textContent=label;state.title.title=full;}
  if(state.path&&state.path!==full){closeMenu(doc,state,false);}state.path=full;
 }
 // Die mobile Vollbildschaltfläche einrichten.
 function fullscreenMenu(doc,state){
  var menu=doc.getElementById('menubar');
  if(!enabled||!menu){if(state.fullscreen){state.fullscreen.remove();state.fullscreen=null;}return;}
  if(!state.fullscreen||!state.fullscreen.isConnected){
   var host=doc.createElement('div'),button=doc.createElement('button');host.id='pep-fullscreen-toggle';host.className='MainMenuItem_Right';button.className='MainMenuItemCaption';button.type='button';button.textContent='Vollbild an/aus';
   var enter=doc.documentElement.requestFullscreen||doc.documentElement.webkitRequestFullscreen;
   button.disabled=!enter;button.title=enter?'Browser-Vollbild umschalten':'Vollbild wird von diesem Browser nicht unterst\u00fctzt.';
   button.onclick=/* Den Browser-Vollbildmodus umschalten. */ function(){
    try{var result;if(doc.fullscreenElement||doc.webkitFullscreenElement){var exit=doc.exitFullscreen||doc.webkitExitFullscreen;result=exit.call(doc);}else{result=enter.call(doc.documentElement);}
     if(result&&result.catch){result.catch(failed);}
    }catch(e){failed();}
   };
   // Eine fehlgeschlagene Vollbildanforderung behandeln.
   function failed(){button.title='Vollbild konnte vom Browser nicht umgeschaltet werden.';button.setAttribute('aria-label',button.title);}
   host.appendChild(button);menu.appendChild(host);state.fullscreen=host;
   state.fullscreenUpdate=/* Den Schaltflächentext an den Vollbildstatus anpassen. */ function(){button.setAttribute('aria-pressed',String(!!(doc.fullscreenElement||doc.webkitFullscreenElement)));};state.fullscreenUpdate();
  }
 }
 // Skriptdialoge für den mobilen Bildschirm anpassen.
 function scriptLayout(doc,state){
  state.editors.forEach(function(observer,wrapper){if(!enabled||!wrapper.isConnected){if(observer){observer.disconnect();}state.editors.delete(wrapper);}});
  if(!enabled){return;}
  var editor=w.__PEP__&&w.__PEP__.editor;
  if(!editor||!editor.isEnabled()){Array.prototype.forEach.call(doc.querySelectorAll('.pep-mobile-suggest'),function(b){b.remove();});}
  // Einen betroffenen Skriptdialog kennzeichnen.
  function mark(area,kind){
   if(!area){return;}var wrapper=area.nextElementSibling;
   if(wrapper&&wrapper.classList.contains('CodeMirror')){
    wrapper.classList.add('pep-mobile-'+kind);
    if(wrapper.CodeMirror&&!state.editors.has(wrapper)){
     var observer=w.ResizeObserver?new w.ResizeObserver(function(){if(wrapper.isConnected){wrapper.CodeMirror.refresh();}}):null;
     state.editors.set(wrapper,observer);if(observer){observer.observe(wrapper);}
    }
    if(kind==='input'&&wrapper.CodeMirror&&editor&&editor.isEnabled()){
     var box=area.closest('#messagebox'),host=box?box.querySelector('.popupTitle'):area.previousElementSibling;
     if(host&&!host.querySelector('.pep-mobile-suggest')){
      var button=doc.createElement('button');button.type='button';button.className='pep-mobile-suggest';button.textContent='Vorschl\u00e4ge';button.setAttribute('aria-label','Skript-Vorschl\u00e4ge anzeigen');
      button.addEventListener('pointerdown',function(e){e.preventDefault();});button.onclick=/* Vorschläge im Skripteditor öffnen. */ function(){editor.showSuggestions(wrapper.CodeMirror);};host.insertBefore(button,host.querySelector('[data-pep-zoom]'));
     }
    }
   }
  }
  Array.prototype.forEach.call(doc.querySelectorAll('.UIFrame'),function(frame){
   var input=frame.querySelector('textarea#code'),output=frame.querySelector('textarea#output');if(!input||!output){return;}
   frame.classList.add('pep-script-tester');mark(input,'input');mark(output,'output');
   var title=frame.querySelector('.UIFrameTitle');if(title&&!title.querySelector('[data-pep-zoom]')){title.appendChild(zoomSelect(doc));}
   if(input.previousElementSibling){input.previousElementSibling.classList.add('pep-mobile-input-label');}
   if(output.previousElementSibling){output.previousElementSibling.classList.add('pep-mobile-output-label');}
   Array.prototype.forEach.call(frame.querySelectorAll('.UIFrameContent > .UIButton'),function(button,i){button.classList.add(i===0?'pep-mobile-run':'pep-mobile-close');});
  });
  var input=doc.querySelector('#messagebox textarea#scrinp'),output=doc.querySelector('#messagebox textarea#scrout');
  if(input&&output){
   var box=input.closest('#messagebox'),table=input.closest('table');box.classList.add('pep-script-program');
   var title=box.querySelector('.popupTitle');if(title&&!title.querySelector('[data-pep-zoom]')){title.appendChild(zoomSelect(doc));}
   if(table){table.classList.add('pep-program-table');if(table.parentElement!==box){table.parentElement.classList.add('pep-program-body');}}
   input.closest('td').classList.add('pep-mobile-input-cell');output.closest('td').classList.add('pep-mobile-output-cell');mark(input,'input');mark(output,'output');
  }
 }
 // Die Auswahl für die Darstellungsgröße erzeugen.
 function zoomSelect(doc){
  var select=doc.createElement('select');select.setAttribute('aria-label','Darstellungsgr\u00f6\u00dfe');select.setAttribute('data-pep-zoom','');
  ['mousedown','pointerdown','touchstart'].forEach(function(type){
   select.addEventListener(type,function(event){event.stopPropagation();});
  });
  [['0.8','Kompakt (80 %)'],['1','Normal (100 %)'],['1.2','Gro\u00df (120 %)']].forEach(function(option){var item=doc.createElement('option');item.value=option[0];item.textContent=option[1];select.appendChild(item);});
  var saved='1';try{saved=w.localStorage.getItem('ewebui-program-zoom')||'1';}catch(ignore){}if(!/^(0\.8|1|1\.2)$/.test(saved)){saved='1';}
  select.value=saved;doc.documentElement.style.setProperty('--pep-program-zoom',saved);
  select.onchange=/* Die gewählte Darstellungsgröße übernehmen. */ function(){doc.documentElement.style.setProperty('--pep-program-zoom',select.value);Array.prototype.forEach.call(doc.querySelectorAll('[data-pep-zoom]'),function(other){other.value=select.value;});try{w.localStorage.setItem('ewebui-program-zoom',select.value);}catch(ignore){}Array.prototype.forEach.call(doc.querySelectorAll('.pep-script-tester .CodeMirror,.pep-script-program .CodeMirror'),function(wrapper){if(wrapper.CodeMirror){wrapper.CodeMirror.refresh();}});};return select;
 }
 // Die mobile Darstellungsgröße anwenden.
 function programZoom(doc,state){
  if(!enabled||!state.shell){if(state.zoom){state.zoom.remove();state.zoom=null;}return;}
  if(!state.zoom||!state.zoom.isConnected){
   var bar=doc.createElement('label'),select=zoomSelect(doc);bar.id='pep-mobile-zoom';
   bar.appendChild(select);state.bar.appendChild(bar);state.zoom=bar;
  }
 }
 // Die aktuellen Layoutregeln anwenden.
 function apply(doc){
  if(doc.querySelector('#printDiv')||/\/addons\/pep\/print\.html$/.test(doc.location.pathname)){return;}
  var state=documents.get(doc);
  if(!state){
   state={meta:null,created:false,content:null,shell:null,editors:new Map()};documents.set(doc,state);
   var view=doc.defaultView;
   // Die Ansichtsbreite des Browsers festlegen.
   function viewport(){var vv=view.visualViewport;doc.documentElement.style.setProperty('--pep-mobile-height',(vv?vv.height:view.innerHeight)+'px');doc.documentElement.style.setProperty('--pep-mobile-top',(vv?vv.offsetTop:0)+'px');}
   if(view.visualViewport){view.visualViewport.addEventListener('resize',viewport);view.visualViewport.addEventListener('scroll',viewport);}else{view.addEventListener('resize',viewport);}viewport();
   state.dispose=/* Mobile Anpassungen entfernen. */ function(){state.observer.disconnect();state.editors.forEach(function(observer){if(observer){observer.disconnect();}});if(view.visualViewport){view.visualViewport.removeEventListener('resize',viewport);view.visualViewport.removeEventListener('scroll',viewport);}else{view.removeEventListener('resize',viewport);}};
   var link=doc.createElement('link');link.rel='stylesheet';link.href=base+'mobile.css?v=1.1.0';link.id='pep-mobile-css';(doc.head||doc.documentElement).appendChild(link);
   var observer=new w.MutationObserver(queue);observer.observe(doc.documentElement,{childList:true,subtree:true});state.observer=observer;
   doc.addEventListener('fullscreenchange',function(){if(state.fullscreenUpdate){state.fullscreenUpdate();}});doc.addEventListener('webkitfullscreenchange',function(){if(state.fullscreenUpdate){state.fullscreenUpdate();}});
   doc.addEventListener('keydown',function(e){if(e.key==='Escape'&&doc.documentElement.classList.contains('pep-mobile-menu-open')){closeMenu(doc,state,true);}});
   doc.addEventListener('click',function(e){
    if(!enabled||!state.bar||!doc.documentElement.classList.contains('pep-mobile-menu-open')){return;}
    var target=e.target.nodeType===1?e.target:e.target.parentElement;
    if(target.closest('#pep-mobile-topbar')){return;}
    if(target.closest('.MainMenuSubItem,#menuStartPage,#btnLogOut,#btnReGaSave,#btnLogOutGuest')||!target.closest('#header,#menubar,.MainMenuSubMenu')){closeMenu(doc,state,false);}
   });
  }
  doc.documentElement.classList.toggle('pep-mobile',enabled);
  if(enabled&&!state.meta){
   state.meta=doc.querySelector('meta[name="viewport"]');state.created=!state.meta;
   if(!state.meta){state.meta=doc.createElement('meta');state.meta.name='viewport';(doc.head||doc.documentElement).appendChild(state.meta);}
   state.content=state.meta.getAttribute('content');state.meta.setAttribute('content','width=device-width,initial-scale=1');
  }else if(!enabled&&state.meta){
   if(state.created){state.meta.remove();}else if(state.content===null){state.meta.removeAttribute('content');}else{state.meta.setAttribute('content',state.content);}
   state.meta=null;
  }
  var header=doc.getElementById('header'),content=doc.getElementById('content'),shell=header&&header.parentElement;
  if(state.shell&&state.shell!==shell){state.shell.classList.remove('pep-mobile-shell');}
  state.shell=shell&&content&&content.parentElement===shell?shell:null;
  if(state.shell){state.shell.classList.toggle('pep-mobile-shell',enabled);}
  navigation(doc,state,header);
  fullscreenMenu(doc,state);
  programZoom(doc,state);
  scriptLayout(doc,state);
  Array.prototype.forEach.call(doc.querySelectorAll('iframe'),function(frame){
   if(!frame.__ewuiMobileLoad){frame.__ewuiMobileLoad=true;frame.addEventListener('load',queue);}
   try{if(frame.contentDocument&&frame.contentDocument.documentElement){apply(frame.contentDocument);}}catch(ignore){}
  });
 }
 // Neue Ansichten erkennen und anpassen.
 function scan(){
  documents.forEach(function(state,doc){try{if(doc!==w.document&&(!doc.defaultView||!doc.defaultView.frameElement||!doc.defaultView.frameElement.isConnected)){state.dispose();documents.delete(doc);}}catch(ignore){state.dispose();documents.delete(doc);}});
  apply(w.document);
 }
 w.__EWUI_MOBILE__={configure:configure,refresh:request,isEnabled:/* Den aktuellen Status der mobilen Ansicht melden. */ function(){return enabled;}};
 w.addEventListener('focus',request);w.addEventListener('storage',function(e){if(e.key==='ewebui-mobile-enabled'){configure(e.newValue==='1');}});
 w.addEventListener('pep-editor-settings',queue);
 request();
})(window);
