// Den Benutzerkontodialog um Ziehgriffe und Größenänderung ergänzen.
(function(w){
 'use strict';var P=w.__PEP__,d=w.document;if(!P||P.userAccount){return;}
 var enabled=false,revision=0,drag=null,moving=false,dialogState=null,observer=null;
 // Passende Elemente im Benutzerkonto sammeln.
 function all(q,root){return Array.prototype.slice.call((root||d).querySelectorAll(q));}
 // Die sortierbaren Systemvariablen im Benutzerkonto bestimmen.
 function rows(){var result=[];all('#userSysVarTbl [onclick*="iseUser.MoveSysVar("]').forEach(function(a){
  var m=/iseUser\.MoveSysVar\(\s*([1-9][0-9]*)\s*,\s*([1-9][0-9]*)\s*,\s*(-?1)\s*\)/.exec(a.getAttribute('onclick')||''),r=a.closest('tr[id]');
  if(m&&r&&!result.some(function(x){return x.row===r;})){result.push({row:r,uid:m[1],id:m[2],arrow:a.closest('td').closest('table')});}
 });return result;}
 // Eine laufende Ziehbewegung beenden.
 function cancel(){if(drag){w.cancelAnimationFrame(drag.frame);try{drag.h.releasePointerCapture(drag.pointer);}catch(ignore){}drag=null;}all('.pep-account-target,.pep-account-before').forEach(function(e){e.classList.remove('pep-account-target','pep-account-before');});}
 // Die ursprüngliche Dialogdarstellung wiederherstellen.
 function restoreDialog(){if(!dialogState){return;}dialogState.resize.disconnect();if(dialogState.dragHandle!==undefined&&w.jQuery&&w.jQuery(dialogState.el).hasClass('ui-draggable')){w.jQuery(dialogState.el).draggable('option','handle',dialogState.dragHandle);}dialogState.el.classList.remove('pep-account-dialog');Object.keys(dialogState.before).forEach(function(k){if(dialogState.el.querySelector('#userSysVarTbl')||dialogState.el.style.getPropertyValue(k)===dialogState.owned[k]){var old=dialogState.before[k];if(old.value){dialogState.el.style.setProperty(k,old.value,old.priority);}else{dialogState.el.style.removeProperty(k);}}});dialogState.el.style.removeProperty('--pep-account-list-height');dialogState=null;}
 // Den Dialog positionieren und die Ziehgriffe ergänzen.
 function scan(){
  if(!enabled){all('.pep-account-arrows').forEach(function(e){e.classList.remove('pep-account-arrows');});all('.pep-account-handle').forEach(function(e){e.remove();});cancel();restoreDialog();return;}
  var list=d.getElementById('userSysVarTbl'),box=list&&list.closest('#messagebox');
  if(dialogState&&(!box||dialogState.el!==box)){restoreDialog();}
  if(box&&!dialogState&&w.ResizeObserver){
   var rect=box.getBoundingClientRect(),listHeight=list.getBoundingClientRect().height;
   var width=Math.min(Math.max(800,rect.width),w.innerWidth-24),height=Math.min(Math.max(550,rect.height),w.innerHeight-24);
   var before={};['position','left','top','margin','width','height'].forEach(function(k){before[k]={value:box.style.getPropertyValue(k),priority:box.style.getPropertyPriority(k)};});
   dialogState={el:box,before:before,owned:{},initialHeight:rect.height,listHeight:listHeight};
   box.style.setProperty('position','fixed','important');box.style.setProperty('left',Math.max(12,(w.innerWidth-width)/2)+'px');box.style.setProperty('top',Math.max(12,(w.innerHeight-height)/2)+'px');box.style.setProperty('margin','0','important');box.style.setProperty('width',width+'px');box.style.setProperty('height',height+'px');box.classList.add('pep-account-dialog');Object.keys(before).forEach(function(k){dialogState.owned[k]=box.style.getPropertyValue(k);});
   var state=dialogState;if(w.jQuery&&w.jQuery.fn.draggable&&w.jQuery(box).hasClass('ui-draggable')){state.dragHandle=w.jQuery(box).draggable('option','handle');w.jQuery(box).draggable('option','handle','.popupTitle');}
   state.resize=new w.ResizeObserver(function(){if(dialogState!==state){return;}var footer=box.querySelector('#svt3'),h=Math.max(80,box.getBoundingClientRect().bottom-list.getBoundingClientRect().top-(footer?footer.getBoundingClientRect().height:40)-16);box.style.setProperty('--pep-account-list-height',h+'px');});state.resize.observe(box);
  }
  rows().forEach(function(item){if(item.row.querySelector('.pep-account-handle')){return;}var h=d.createElement('button');h.type='button';h.className='pep-handle pep-account-handle';h.title='Systemvariable auf der Startseite verschieben (sofort gespeichert)';h.setAttribute('aria-label','Systemvariable verschieben');h.dataset.uid=item.uid;h.dataset.id=item.id;
   item.arrow.parentNode.appendChild(h);item.arrow.classList.add('pep-account-arrows');
  });
 }
 // Die Benutzerkonto-Erweiterung umschalten.
 function configure(value){revision++;enabled=value===true;scan();}
 // Die zentrale Benutzerkonto-Einstellung lesen.
 function refresh(){var token=revision;P.api({op:'useraccount_settings'},function(ok,text){if(token===revision&&ok&&/^OK\|[01]$/.test(text)){configure(text==='OK|1');}});}
 // Die aktuelle Reihenfolge der Variablen ermitteln.
 function ids(uid){return rows().filter(function(r){return r.uid===uid;}).map(function(r){return r.id;});}
 // Einen Sortierfehler behandeln.
 function fail(){moving=false;w.alert('Enhanced WebUI: Die Sortierung wurde nicht bestätigt und angehalten. Bitte die aktuelle Reihenfolge prüfen. Bereits bestätigte Einzelschritte bleiben gespeichert.');}
 // Einen nativen Verschiebeschritt ausführen.
 function step(state,order,targetIndex){
  if(!enabled||!d.getElementById('userSysVarTbl')){moving=false;return;}
  if(ids(state.uid).join(',')!==order.join(',')){fail();return;}
  var at=order.indexOf(state.id);if(at===targetIndex){moving=false;scan();return;}
  var direction=targetIndex>at?1:-1,next=order.slice(),swap=next[at+direction];next[at+direction]=state.id;next[at]=swap;
  var root=d.getElementById('userSysVarTbl'),finished=false;
  var watch=new w.MutationObserver(function(){if(ids(state.uid).join(',')===next.join(',')){finished=true;watch.disconnect();w.clearTimeout(timeout);step(state,next,targetIndex);}});
  watch.observe(root,{childList:true,subtree:true});
  var timeout=w.setTimeout(function(){if(!finished){watch.disconnect();fail();}},8000);
  try{w.iseUser.MoveSysVar(Number(state.uid),Number(state.id),direction);}catch(ignore){watch.disconnect();w.clearTimeout(timeout);fail();}
 }
 d.addEventListener('pointerdown',function(e){var h=e.target.closest&&e.target.closest('.pep-account-handle');if(!h||!enabled||moving||e.button!==0){return;}e.preventDefault();cancel();drag={h:h,pointer:e.pointerId,uid:h.dataset.uid,id:h.dataset.id,x:e.clientX,y:e.clientY,active:false};try{h.setPointerCapture(e.pointerId);}catch(ignore){}},true);
 // Das Ziel der Ziehbewegung bestimmen.
 function locate(state){
  all('.pep-account-target,.pep-account-before').forEach(function(r){r.classList.remove('pep-account-target','pep-account-before');});
  var list=d.getElementById('userSysVarTbl');if(!list){return;}var bounds=list.getBoundingClientRect();state.target=null;
  if(state.x<bounds.left||state.x>bounds.right||state.y<bounds.top-20||state.y>bounds.bottom+20){return;}
  var candidates=rows().filter(function(r){return r.uid===state.uid&&r.id!==state.id&&r.row.getBoundingClientRect().bottom>bounds.top&&r.row.getBoundingClientRect().top<bounds.bottom;});
  if(!candidates.length){return;}
  var target=candidates[candidates.length-1],before=false;
  for(var i=0;i<candidates.length;i++){var rect=candidates[i].row.getBoundingClientRect(),top=Math.max(bounds.top,rect.top),bottom=Math.min(bounds.bottom,rect.bottom);if(state.y<(top+bottom)/2){target=candidates[i];before=true;break;}}
  state.target=target;state.before=before;target.row.classList.add(before?'pep-account-before':'pep-account-target');
 }
 // Beim Ziehen am Listenrand weiter scrollen.
 function scrollDrag(){
  if(!drag||!drag.active){return;}var list=d.getElementById('userSysVarTbl');if(!list){return;}var r=list.getBoundingClientRect();
  if(drag.x>=r.left&&drag.x<=r.right&&drag.y>=r.top-20&&drag.y<=r.bottom+20){if(drag.y<r.top+28){list.scrollTop-=10;}else if(drag.y>r.bottom-28){list.scrollTop+=10;}}
  locate(drag);drag.frame=w.requestAnimationFrame(scrollDrag);
 }
 d.addEventListener('pointermove',function(e){if(!drag||e.pointerId!==drag.pointer){return;}if(!drag.active&&Math.abs(e.clientX-drag.x)+Math.abs(e.clientY-drag.y)<7){return;}var started=!drag.active;drag.active=true;drag.x=e.clientX;drag.y=e.clientY;e.preventDefault();locate(drag);if(started){drag.frame=w.requestAnimationFrame(scrollDrag);}},true);
 d.addEventListener('pointerup',function(e){if(!drag||e.pointerId!==drag.pointer){return;}drag.x=e.clientX;drag.y=e.clientY;locate(drag);var state=drag,target=state.target;cancel();if(!enabled||!state.active||!target||!w.iseUser||typeof w.iseUser.MoveSysVar!=='function'){return;}e.preventDefault();var order=ids(state.uid),next=order.filter(function(id){return id!==state.id;}),at=next.indexOf(target.id)+(state.before?0:1);moving=true;step(state,order,at);},true);
 d.addEventListener('pointercancel',cancel,true);d.addEventListener('keydown',function(e){if(e.key==='Escape'){cancel();}},true);
 if(w.MutationObserver){observer=new w.MutationObserver(function(){scan();observer.takeRecords();});observer.observe(d.documentElement,{subtree:true,childList:true});}
 w.addEventListener('resize',function(){if(!dialogState){return;}var box=dialogState.el,r=box.getBoundingClientRect();box.style.left=Math.max(12,Math.min(r.left,w.innerWidth-r.width-12))+'px';box.style.top=Math.max(12,Math.min(r.top,w.innerHeight-r.height-12))+'px';});
 w.addEventListener('focus',refresh);w.addEventListener('storage',function(e){if(e.key==='ewebui-useraccount-enabled'){configure(e.newValue==='1');}});
 P.userAccount={scan:scan,configure:configure,isEnabled:/* Den aktuellen Status der Benutzerkonto-Erweiterung melden. */ function(){return enabled;}};refresh();
})(window);
