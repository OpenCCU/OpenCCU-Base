# Den getrennten Datenspeicher für Programm- und Systemvariablengruppen bestimmen.
proc pep_groups_path {kind} {
  global pep_var
  if {$kind == "variables"} {return "$pep_var/system-variable-groups.tcldata"}
  return "$pep_var/program-groups.tcldata"
}

# Gruppen, Zuordnungen und den Stand der letzten Änderung einlesen.
proc pep_groups_read {{kind programs}} {
  set path [pep_groups_path $kind]
  if {![file exists $path]} {return [list 0 {} {} 0]}
  set f [open $path r]
  fconfigure $f -encoding utf-8
  set data [read $f]
  close $f
  if {[llength $data] == 3} {lappend data 0}
  if {[llength $data] != 4} {error "Ungueltige Gruppendatei"}
  return $data
}

# Gruppen und Zuordnungen für die jeweilige Übersicht bereitstellen.
proc pep_groups_response {data admin} {
  set out "OK|$admin\nV|[lindex $data 3]"
  foreach group [lindex $data 1] {
    append out "\nG|[lindex $group 0]|0|[pep_editor_uri [lindex $group 2]]"
  }
  foreach assignment [lindex $data 2] {
    append out "\nP|[lindex $assignment 0]|[lindex $assignment 1]"
  }
  return $out
}

# Die Objekt-IDs der jeweiligen WebUI-Liste und bei Bedarf die Namen lesen.
proc pep_groups_objects {names kind} {
  set collection ID_PROGRAMS
  set valid {(p.IsTypeOf(OT_PROGRAM) && (p.ProgramCopyID()==ID_ERROR))}
  if {$kind == "variables"} {
    set collection ID_SYSTEM_VARIABLES
    set valid {(p.IsTypeOf(OT_VARDP) || p.IsTypeOf(OT_ALARMDP))}
  }
  set line {WriteLine(p.ID());}
  if {$names} {set line {WriteLine(p.ID()#"|"#p.Name());}}
  return [pep_rega "
    object programs = dom.GetObject($collection);
    if (programs) {
      string id;
      foreach (id, programs.EnumEnabledIDs()) {
        object p = dom.GetObject(id);
        if (p) {
          if $valid { $line }
        }
      }
      WriteLine(\"DONE\");
    }"]
}

# Die Auswahlliste für die Gruppenverwaltung zusammenstellen.
proc pep_groups_catalog {{kind programs}} {
  set lines [split [string trim [pep_groups_objects 1 $kind]] \n]
  if {[string trim [lindex $lines end]] != "DONE"} {return "ERR|Auswahlliste konnte nicht geladen werden"}
  set out OK
  foreach line [lrange $lines 0 end-1] {
    if {[regexp {^([1-9][0-9]*)\|(.*)$} [string trimright $line \r] all id name] && [pep_is_id $id]} {
      append out "\n$id|[pep_editor_uri $name]"
    }
  }
  return $out
}

# Eine Gruppe und ihre vollständige Auswahl gemeinsam speichern.
proc pep_groups_change {action gid revision name ids {kind programs}} {
  set data [pep_groups_read $kind]
  set sequence [lindex $data 0]
  set groups [lindex $data 1]
  set assignments [lindex $data 2]
  set current [lindex $data 3]
  if {[string compare $revision $current] != 0} {return "ERR|Gruppen wurden inzwischen geaendert. Bitte die Bearbeitung neu oeffnen."}
  set index -1
  set i 0
  foreach group $groups {
    if {[lindex $group 0] == $gid} {set index $i}
    incr i
  }
  if {[string compare $gid "0"] != 0 && (![pep_is_id $gid] || $index < 0)} {return "ERR|Gruppe nicht gefunden"}
  if {$action == "save"} {
    set name [string trim $name]
    if {$name == "" || [string length $name] > 80 || [regexp {[[:cntrl:]]} $name]} {
      return "ERR|Bitte einen Gruppennamen mit 1 bis 80 Zeichen eingeben"
    }
    foreach group $groups {
      if {[lindex $group 0] != $gid && [string compare [string tolower [lindex $group 2]] [string tolower $name]] == 0} {
        return "ERR|Gruppenname bereits vorhanden"
      }
    }
    set selected [split $ids ,]
    if {[llength $selected]} {
      set available [split [string trim [pep_groups_objects 0 $kind]] \n]
      if {[string trim [lindex $available end]] != "DONE"} {return "ERR|Auswahl konnte nicht geprueft werden"}
      foreach id [lrange $available 0 end-1] {
        set id [string trim $id]
        if {[pep_is_id $id]} {set valid($id) 1}
      }
      foreach id $selected {
        if {![pep_is_id $id] || ![info exists valid($id)] || [info exists chosen($id)]} {return "ERR|Ungueltige Auswahl"}
        set chosen($id) 1
      }
    }
    if {$index < 0} {
      if {[llength $groups] >= 500 || $sequence >= 2147483646} {return "ERR|Gruppenlimit erreicht"}
      set gid [incr sequence]
      lappend groups [list $gid 0 $name]
    } else {
      set groups [lreplace $groups $index $index [list $gid 0 $name]]
    }
  } elseif {$action == "delete" && $index >= 0} {
    set selected {}
    set groups [lreplace $groups $index $index]
  } else {
    return "ERR|Unbekannte Gruppenaenderung"
  }

  # Jeder Eintrag gehört höchstens einer Gruppe an. Die neue Auswahl ersetzt
  # die bisherige Zuordnung erst zusammen mit dem Speichern der Gruppe.
  set remaining {}
  foreach assignment $assignments {
    if {[lindex $assignment 1] != $gid && ![info exists chosen([lindex $assignment 0])]} {
      lappend remaining $assignment
    }
  }
  foreach id $selected {lappend remaining [list $id $gid]}

  # Leser sehen durch das Ersetzen der Datei entweder den alten oder den neuen Stand.
  set data [list $sequence $groups $remaining [incr current]]
  set path [pep_groups_path $kind]
  set f [open "$path.tmp" w]
  fconfigure $f -encoding utf-8
  puts $f $data
  close $f
  file rename -force "$path.tmp" $path
  return [pep_groups_response $data 1]
}

