// Die Gruppenverwaltung für Programme und Systemvariablen einbinden.
(function (w) {
  'use strict';
  const P = w.__PEP__, d = w.document;
  if (!P || P.programGroups) { return; }

  createGroups({
    kind: 'programs', module: 'programGroups', option: 'programgroups',
    editTable: 'ProgramListTable', statusTable: 'ProgramListTable', rowId: /^(?:program|pr)(\d+)$/,
    storageKey: 'ewebui-program-group-rows', menuAnchor: 'submenuCreateGroups', tileAnchor: 'btnSettingsGroups_container',
    title: 'Programmgruppen', newTitle: 'Neue Programmgruppe', editTitle: 'Programmgruppe bearbeiten',
    singular: 'Programm', plural: 'Programme', assigned: 'Zugeordnete Programme', count: 'Programmanzahl'
  });
  createGroups({
    kind: 'variables', module: 'systemVariableGroups', option: 'sysvargroups',
    editTable: 'sysVars', statusTable: 'sysvarsListTable', rowId: /^(?:sv|sysvar)(\d+)$/,
    storageKey: 'ewebui-system-variable-group-rows', menuAnchor: 'submenuCreateGroups', tileAnchor: 'btnSettingsGroups_container',
    title: 'Systemvariablengruppen', newTitle: 'Neue Systemvariablengruppe', editTitle: 'Systemvariablengruppe bearbeiten',
    singular: 'Systemvariable', plural: 'Systemvariablen', assigned: 'Zugeordnete Systemvariablen', count: 'Variablenanzahl'
  });

  // Eine Gruppenverwaltung mit eigenem Katalog, Datenspeicher und Ansichtsstatus betreiben.
  function createGroups(config) {
    const {storageKey} = config;
    const isProgram = config.kind === 'programs';
    const menuId = isProgram ? 'pep-program-groups-menu' : 'pep-sysvar-groups-menu';
    const tileId = isProgram ? 'pep-program-groups-tile' : 'pep-sysvar-groups-tile';
    const settingsKey = 'ewebui-' + config.option + '-enabled';
    let savedViews;
    try { savedViews = JSON.parse(w.sessionStorage.getItem(storageKey)); } catch (error) {}
    const views = {edit: restoreView('edit', savedViews), status: restoreView('status', savedViews)};
    let enabled = false, admin = false, revision = '0';
    let groups = new Map(), assignments = new Map();
    let table = null, list = null, footer = null;
    let manager = null, editor = null, request = 0, settingRequest = 0, queued = false;

    // Ein Element mit Text erzeugen, auch für Namen aus der Zentrale.
    function element(tag, text, className) {
      const node = d.createElement(tag);
      if (text !== undefined) { node.textContent = text; }
      if (className) { node.className = className; }
      return node;
    }

    // Eine Schaltfläche mit ihrer Aktion verbinden.
    function button(text, action, className = 'StdButton') {
      const node = element('button', text, className);
      node.type = 'button';
      node.addEventListener('click', action);
      return node;
    }

    // Ein Element auch dann sicher entfernen, wenn die WebUI bereits navigiert hat.
    function remove(node) {
      if (node && node.parentNode) { node.parentNode.removeChild(node); }
    }

    // Eine erfolgreiche Antwort als vollständigen Stand übernehmen.
    function accept(ok, text) {
      const lines = text.trim().split(/\r?\n/);
      if (!ok || !/^OK\|[01]$/.test(lines[0])) { return false; }
      const nextGroups = new Map(), nextAssignments = new Map();
      let nextRevision = '0';
      try {
        lines.slice(1).forEach(line => {
          const [kind, id, parent, name] = line.split('|');
          if (kind === 'V') { nextRevision = id; }
          if (kind === 'G') { nextGroups.set(id, decodeURIComponent(name)); }
          if (kind === 'P') { nextAssignments.set(id, parent); }
        });
      } catch (error) { return false; }
      groups = nextGroups;
      assignments = nextAssignments;
      revision = nextRevision;
      admin = lines[0] === 'OK|1';
      return true;
    }

    // Gruppen aus der Zentrale nachladen und ältere Antworten verwerfen.
    function refresh(done) {
      if (!enabled || !P.sid()) { if (done) { done(false); } return; }
      const current = ++request;
      P.api({op: 'groups_get', kind: config.kind}, (ok, text) => {
        if (current !== request || !enabled) { return; }
        const accepted = accept(ok, text);
        scan();
        if (P.filters) { P.filters.scan(); }
        if (done) { done(accepted); }
      });
    }

    // Die Einträge der jeweiligen Tabelle erkennen. Kopf-, Filter- und Gruppenzeilen bleiben außen vor.
    function itemRows(target) {
      return Array.prototype.slice.call(target.rows).filter(row => config.rowId.test(row.id));
    }

    // Die Objekt-ID aus der Kennung der Tabellenzeile lesen.
    function itemId(row) {
      return config.rowId.exec(row.id)[1];
    }

    // Aufklappzustand als ID-Liste speichern. Die WebUI hat eine eigene JSON-Serialisierung für Arrays.
    function remember() {
      const saved = {};
      Object.keys(views).forEach(key => {
        const state = views[key];
        saved[key] = {closed: [...state.closed].join(','), direction: state.direction};
      });
      try { w.sessionStorage.setItem(storageKey, JSON.stringify(saved)); } catch (error) {}
    }

    // Gespeicherte Gruppen-IDs als eindeutige Schlüssel für den geöffneten Tab übernehmen.
    function restoreView(key, saved) {
      const view = saved?.[key];
      const closed = new Set();
      let ids = view?.closed;
      if (typeof ids === 'string') {
        // Je nach Prototype-Version wurden frühere Arrays als JSON-Text gespeichert.
        if (ids.startsWith('[')) {
          try { ids = JSON.parse(ids); } catch (error) { ids = []; }
        } else { ids = ids.split(','); }
      }
      if (Array.isArray(ids)) {
        for (const id of ids) {
          const value = String(id);
          if (/^[1-9]\d*$/.test(value)) { closed.add(value); }
        }
      }
      return {closed, direction: view?.direction === -1 ? -1 : 1};
    }

    // Einzelne Gruppen und den Sammelschalter über dieselbe Zustandsänderung bedienen.
    function setGroupsOpen(ids, open) {
      for (const id of ids) {
        if (open) { list.state.closed.delete(id); }
        else { list.state.closed.add(id); }
      }
      remember();
      arrange();
      if (P.filters) { P.filters.scan(); }
    }

    // Den Zustand eines einzelnen Blocks umschalten.
    function toggleGroup(id) {
      setGroupsOpen([id], list.state.closed.has(id));
    }

    // Alle Gruppen öffnen, sobald mindestens eine davon geschlossen ist.
    function toggleAll() {
      const ids = [...groups.keys()];
      setGroupsOpen(ids, ids.some(id => list.state.closed.has(id)));
    }

    // Symbol und Gruppenname bilden eine gemeinsame Schaltfläche.
    function groupHeader(id) {
      const row = element('tr', undefined, 'pep-program-group-row');
      const name = element('td', undefined, 'pep-program-group-name');
      const toggle = button(undefined, () => toggleGroup(id), 'pep-program-group-toggle');
      const label = element('span', undefined, 'pep-program-group-label');
      toggle.append(label);
      name.append(toggle);
      const count = element('td', undefined, 'pep-program-group-count');
      const total = element('span', undefined, 'pep-program-group-total');
      count.append(element('span', config.count, 'pep-program-group-count-label'), total);
      const rest = element('td', undefined, 'pep-program-group-rest');
      row.append(name, count, rest);
      return {row, rest, toggle, label, total};
    }

    // Gruppenblöcke und ungruppierte Einträge im vorhandenen Tabellenkörper anordnen.
    function arrange() {
      if (!table || !list || !groups.size) { return; }
      const rows = itemRows(table);
      const parent = rows[0]?.parentNode || table.tBodies[table.tBodies.length - 1];
      if (!parent || !rows.every(row => row.parentNode === parent)) { return; }

      // Die ursprüngliche Reihenfolge der Einträge bleibt pro Tabelle erhalten.
      // Der Spaltenvergleich darf nur die Zeilen ohne Gruppenzuordnung umsortieren.
      const currentRows = new Set(rows);
      list.original = list.original.filter(row => currentRows.has(row));
      const original = new Set(list.original);
      rows.forEach(row => { if (!original.has(row)) { list.original.push(row); } });
      const members = new Map([...groups.keys()].map(id => [id, []]));
      const standalone = new Set();
      list.original.forEach(row => {
        const id = assignments.get(itemId(row));
        if (members.has(id)) { members.get(id).push(row); }
        else { standalone.add(row); }
        row.classList.toggle('pep-program-group-member', members.has(id));
        row.classList.toggle('pep-group-hidden', members.has(id) && list.state.closed.has(id));
      });

      list.headers.forEach((header, id) => {
        if (!groups.has(id)) { remove(header.row); list.headers.delete(id); }
      });
      const width = rows[0]?.cells.length || table.rows[0]?.cells.length || 1;
      const ordered = [];
      [...groups].sort((a, b) => list.state.direction * a[1].localeCompare(b[1], 'de', {sensitivity: 'base'})).forEach(([id, name]) => {
        if (!list.headers.has(id)) { list.headers.set(id, groupHeader(id)); }
        const header = list.headers.get(id), open = !list.state.closed.has(id);
        const remainingColumns = Math.max(1, width - 2);
        if (header.rest.colSpan !== remainingColumns) { header.rest.colSpan = remainingColumns; }
        if (header.label.textContent !== name) { header.label.textContent = name; }
        const count = String(members.get(id).length);
        if (header.total.textContent !== count) { header.total.textContent = count; }
        header.toggle.setAttribute('aria-expanded', String(open));
        header.toggle.setAttribute('aria-label', name + (open ? ' schließen' : ' öffnen'));
        ordered.push(header.row, ...members.get(id));
      });
      (list.sorted || []).forEach(row => { if (standalone.delete(row)) { ordered.push(row); } });
      ordered.push(...standalone);

      // Nur umhängen, wenn sich die sichtbare Struktur ändert. Filter, Aktionen
      // und zusätzliche Spalten arbeiten dadurch weiter mit den nativen Zeilen.
      const current = Array.prototype.slice.call(parent.rows).filter(row =>
        row.classList.contains('pep-program-group-row') || config.rowId.test(row.id));
      if (current.length !== ordered.length || ordered.some((row, i) => row !== current[i])) {
        ordered.forEach(row => parent.appendChild(row));
      }
    }

    // Die Sortierung aus der erweiterten Filterleiste in die Gruppenansicht übernehmen.
    function sort(target, isName, direction, sorted) {
      if (target !== table || !list || !groups.size) { return false; }
      if (isName) { list.state.direction = direction; remember(); }
      list.sorted = sorted;
      arrange();
      return true;
    }

    // Bei aktiven Gruppen den nativen Namensklick ohne Seitenwechsel behandeln.
    function nativeNameSort(event) {
      if (!table || !list || !groups.size || (P.filters && P.filters.isEnabled())) { return; }
      const header = event.target.closest?.('[onclick*="IseSort("],[onclick*="DivSort("]');
      const firstCell = table.rows[0]?.cells[0];
      if (!header || header.closest('table') !== table || !firstCell?.contains(header)) { return; }
      event.preventDefault();
      event.stopImmediatePropagation();
      const direction = -list.state.direction;
      const rows = itemRows(table).sort((a, b) => direction *
        a.cells[0].textContent.trim().localeCompare(b.cells[0].textContent.trim(), 'de', {sensitivity: 'base'}));
      sort(table, true, direction, rows);
      header.setAttribute('aria-sort', direction === 1 ? 'ascending' : 'descending');
    }

    // Die Gruppenschaltfläche in die native Fußleiste einsetzen.
    function listFooter() {
      const host = d.getElementById('footer');
      if (!host || footer?.isConnected) { return; }
      const control = button('Gruppen öffnen / schließen', toggleAll, 'FooterButton pep-group-footer-button');
      const row = host.querySelector('table tr');
      footer = row ? element('td') : control;
      if (row) { footer.append(control); row.append(footer); }
      else { host.append(footer); }
    }

    // Gruppenzeilen entfernen und die ursprüngliche Tabellenstruktur wiederherstellen.
    function detach() {
      remove(footer);
      footer = null;
      if (list) {
        table.classList.remove('pep-grouped-program-columns', 'pep-grouped-table');
        list.headers.forEach(header => remove(header.row));
        list.original.forEach(row => row.classList.remove('pep-group-hidden', 'pep-program-group-member'));
        if (table.isConnected && list.original.length) {
          const parent = list.original.find(row => table.contains(row))?.parentNode;
          if (parent) { list.original.forEach(row => { if (row.parentNode === parent) { parent.appendChild(row); } }); }
        }
        table.querySelector('[id="name"]')?.removeAttribute('aria-sort');
      }
      list = null;
    }

    // Einen Formular- oder Navigationsbereich mit nativen Tabellenklassen erzeugen.
    function adminTable(headings) {
      const target = element('table', undefined, 'tTable pep-group-admin-table');
      const header = target.createTHead().insertRow();
      headings.forEach(name => header.append(element('th', name, 'thCell')));
      target.createTBody();
      return target;
    }

    // Die native Fußleiste der Gruppenverwaltung mit den verfügbaren Aktionen füllen.
    function managerFooter(actions) {
      const target = d.getElementById('footer');
      if (!target) { return; }
      const row = element('table').insertRow();
      actions.forEach(([text, action]) => row.insertCell().append(button(text, action, 'FooterButton')));
      target.replaceChildren(row.closest('table'));
    }

    // Inhalt und Titel der Verwaltungsseite in der WebUI anzeigen.
    function managerContent(title) {
      const host = d.getElementById('content');
      const page = element('section', undefined, 'pep-group-admin');
      page.append(element('h2', title));
      host.replaceChildren(page);
      if (typeof w.setPath === 'function') { w.setPath('Einstellungen &gt; ' + config.title); }
      const message = element('p', '', 'pep-group-message');
      message.setAttribute('role', 'status');
      manager = {page, message, busy: false};
      return manager;
    }

    // Die Verwaltungsseite mit einer beständigen Gruppenliste öffnen.
    function showManager() {
      if (!enabled || !admin || !d.getElementById('content')) { return null; }
      const state = managerContent(config.title);
      state.table = adminTable(['Name', config.plural, config.assigned, 'Aktion']);
      state.page.append(state.table, state.message);
      renderManagerRows(state);
      managerFooter([['Zurück', () => w.WebUI.goBack()], ['Neu', () => editGroup('0')]]);
      return state;
    }

    // Die Namen je Gruppe sammeln und die Vorschau auf fünf Einträge begrenzen.
    function renderManagerRows(state) {
      const body = state.table.tBodies[0];
      const assigned = new Map();
      assignments.forEach((id, program) => {
        if (!assigned.has(id)) { assigned.set(id, []); }
        assigned.get(id).push(program);
      });
      body.replaceChildren();
      [...groups].sort((a, b) => a[1].localeCompare(b[1], 'de')).forEach(([id, name]) => {
        const row = body.insertRow();
        row.insertCell().textContent = name;
        const programs = assigned.get(id) || [];
        row.insertCell().textContent = programs.length;
        const preview = row.insertCell();
        preview.className = 'pep-group-program-preview';
        if (programs.length && !state.catalog) { preview.textContent = '…'; }
        else if (programs.length) {
          const names = programs.map(program => state.catalog.get(program) || 'ID ' + program)
            .sort((a, b) => a.localeCompare(b, 'de'));
          preview.textContent = names.slice(0, 5).join('; ') + (names.length > 5 ? '; ...' : '');
        } else { preview.textContent = '—'; }
        row.insertCell().append(
          button('Bearbeiten', () => editGroup(id)),
          button('Löschen', () => {
            if (w.confirm('Gruppe „' + name + '“ löschen? Die zugeordneten Einträge bleiben erhalten.')) {
              saveGroup(state, {action: 'delete', gid: id, revision});
            }
          }));
      });
      if (!groups.size) {
        const cell = body.insertRow().insertCell();
        cell.colSpan = 4;
        cell.textContent = 'Keine ' + config.title + ' vorhanden.';
      }
    }

    // Tabellenvorschau und Auswahlliste aus demselben Katalog versorgen.
    function loadCatalog(state) {
      if (!state.catalogRequest) {
        state.catalogRequest = new Promise(resolve => {
          P.api({op: 'groups_catalog', kind: config.kind}, (ok, text) => {
            const lines = text.trim().split(/\r?\n/);
            if (!ok || lines.shift() !== 'OK') { resolve(null); return; }
            try {
              const entries = lines.filter(Boolean).map(line => {
                const [id, name] = line.split('|');
                return [id, decodeURIComponent(name)];
              });
              resolve(new Map(entries));
            } catch (error) { resolve(null); }
          });
        }).then(catalog => {
          state.catalog = catalog;
          if (!catalog) { state.catalogRequest = null; }
          if (manager === state && state.page.isConnected && !state.busy) { renderManagerRows(state); }
          return catalog;
        });
      }
      return state.catalogRequest;
    }

    // Änderungen einer Gruppe erst nach Bestätigung an die Zentrale senden.
    function saveGroup(state, payload, message = state.message) {
      if (state.busy) { return; }
      state.busy = true;
      const controls = editor ? editor.querySelectorAll('button, input') :
        d.querySelectorAll('.pep-group-admin button, #footer button');
      controls.forEach(control => { control.disabled = true; });
      ++request;
      message.textContent = 'Speichert …';
      P.api({...payload, op: 'groups_change', kind: config.kind}, (ok, text) => {
        state.busy = false;
        const saved = accept(ok, text);
        if (saved) { ++request; scan(); }
        if (manager !== state || !state.page.isConnected) { return; }
        if (saved) {
          controls.forEach(control => { control.disabled = false; });
          closeEditor();
          state.message.textContent = '';
          renderManagerRows(state);
        } else {
          controls.forEach(control => { control.disabled = false; });
          message.textContent = text.split('|')[1] || 'Speichern fehlgeschlagen.';
        }
      });
    }

    // Den schwebenden Gruppendialog schließen und den Fokus zurückgeben.
    function closeEditor() {
      if (editor?.open) { editor.close(); }
      remove(editor);
      editor = null;
    }

    // Gruppennamen und Zuordnungen als Entwurf bearbeiten, während die Liste sichtbar bleibt.
    function editGroup(id) {
      const state = manager;
      if (!state || state.busy || editor) { return; }
      const openedRevision = revision;
      const selection = new Set([...assignments].filter(entry => entry[1] === id).map(entry => entry[0]));
      const title = id === '0' ? config.newTitle : config.editTitle;
      const dialog = editor = element('dialog', undefined, 'pep-group-picker');
      dialog.setAttribute('aria-label', title);
      const label = element('label', 'Name', 'pep-group-name-field');
      const name = element('input');
      name.type = 'text';
      name.maxLength = 80;
      name.value = groups.get(id) || '';
      name.setAttribute('aria-label', 'Gruppenname');
      label.append(name);
      const body = element('div', config.plural + ' werden geladen …', 'pep-group-picker-body');
      const message = element('p', '', 'pep-group-message');
      message.setAttribute('role', 'status');
      const actions = element('div', undefined, 'pep-group-picker-actions');
      const apply = button('OK', () => {
        if (!name.value.trim()) { message.textContent = 'Bitte einen Gruppennamen eingeben.'; name.focus(); return; }
        saveGroup(state, {action: 'save', gid: id, revision: openedRevision, name: name.value.trim(), ids: [...selection].join(',')}, message);
      });
      apply.disabled = true;
      actions.append(button('Zurück', closeEditor), apply);
      dialog.append(element('h2', title), label, body, message, actions);
      dialog.addEventListener('cancel', event => { event.preventDefault(); if (!state.busy) { closeEditor(); } });
      d.body.append(dialog);
      dialog.showModal();
      name.focus();

      loadCatalog(state).then(catalog => {
        if (editor !== dialog || manager !== state) { return; }
        if (!catalog) { body.textContent = config.plural + ' konnten nicht geladen werden.'; return; }
        // Erst nach erfolgreichem Laden veraltete IDs aussortieren.
        selection.forEach(program => { if (!catalog.has(program)) { selection.delete(program); } });
        const target = adminTable(['Auswahl', config.singular, 'Bisherige Gruppe']);
        [...catalog].sort((a, b) => a[1].localeCompare(b[1], 'de')).forEach(([program, programName]) => {
          const row = target.tBodies[0].insertRow(), check = element('input');
          check.type = 'checkbox';
          check.checked = selection.has(program);
          check.setAttribute('aria-label', programName);
          check.addEventListener('change', () => {
            if (check.checked) { selection.add(program); }
            else { selection.delete(program); }
          });
          row.insertCell().append(check);
          row.insertCell().textContent = programName;
          row.insertCell().textContent = groups.get(assignments.get(program)) || '—';
        });
        body.replaceChildren(target);
        apply.disabled = false;
      });
    }

    // Die Verwaltungsseite über die normale WebUI-Navigation öffnen.
    const managerPage = {
      // Vor der Bearbeitung die gemeinsame Gruppenliste aktualisieren.
      enter() {
        w.MainMenu?.select?.('MAINMENU_OPTIONS');
        const opened = showManager();
        if (!opened) { return; }
        loadCatalog(opened);
        refresh(ok => {
          if (manager !== opened || !opened?.page.isConnected) { return; }
          if (ok && admin) { renderManagerRows(opened); }
          else { opened.message.textContent = config.title + ' konnten nicht geladen werden.'; }
        });
      },
      // Beim Seitenwechsel einen offenen Entwurf aus der Oberfläche entfernen.
      leave() { closeEditor(); manager = null; },
      // Die Verwaltungsseite passt ihre Breite per CSS an.
      resize() {}
    };

    // Den Eintrag unter Einstellungen neben der nativen Gruppenverwaltung ergänzen.
    function navigation() {
      const menu = d.querySelector('#menuSettingsPage_SUBMENU #' + config.menuAnchor);
      const tile = d.getElementById(config.tileAnchor);
      if (!enabled || !admin) {
        remove(d.getElementById(menuId));
        remove(d.getElementById(tileId));
        return;
      }
      const open = () => {
        w.MainMenu?.beginHideSubmenu?.({id: 'menuSettingsPage'});
        if (w.WebUI?.enter) { w.WebUI.enter(managerPage); }
      };
      if (menu && !d.getElementById(menuId)) {
        const anchorRow = menu.closest('tr');
        const cell = element(anchorRow ? 'td' : menu.tagName.toLowerCase(), config.title, 'MainMenuSubItem');
        const entry = anchorRow ? element('tr') : cell;
        entry.id = menuId;
        const icon = menu.querySelector('img')?.cloneNode(false);
        if (icon) { icon.removeAttribute('id'); icon.alt = ''; cell.prepend(icon); }
        cell.tabIndex = 0;
        cell.setAttribute('role', 'button');
        cell.addEventListener('mouseenter', () => cell.classList.add('MainMenuSubItem_Highlight'));
        cell.addEventListener('mouseleave', () => cell.classList.remove('MainMenuSubItem_Highlight'));
        cell.addEventListener('click', open);
        cell.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); open(); } });
        if (anchorRow) { entry.append(cell); }
        (anchorRow || menu).after(entry);
      }
      if (tile && !d.getElementById(tileId)) {
        const item = element('div', undefined, tile.className);
        item.id = tileId;
        const description = element('ul');
        ['Gruppen anlegen, umbenennen und löschen',
          config.plural + ' gleichzeitig einer Gruppe zuordnen',
          'Gruppen in beiden Übersichten öffnen und schließen'].forEach(text => description.append(element('li', text)));
        item.append(button(config.title, open, 'StdTableBtn pep-program-groups-tile-button'), description);
        tile.after(item);
      }
      // Die Systemvariablengruppen folgen den Programmgruppen, sobald beide sichtbar sind.
      if (!isProgram) {
        for (const [anchorId, entryId] of [['pep-program-groups-menu',menuId],['pep-program-groups-tile',tileId]]) {
          const anchor = d.getElementById(anchorId), entry = d.getElementById(entryId);
          if (anchor && entry && anchor.nextElementSibling !== entry) { anchor.after(entry); }
        }
      }
    }

    // Bei einem Wechsel der Tabelle den Zustand der passenden Übersicht laden.
    function scan() {
      navigation();
      const next = enabled ? d.getElementById(config.editTable) || d.getElementById(config.statusTable) : null;
      if (next !== table) {
        detach();
        table = next;
        if (next) { refresh(); }
      }
      if (!table || !groups.size) { detach(); return; }
      if (!list) {
        const rows = itemRows(table);
        const status = isProgram
          ? table.classList.contains('CLASS03701') || rows.some(row => /^pr\d+$/.test(row.id))
          : table.id === config.statusTable;
        const key = status ? 'status' : 'edit';
        const state = views[key];
        // Nur die Bearbeitungsliste hat die drei Spalten Name, Beschreibung und Bedingung.
        table.classList.add('pep-grouped-table');
        table.classList.toggle('pep-grouped-program-columns', isProgram && key === 'edit');
        list = {state, original: rows, headers: new Map(), sorted: null};
      }
      arrange();
      listFooter();
    }

    // Die optionale Funktion aktivieren oder vollständig aus der WebUI entfernen.
    function configure(value) {
      ++settingRequest;
      const changed = enabled !== value;
      enabled = value;
      if (!enabled) { ++request; }
      if (!enabled && manager) { closeEditor(); w.WebUI?.goBack(); }
      scan();
      if (changed && enabled && !table) { refresh(); }
    }

    // Den zentralen Funktionsschalter beim Start und beim Fokussieren abfragen.
    function refreshSettings() {
      const current = ++settingRequest;
      P.api({op: config.option + '_settings'}, (ok, text) => {
        if (current !== settingRequest || !ok || !/^OK\|[01]$/.test(text)) { return; }
        const alreadyEnabled = enabled;
        configure(text === 'OK|1');
        if (alreadyEnabled && enabled) { refresh(); }
      });
    }

    // Zusammengehörige DOM-Änderungen in einem Durchlauf verarbeiten.
    function schedule() {
      if (!enabled || queued) { return; }
      queued = true;
      w.requestAnimationFrame(() => { queued = false; scan(); });
    }

    P[config.module] = {configure, sort, owns: target => target === table && !!list && groups.size > 0};
    new w.MutationObserver(schedule).observe(d.documentElement, {subtree: true, childList: true});
    d.addEventListener('click', nativeNameSort, true);
    w.addEventListener('focus', refreshSettings);
    w.addEventListener('storage', event => {
      if (event.key === settingsKey) { configure(event.newValue === '1'); }
    });
    refreshSettings();
  }
})(window);
