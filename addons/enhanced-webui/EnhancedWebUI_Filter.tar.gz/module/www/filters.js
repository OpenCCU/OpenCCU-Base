// Die unterstützten Listen mit Live-Filtern ergänzen.
(function(w){
 'use strict';var P=w.__PEP__,d=w.document;if(!P||P.filters){return;}var active=false,states=new Map(),timer=null,channelGroups=new WeakMap();
 // Bei der Navigation ersetzt die WebUI die Tabelle. Die Filterwerte bleiben pro Ansicht im Browser erhalten.
 var filtersByView = new Map();
 var targets={ProgramListTable:true,sysVars:true,sysvarsListTable:true,tblRoomNames:true,tblFunctionNames:true,tblHDeviChannel:true,tblFavs:true};
 // Ein Element für die Filterleiste erzeugen.
 function node(tag,cls,text){var n=d.createElement(tag);if(cls){n.className=cls;}if(text!==undefined){n.textContent=text;}return n;}
 // Sichtbaren Text für die Suche vereinheitlichen.
 function text(n){return (n?n.textContent:'').replace(/\s+/g,' ').trim();}
 // Text nur bei einer Änderung ersetzen.
 function setText(n,value){if(n.textContent!==value){n.textContent=value;}}
 // Die native Geräte- und Kanaltabelle erkennen.
 function channelTable(t){return t.id==='tblHDeviChannel';}
 // Filterbare Zeilen und zugehörige Kanäle bestimmen.
 function rows(t){
  var controls=new Set();if(channelTable(t)){
   var groups=channelGroups.get(t);if(!groups){groups=new Map();channelGroups.set(t,groups);}
   // Die Zuordnung von Geräte- und Bedienzeilen bleibt gültig, bis die WebUI die Tabelle ersetzt.
   if(Array.isArray(w.arChns)){w.arChns.forEach(function(item){var row=d.getElementById(item.trid),control=item.ctrlId&&d.getElementById(item.ctrlId);if(row&&row.closest('table')===t&&control&&t.contains(control)&&control!==row){groups.set(row.id,control);}});}
   groups.forEach(function(control,id){var row=d.getElementById(id);if(!row||row.closest('table')!==t||!t.contains(control)){groups.delete(id);}else{controls.add(control.id);}});
  }
  return Array.prototype.slice.call(t.rows).filter(function(r){return r.closest('table')===t&&r.id&&!controls.has(r.id)&&r.id!=='rowhead'&&r.id!=='rowflt'&&!r.querySelector('.FilterBtn')&&(t.id!=='ProgramListTable'||/^(?:program|pr)\d+$/.test(r.id));});
 }
 // Die Programmübersicht zur Bedienung erkennen.
 function isStatusProgramList(table, list) {
  return table.classList.contains('CLASS03701') || list.some(function(row) {
   return /^pr\d+$/.test(row.id);
  });
 }
 // Einen Schlüssel für die jeweilige Übersicht bestimmen.
 function viewKey(table, list) {
  if (table.id === 'ProgramListTable') {
   return isStatusProgramList(table, list) ? 'status-programs' : 'edit-programs';
  }
  if (table.id === 'tblFunctionNames' && list.some(function(row) {
   return /^devices\d+$/.test(row.id);
  })) {
   return 'status-devices';
  }
  return table.id;
 }
 // Filterwerte merken und anwenden.
 function applyUserFilter(state) {
  filtersByView.set(state.viewKey, {
   query: state.search.value,
   excludedColumns: [...state.excludedColumns],
   status: state.status ? state.status.value : 'all'
  });
  apply(state);
 }
 // Die zu einer Gerätezeile gehörige Bedienzeile finden.
 function companion(t,row){var groups=channelGroups.get(t),control=groups&&groups.get(row.id);return control&&t.contains(control)&&!row.contains(control)?control:null;}
 // Die durchsuchbaren Spalten bestimmen.
 function columns(state){
  var t=state.table,head=Array.prototype.slice.call(t.rows).find(function(r){return r.closest('table')===t&&r.cells.length&&r.querySelector('th,.thCell');});if(!head){return [];}
  return Array.prototype.slice.call(head.cells).map(function(cell,index){var copy=cell.cloneNode(true);Array.prototype.forEach.call(copy.querySelectorAll('.pep-filter-sort'),function(b){b.remove();});var key=cell.classList.contains('pep-id-cell')?'id':cell.classList.contains('pep-date-cell')?'date':String(index);return {cell:cell,index:index,key:key,label:text(copy)||'Spalte '+(index+1)};}).filter(function(c){return !/^(Aktion|Action|Link|Passwort|Password|Bild|Picture)$/i.test(c.label);});
 }
 // Die passenden Zeilen anzeigen und zählen.
 function apply(state){
  var list=rows(state.table),query=state.search.value.trim().toLocaleLowerCase('de-DE'),terms=query.split(/\s+/).filter(Boolean),selected=state.columns.filter(function(c){return !state.excludedColumns.has(c.key);}),status=state.status?state.status.value:'all',shown=0,total=0;
  list.forEach(function(row){
   if(state.order.indexOf(row)<0){state.order.push(row);}
   var nativeVisible=!row.hidden&&row.style.display!=='none'&&!row.classList.contains('hidden')&&!row.classList.contains('pep-group-hidden');if(nativeVisible){total++;}
   var haystack=selected.map(function(c){return text(row.cells[c.index]);}).join(' ').toLocaleLowerCase('de-DE'),matches=terms.every(function(term){return haystack.indexOf(term)>=0;});
   if(status!=='all'){var check=row.querySelector('input[onclick*="SetActive("],input[onchange*="SetActive("]');matches=matches&&!!check&&(status==='active'?check.checked:!check.checked);}
   var control=companion(state.table,row);
   if(d.activeElement&&(row.contains(d.activeElement)||control&&control.contains(d.activeElement))&&d.activeElement.matches('input:not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]):not([type="hidden"]),textarea,[contenteditable="true"]')){matches=true;}
   row.classList.toggle('pep-live-filter-hidden',!matches);if(control){control.classList.toggle('pep-live-filter-hidden',!matches);}if(matches&&nativeVisible){shown++;}
  });
  var filtered=!!terms.length||status!=='all';
  if(state.icon.hidden!==!filtered){state.icon.hidden=!filtered;}state.clear.disabled=!state.search.value;state.clear.title='Suchbegriff löschen';setText(state.count,shown+' / '+total);if(state.bar.classList.contains('pep-filter-is-active')!==filtered){state.bar.classList.toggle('pep-filter-is-active',filtered);}
  if((state.program||P.systemVariableGroups?.owns(state.table))&&state.sort){sortRows(state,list);}
 }
 // Den Wert für den Spaltenvergleich lesen.
 function value(state,row,column){
  if(column.key==='id'){return Number(text(row.querySelector('.pep-id-cell')))||null;}
  if(column.key==='date'){var raw=row.querySelector('.pep-date-cell');return raw&&raw.dataset.pepTimestamp?Number(raw.dataset.pepTimestamp):null;}
  return text(row.cells[column.index]);
 }
 // Die nativen Zeilen nach der ausgewählten Spalte sortieren.
 function sortRows(state,list){
  var column=state.columns.find(function(c){return c.key===state.sort;});if(!column){return;}
  var sorted=list.slice().sort(function(a,b){var av=value(state,a,column),bv=value(state,b,column);if(av===null||bv===null){return av===bv?state.order.indexOf(a)-state.order.indexOf(b):av===null?1:-1;}var delta=typeof av==='number'?av-bv:av.localeCompare(bv,'de',{sensitivity:'base'});return delta*state.direction||state.order.indexOf(a)-state.order.indexOf(b);});
  if(P.programGroups?.sort(state.table,column.index===0,state.direction,sorted)||P.systemVariableGroups?.sort(state.table,column.index===0,state.direction,sorted)){return;}
  if(list.length<2){return;}
  if(sorted.every(function(row,i){return row===list[i];})){return;}var parent=list[0].parentNode;if(!list.every(function(row){return row.parentNode===parent;})){return;}sorted.forEach(function(row){parent.appendChild(row);});
 }
 // Sortierschaltflächen im Tabellenkopf ergänzen.
 function headings(state){
  state.headings.forEach(function(info,cell){if(!cell.isConnected||!state.columns.some(function(c){return c.cell===cell;})){cell.removeEventListener('click',info.click,true);info.button.remove();cell.removeAttribute('aria-sort');state.headings.delete(cell);}});
  state.columns.forEach(function(column){
   var sortable=state.program?(column.index<2||column.key==='id'||column.key==='date'):column.cell.querySelector('[onclick*="Sort("]');if(!sortable){return;}
   var info=state.headings.get(column.cell);
   if(!info){
    var button=node('button','pep-filter-sort','↕');button.type='button';button.title=column.label+' auf-/absteigend sortieren';button.setAttribute('aria-label',button.title);
    var host=column.cell.querySelector('[onclick*="Sort("]')||column.cell;host.appendChild(button);
    var click=/* Die Sortierreihenfolge der Spalte ändern. */ function(e){if(!active){return;}if(state.program||P.systemVariableGroups?.owns(state.table)){e.preventDefault();e.stopImmediatePropagation();}state.direction=state.sort===column.key?-state.direction:1;state.sort=column.key;apply(state);updateHeadings(state);};
    column.cell.addEventListener('click',click,true);info={button:button,click:click};state.headings.set(column.cell,info);
   }
  });updateHeadings(state);
 }
 // Sortiersymbole an die aktuelle Reihenfolge anpassen.
 function updateHeadings(state){state.columns.forEach(function(c){var info=state.headings.get(c.cell);if(info){setText(info.button,state.sort===c.key?(state.direction===1?'↑':'↓'):'↕');if(state.sort===c.key){c.cell.setAttribute('aria-sort',state.direction===1?'ascending':'descending');}else{c.cell.removeAttribute('aria-sort');}}});}
 // Suchspalten nach einer Tabellenänderung neu aufbauen.
 function rebuild(state){
  var next=columns(state),signature=next.map(function(c){return c.key+':'+c.label;}).join('|');state.columns=next;
  if(signature!==state.signature){
   state.signature = signature;
   state.choices.replaceChildren();
   next.forEach(function(column) {
    var label = node('label');
    var input = node('input');
    input.type = 'checkbox';
    input.checked = !state.excludedColumns.has(column.key);
    input.onchange = /* Eine Suchspalte ein- oder ausschließen. */ function() {
     if (input.checked) {
      state.excludedColumns.delete(column.key);
     } else {
      state.excludedColumns.add(column.key);
     }
     applyUserFilter(state);
    };
    label.append(input, d.createTextNode(' ' + column.label));
    state.choices.appendChild(label);
   });
  }
  headings(state);Array.prototype.forEach.call(state.table.querySelectorAll('.FilterBtn'),function(button){var row=button.closest('tr');if(row&&row.closest('table')===state.table&&!rows(state.table).includes(row)){row.classList.add('pep-native-filter-row');}});apply(state);
 }
 // Die Filterleiste für eine Tabelle einrichten.
 function create(table){
  var list = rows(table);
  var key = viewKey(table, list);
  var saved = filtersByView.get(key);
  var state = {
   table: table,
   viewKey: key,
   program: table.id === 'ProgramListTable',
   order: list,
   columns: [],
   excludedColumns: new Set(saved ? saved.excludedColumns : []),
   signature: '',
   headings: new Map(),
   sort: null,
   direction: 1
  };
  var wrapper=node('div','pep-filter-view'),bar=node('section','pep-live-filter'),line=node('div','pep-filter-line'),search=node('input','pep-live-search'),clear=node('button','pep-filter-clear','×'),icon=node('span','pep-filter-funnel'),count=node('span','pep-filter-count'),details=node('details','pep-filter-columns'),summary=node('summary',null,'Spalten auswählen'),choices=node('div','pep-filter-choices');
  search.type='text';search.inputMode='search';search.placeholder='In ausgewählten Spalten suchen …';search.setAttribute('aria-label','Listen durchsuchen');search.autocomplete='off';clear.type='button';clear.setAttribute('aria-label','Suchbegriff löschen');icon.title='Filter aktiv';icon.setAttribute('role','img');icon.setAttribute('aria-label','Filter aktiv');bar.setAttribute('aria-label','Verbesserter Filter');count.setAttribute('role','status');
  var context=table.id==='sysvarsListTable'?'Systemvariablen':channelTable(table)?'Kanäle':table.id==='tblFunctionNames'&&state.order.some(function(row){return /^devices\d+$/.test(row.id);})?'Geräte':'';
  if(context){search.placeholder=context+' durchsuchen …';search.setAttribute('aria-label',context+' durchsuchen');bar.setAttribute('aria-label',context+' filtern');}bar.dataset.pepFilterFor=table.id;
  Object.assign(state,{wrapper:wrapper,bar:bar,search:search,clear:clear,icon:icon,count:count,choices:choices});
  search.value = saved ? saved.query : '';
  search.oninput = /* Beim Tippen live filtern. */ function() { applyUserFilter(state); };
  clear.onclick = /* Den Suchbegriff leeren. */ function() {
   search.value = '';
   applyUserFilter(state);
   search.focus();
  };
  line.append(icon, search, clear);
  if (state.program && !isStatusProgramList(table, list)) {
   var status = node('select', 'pep-program-status');
   status.setAttribute('aria-label', 'Programmstatus');
   [['all','Alle Programme'],['active','Nur aktive Programme'],['inactive','Nur deaktivierte Programme']].forEach(function(pair) {
    var option = node('option', null, pair[1]);
    option.value = pair[0];
    status.appendChild(option);
   });
   status.value = saved ? saved.status : 'all';
   status.onchange = /* Nach dem ausgewählten Programmstatus filtern. */ function() { applyUserFilter(state); };
   line.appendChild(status);
   state.status = status;
  }
  line.appendChild(count);details.append(summary,choices);bar.append(line,details);table.parentNode.insertBefore(wrapper,table);wrapper.append(bar,table);states.set(table,state);rebuild(state);return state;
 }
 // Die Zusatzfilter von einer Tabelle entfernen.
 function remove(state){
  state.headings.forEach(function(info,cell){cell.removeEventListener('click',info.click,true);info.button.remove();cell.removeAttribute('aria-sort');});Array.prototype.forEach.call(state.table.querySelectorAll('.pep-live-filter-hidden'),function(r){r.classList.remove('pep-live-filter-hidden');});Array.prototype.forEach.call(state.table.querySelectorAll('.pep-native-filter-row'),function(r){r.classList.remove('pep-native-filter-row');});
  if(state.program&&state.sort){var surviving=state.order.filter(function(r){return r.isConnected;});if(surviving.length&&surviving.every(function(r){return r.parentNode===surviving[0].parentNode;})){surviving.forEach(function(r){surviving[0].parentNode.appendChild(r);});}}
  if(state.wrapper.parentNode){state.wrapper.parentNode.insertBefore(state.table,state.wrapper);state.wrapper.remove();}
 }
 // Unterstützte Tabellen finden und aktualisieren.
 function scan(){
  states.forEach(function(state,table){if(!active||!table.isConnected){if(table.isConnected){remove(state);}states.delete(table);}});if(!active){return;}
  Object.keys(targets).forEach(function(id){var table=d.getElementById(id);if(!table||table.tagName!=='TABLE'||id==='tblFavs'&&!table.classList.contains('filterTable')){return;}if(!rows(table).length&&!states.has(table)){return;}var state=states.get(table);if(state){rebuild(state);}else{create(table);}});
 }
 // Eine Aktualisierung der Tabellen vormerken.
 function queue(){if(!timer){timer=w.setTimeout(function(){timer=null;scan();},70);}}
 // Verbesserte Filter ein- oder ausschalten.
 function configure(value){active=value===true;scan();}
 // Die zentrale Filtereinstellung abfragen.
 function refresh(){P.api({op:'filters_settings'},function(ok,response){if(ok&&/^OK\|[01]$/.test(response)){configure(response==='OK|1');}});}
 d.addEventListener('change',function(e){if(e.target.closest&&e.target.closest('table')){queue();}});
 d.addEventListener('focusout',function(e){if(e.target.closest&&e.target.closest('table')){queue();}});
 d.addEventListener('click',function(e){var control=e.target.closest&&e.target.closest('[onclick*="clearFilters"]');if(control){states.forEach(function(state){state.search.value='';if(state.status){state.status.value='all';}state.choices.querySelectorAll('input').forEach(function(input){input.checked=true;});state.excludedColumns.clear();applyUserFilter(state);});}});
 new w.MutationObserver(queue).observe(d.documentElement,{subtree:true,childList:true,attributes:true,attributeFilter:['style','hidden','data-pep-timestamp']});w.addEventListener('focus',refresh);w.addEventListener('storage',function(e){if(e.key==='ewebui-filters-enabled'){configure(e.newValue==='1');}});
 P.filters={configure:configure,isEnabled:/* Den aktuellen Filterstatus melden. */ function(){return active;},scan:scan};refresh();
})(window);
