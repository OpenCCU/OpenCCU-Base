# Die angeforderte Favoritenliste und ihre Einträge prüfen.
proc pep_fav_guard {parent} {
  if {![pep_is_id $parent]} { error "Ungueltige Favoritenliste" }
  set sid [string trim [pep_param sid] @]
  if {![regexp {^[A-Za-z0-9]{10}$} $sid]} { error "Sitzung fehlt" }
  set s "boolean allowed = false; object f = dom.GetObject($parent);\n"
  append s "string fs = system.GetSessionVarStr(\"$sid\"); if (fs == \"\") { fs = system.GetSessionVarStr(\"@$sid@\"); }\n"
  append s "object fu = dom.GetObject(\"_USER\" # fs.StrValueByIndex(\";\",0));\n"
  append s "if (f && fu) { if (f.ID() == fu.ID()) { allowed = true; } else { if (f.IsTypeOf(OT_FAVORITE)) { if (f.EnCopyID() != ID_ERROR) { allowed = true; } } } }\n"
  return $s
}
# Die aktuelle Reihenfolge der Favoriten lesen.
proc pep_favorites_get {parent} {
  set s [pep_fav_guard $parent]
  append s "if (allowed) { Write(\"OK|\" # f.EnumIDs()); } else { Write(\"ERR|Nur eigene Listen oder eine Bearbeitungskopie erlaubt\"); }"
  return [string trim [pep_rega $s]]
}
# Die verfügbaren nativen Verschiebeschritte vorbereiten.
proc pep_fav_moves {ids} {
  set s ""; set pos 0
  foreach id $ids {
    append s "integer fi = 0; string fj; foreach(fj, f.EnumIDs()) { if (fj == $id) { break; } fi = fi + 1; }\n"
    append s "while (fi > $pos) { f.MoveObject($id,-1); fi = fi - 1; }\n"
    incr pos
  }
  return $s
}
# Die gewünschte Favoritenreihenfolge über native Schritte anwenden.
proc pep_favorites_set {parent expected order} {
  if {![lindex [pep_settings] 2]} { return "ERR|Favoritensortierung ausgeschaltet" }
  foreach text [list $expected $order] {
    if {![regexp {^[1-9][0-9]*(,[1-9][0-9]*)*$} $text]} { return "ERR|Ungueltige Reihenfolge" }
  }
  set old [split $expected ,]; set new [split $order ,]
  if {[llength $old] > 500 || [lsort -integer $old] != [lsort -integer $new]} { return "ERR|Mitglieder geaendert" }
  set seen {}; foreach id $old { if {[lsearch -exact $seen $id] >= 0} { return "ERR|Doppelte ID" }; lappend seen $id }
  set s [pep_fav_guard $parent]
  set oldenum [join $old \t]; set newenum [join $new \t]
  append s "if (!allowed) { Write(\"ERR|Favoritenliste nicht freigegeben\"); } else { if (f.EnumIDs() != \"$oldenum\") { Write(\"ERR|Reihenfolge geaendert - neu laden\"); } else {\n"
  append s [pep_fav_moves $new]
  append s "if (f.EnumIDs() == \"$newenum\") { Write(\"OK\"); } else {\n" [pep_fav_moves $old]
  append s "if (f.EnumIDs() == \"$oldenum\") { Write(\"ERR|Ausgangsreihenfolge wiederhergestellt\"); } else { Write(\"POSTFAIL|Reihenfolge nicht bestaetigt - neu laden\"); } } } }"
  return [string trim [pep_rega $s]]
}

