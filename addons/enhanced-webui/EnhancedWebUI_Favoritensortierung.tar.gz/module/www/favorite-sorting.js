// Favoriten und Favoritenlisten an ihren Ziehgriffen verschieben.
(function(w){
 'use strict';
 var P=w.__PEP__,d=w.document;
 if(!P||P.favoriteSorting){return;}
 var drag=null,busy=false;
 // Alle passenden Elemente im Bereich sammeln.
 function all(q,root){return Array.prototype.slice.call((root||d).querySelectorAll(q));}
 // Ein Element mit Text erzeugen.
 function node(tag,cls,text){var e=d.createElement(tag);e.className=cls||'';if(text!==undefined){e.textContent=text;}return e;}
 // Eine Antwort der Addon-Schnittstelle auswerten.
 function api(args,cb){P.api(args,function(ok,text){if(!ok||text.indexOf('OK')!==0){cb(null,text);return;}cb(text);});}
 // Eine Meldung zur Übersichtsaktion anzeigen.
 function report(text){w.alert('Enhanced WebUI: '+text);}
 // Die Einträge einer Favoritentabelle ermitteln.
 function favoriteRows(){
  var result=[];
  all('[onclick*="MoveUp("],[onclick*="MoveDown("]').forEach(function(a){
   var m=/Move(?:Up|Down)\(\s*(\d+)\s*,\s*(\d+)\s*\)/.exec(a.getAttribute('onclick')||'');
   var row=a.closest('tr[id]');if(!m||!row||result.some(function(x){return x.row===row;})){return;}
   result.push({row:row,parent:m[1],id:m[2]});
  });return result;
 }
 // Ziehgriffe in der Favoritentabelle ergänzen.
 function favoriteHandles(){
  if(!P.settings.favorites){all('.pep-favorite-position').forEach(function(host){var count=host.querySelector('.pep-favorite-number');if(count){while(count.firstChild){host.parentNode.insertBefore(count.firstChild,host);}}host.remove();});all('.pep-favorite-handle').forEach(function(h){h.remove();});cancel();return;}
  favoriteRows().forEach(function(item){
   if(item.row.querySelector('.pep-favorite-handle')){return;}
   var h=node('button','pep-handle pep-favorite-handle');h.type='button';h.title='Favorit oder Favoritenliste verschieben; Reihenfolge wie bei den Pfeiltasten speichern';
   h.setAttribute('aria-label','Favorit verschieben');h.dataset.parent=item.parent;h.dataset.id=item.id;
   var cell=item.row.querySelector('[id="favPosCount"]');
   if(!cell){return;}
   var host=node('span','pep-favorite-position'),number=node('span','pep-favorite-number');
   while(cell.firstChild){number.appendChild(cell.firstChild);}
   host.appendChild(h);host.appendChild(number);cell.appendChild(host);
  });
 }
 // Eine laufende Favoritensortierung aufräumen.
 function cancel(){if(drag){w.cancelAnimationFrame(drag.frame);if(drag.ghost){drag.ghost.remove();}try{if(drag.h.hasPointerCapture(drag.pointer)){drag.h.releasePointerCapture(drag.pointer);}}catch(ignore){}drag=null;}all('.pep-favorite-target,.pep-favorite-before').forEach(function(r){r.classList.remove('pep-favorite-target','pep-favorite-before');});}
 d.addEventListener('pointerdown',function(e){
  var h=e.target.closest&&e.target.closest('.pep-favorite-handle');if(!h||busy||!P.settings.favorites||e.button!==0){return;}
  if(drag){return;}e.preventDefault();cancel();var state=drag={h:h,pointer:e.pointerId,row:h.closest('tr[id]'),parent:h.dataset.parent,id:h.dataset.id,x:e.clientX,y:e.clientY,active:false,snapshot:null};
  try{h.setPointerCapture(e.pointerId);}catch(ignore){}
  api({op:'favorites_get',parent:state.parent},function(text,error){if(drag!==state){return;}if(!text){cancel();report(error);return;}state.snapshot=text.slice(3).trim().split(/\s+/).filter(Boolean);});
 },true);
 // Den scrollbaren Bereich der Favoriten finden.
 function favoriteScroller(row){var n=row.parentElement;while(n&&n!==d.body){var style=w.getComputedStyle(n);if(n.scrollHeight>n.clientHeight&&/(auto|scroll)/.test(style.overflowY)){return n;}n=n.parentElement;}return d.scrollingElement;}
 // Das Ziel einer Favoritensortierung bestimmen.
 function favoriteTarget(state){
  all('.pep-favorite-target,.pep-favorite-before').forEach(function(r){r.classList.remove('pep-favorite-target','pep-favorite-before');});
  var root=favoriteScroller(state.row),r=root===d.scrollingElement?{top:0,bottom:w.innerHeight,left:0,right:w.innerWidth}:root.getBoundingClientRect();state.target=null;
  if(state.x<r.left||state.x>r.right||state.y<r.top-20||state.y>r.bottom+20){return;}
  var items=favoriteRows().filter(function(i){var b=i.row.getBoundingClientRect();return i.parent===state.parent&&i.id!==state.id&&b.height>0&&b.bottom>r.top&&b.top<r.bottom;});if(!items.length){return;}
  var target=items[items.length-1],before=false;for(var i=0;i<items.length;i++){var b=items[i].row.getBoundingClientRect();if(state.y<(Math.max(r.top,b.top)+Math.min(r.bottom,b.bottom))/2){target=items[i];before=true;break;}}
  state.target=target;state.before=before;target.row.classList.add(before?'pep-favorite-before':'pep-favorite-target');
 }
 // Beim Ziehen am Rand weiter scrollen.
 function scrollFavorite(){if(!drag||!drag.active){return;}var root=favoriteScroller(drag.row),r=root===d.scrollingElement?{top:0,bottom:w.innerHeight}:root.getBoundingClientRect();if(drag.y>=r.top-20&&drag.y<r.top+28){root.scrollTop-=10;}else if(drag.y<=r.bottom+20&&drag.y>r.bottom-28){root.scrollTop+=10;}favoriteTarget(drag);drag.frame=w.requestAnimationFrame(scrollFavorite);}
 d.addEventListener('pointermove',function(e){
  if(!drag||e.pointerId!==drag.pointer){return;}if(!drag.active&&Math.abs(e.clientX-drag.x)+Math.abs(e.clientY-drag.y)<7){return;}
  drag.active=true;e.preventDefault();
  if(!drag.ghost){drag.ghost=node('div','pep-favorite-ghost','Favorit verschieben');d.body.appendChild(drag.ghost);}
  drag.ghost.style.left=(e.clientX+14)+'px';drag.ghost.style.top=(e.clientY+14)+'px';
  all('.pep-favorite-target,.pep-favorite-before').forEach(function(r){r.classList.remove('pep-favorite-target','pep-favorite-before');});
  drag.x=e.clientX;drag.y=e.clientY;favoriteTarget(drag);if(!drag.frame){drag.frame=w.requestAnimationFrame(scrollFavorite);}
 },true);
 d.addEventListener('pointerup',function(e){
  if(!drag||e.pointerId!==drag.pointer){return;}drag.x=e.clientX;drag.y=e.clientY;favoriteTarget(drag);var state=drag,target=drag.target,active=drag.active;cancel();if(!active||!target||target.row===state.row){return;}e.preventDefault();
  if(!state.snapshot){report('Die Reihenfolge wird noch geladen. Bitte erneut ziehen.');return;}
  var visible=favoriteRows().filter(function(i){return i.parent===state.parent&&i.row.getBoundingClientRect().height>0;});
  var ids=visible.map(function(i){return i.id;}).filter(function(id){return id!==state.id;});
  var at=ids.indexOf(target.id)+(state.before?0:1);ids.splice(at,0,state.id);
  if(ids.some(function(id){return state.snapshot.indexOf(id)<0;})){report('Favoriten geändert. Bitte neu laden.');return;}
  var n=0,order=state.snapshot.map(function(id){return ids.indexOf(id)>=0?ids[n++]:id;});
  if(order.join(',')===state.snapshot.join(',')){return;}
  busy=true;
  api({op:'favorites_set',parent:state.parent,expected:state.snapshot.join(','),order:order.join(',')},function(text,error){busy=false;if(!text){report(error);return;}if(typeof w.reloadPage==='function'){w.reloadPage();}else{w.location.reload();}});
 },true);
 d.addEventListener('pointercancel',cancel,true);d.addEventListener('keydown',function(e){if(e.key==='Escape'){cancel();}},true);
 P.favoriteSorting={scan:favoriteHandles,cancel:cancel};
 P.favoriteSorting.scan();
})(window);
