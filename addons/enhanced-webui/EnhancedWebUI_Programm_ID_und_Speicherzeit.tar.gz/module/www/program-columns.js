// Programm-ID und Speicherzeit in beiden Programmübersichten einblenden.
(function(w){
 'use strict';
 var P=w.__PEP__,d=w.document;
 if(!P||P.programColumns){return;}
 var dates={},dateTable=null,observed=false;
 // Alle passenden Elemente im Bereich sammeln.
 function all(q,root){return Array.prototype.slice.call((root||d).querySelectorAll(q));}
 // Ein Element mit Text erzeugen.
 function node(tag,cls,text){var e=d.createElement(tag);e.className=cls||'';if(text!==undefined){e.textContent=text;}return e;}
 // Eine Antwort der Addon-Schnittstelle auswerten.
 function api(args,cb){P.api(args,function(ok,text){if(!ok||text.indexOf('OK')!==0){cb(null,text);return;}cb(text);});}
 // Eine Meldung zur Übersichtsaktion anzeigen.
 function report(text){w.alert('Enhanced WebUI: '+text);}
 // Die ID einer Programmzeile lesen.
 function programId(row){return row.id.replace(/^(?:program|pr)/,'');}
 // Die Programmzeilen der Übersicht sammeln.
 function programRows(t){return Array.prototype.slice.call(t.rows).filter(function(r){return /^(?:program|pr)\d+$/.test(r.id);});}
 // Eine Zusatzspalte im Stil der Tabelle erzeugen.
 function nativeCell(row,cls,text){
  var cells=Array.prototype.slice.call(row.cells).filter(function(c){return !c.classList.contains('pep-id-cell')&&!c.classList.contains('pep-date-cell');});
  var reference=cells[Math.min(3,cells.length-1)];return node('td',((reference&&reference.className)||'')+' '+cls,text);
 }
 // Zusatzspalten direkt vor der Aktion anordnen.
 function positionColumns(row){
  var nativeCells=Array.prototype.slice.call(row.cells).filter(function(c){return !c.classList.contains('pep-id-cell')&&!c.classList.contains('pep-date-cell');});
  var action=nativeCells[nativeCells.length-1],id=row.querySelector(':scope > .pep-id-cell'),date=row.querySelector(':scope > .pep-date-cell');
  if(date&&date.nextElementSibling!==action){row.insertBefore(date,action);}
  if(id&&id.nextElementSibling!==(date||action)){row.insertBefore(id,date||action);}
 }
 // Breiten für die Zusatzspalten ergänzen.
 function columnWidths(t){
  var group=t.querySelector(':scope > colgroup');if(!group){return;}
  [['pep-id-column',P.settings.programids,'var(--pep-program-id-column-width)'],['pep-date-column',P.settings.programsort,'165px']].forEach(function(item){
   var col=group.querySelector('.'+item[0]);
   if(!item[1]){if(col){col.remove();}return;}
   if(!col){col=node('col',item[0]);col.style.width=item[2];group.appendChild(col);}
  });
  var nativeCols=all('col',group).filter(function(c){return !c.classList.contains('pep-id-column')&&!c.classList.contains('pep-date-column');}),action=nativeCols[nativeCols.length-1];
  var id=group.querySelector('.pep-id-column'),date=group.querySelector('.pep-date-column');
  if(action){if(date&&date.nextElementSibling!==action){group.insertBefore(date,action);}if(id&&id.nextElementSibling!==(date||action)){group.insertBefore(id,date||action);}}
 }
 // Programm-ID und letzte Speicherzeit anzeigen.
 function programOverview(){
  var t=d.getElementById('ProgramListTable');if(!t){dateTable=null;return;}
  var rows=programRows(t),headers=Array.prototype.slice.call(t.rows).filter(function(r){return !/^(?:program|pr)\d+$/.test(r.id)&&r.closest('table')===t&&r.cells.length>=5;});
  if(P.settings.programids){
   headers.forEach(function(r,i){if(!r.querySelector('.pep-id-cell')){r.appendChild(nativeCell(r,'pep-id-cell',i?'':'Programm-ID'));}});
   rows.forEach(function(r){if(!r.querySelector(':scope > .pep-id-cell')){r.appendChild(nativeCell(r,'pep-id-cell',programId(r)));}});
  }else{all('.pep-id-cell',t).forEach(function(e){e.remove();});}
  var control=d.getElementById('pep-program-sort');if(control){control.remove();}
  if(P.settings.programsort){
   rows.forEach(function(r){if(!r.querySelector(':scope > .pep-date-cell')){r.appendChild(nativeCell(r,'pep-date-cell','unbekannt'));}});
   headers.forEach(function(r,i){if(!r.querySelector('.pep-date-cell')){var cell=nativeCell(r,'pep-date-cell',i?'':'Zuletzt gespeichert');cell.title='Erfasste WebUI-Speicherung seit Installation von Enhanced WebUI; ältere Zeiten sind unbekannt.';r.appendChild(cell);}});
   if(dateTable!==t){dateTable=t;api({op:'program_dates'},function(text,error){
    if(!t.isConnected||dateTable!==t||!P.settings.programsort){return;}if(!text){all('.pep-date-cell',t).forEach(function(c){c.title='Speicherzeiten konnten nicht geladen werden: '+error;});dateTable=null;return;}
    dates={};text.split('\n').slice(1).forEach(function(line){var f=line.trim().split('|');if(/^\d+$/.test(f[0])&&/^\d+$/.test(f[1])){dates[f[0]]=Number(f[1]);}});
    programRows(t).forEach(function(r){var value=dates[programId(r)],cell=r.querySelector('.pep-date-cell');if(!cell){return;}cell.textContent=value?new Date(value*1000).toLocaleString('de-DE'):'unbekannt';cell.dataset.pepTimestamp=value?String(value):'';});
   });}
  }else{all('.pep-date-cell',t).forEach(function(e){e.remove();});dateTable=null;}
  headers.concat(rows).forEach(positionColumns);
  columnWidths(t);
 }
 // Die native Programmspeicherung beobachten.
 function saveObserver(){
  if(observed||!w.Ajax||!w.Ajax.Responders){return;}observed=true;
  w.Ajax.Responders.register({onComplete:/* Eine bestätigte Speicherung für die Übersicht erfassen. */ function(request){
   if(String(request.url||'').indexOf('/esp/programs.htm')<0||!request.transport||request.transport.status<200||request.transport.status>=300){return;}
   var body=String(request.options&&request.options.postBody||'');try{body=w.unescape(body);}catch(ignore){}
   if(body.indexOf('RestoreProgram')<0){return;}
   var pid=/string\s+orig\s*=\s*"(\d+)"/.exec(body),copy=/string\s+copy\s*=\s*"(\d+)"/i.exec(body);
   if(!pid||!copy){return;}
   api({op:'program_saved',pid:pid[1],copy:copy[1]},function(text,error){if(!text){report('Speicherzeit konnte nicht erfasst werden: '+error);}dateTable=null;});
  }});
 }
 P.programColumns={scan:function(){programOverview();saveObserver();}};
 P.programColumns.scan();
})(window);
