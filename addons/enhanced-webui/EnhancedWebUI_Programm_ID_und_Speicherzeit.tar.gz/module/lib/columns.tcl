# Die erfassten Speicherzeiten lesen.
proc pep_program_dates {} {
  global pep_var
  set path "$pep_var/program-dates.list"
  if {![file exists $path]} { return {} }
  set fh [open $path r]; set records [read $fh]; close $fh
  if {[catch {llength $records}]} { error "Beschaedigte Programmdaten" }
  return $records
}
# Nach der nativen Speicherung die Speicherzeit des Programms erfassen.
proc pep_program_saved {pid copy} {
  global pep_var
  if {![pep_is_id $pid] || ![pep_is_id $copy] } { return "ERR|Ungueltige Speicherbestaetigung" }
  # Beim ersten Speichern bleibt die ID des neuen Programms erhalten.
  set copyCheck "true"
  if {$pid != $copy} { set copyCheck "!dom.GetObject($copy)" }
  if {[string trim [pep_rega "object ps=dom.GetObject($pid); if (ps) { if (ps.IsTypeOf(OT_PROGRAM) && (ps.ProgramCopyID()==ID_ERROR) && ($copyCheck)) { Write(\"SAVED\"); } }"]] != "SAVED"} { return "ERR|Speichern nicht bestaetigt" }
  set keep {}; foreach row [pep_program_dates] { if {[lindex $row 0] != $pid} { lappend keep $row } }
  lappend keep [list $pid [clock seconds]]
  file mkdir $pep_var
  set file "$pep_var/program-dates.list"; set fh [open "$file.tmp" w]; puts -nonewline $fh $keep; close $fh
  file rename -force "$file.tmp" $file
  return "OK"
}
# Die erfassten Speicherzeiten für die Programmübersicht ausgeben.
proc pep_program_dates_get {} {
  set out "OK\n"
  foreach row [pep_program_dates] {
    if {[llength $row] == 2 && [pep_is_id [lindex $row 0]] && [regexp {^[0-9]+$} [lindex $row 1]]} { append out "[join $row |]\n" }
  }
  return $out
}
